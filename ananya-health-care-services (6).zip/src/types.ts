export interface Service {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  iconName: string;
  features: string[];
  rates: string;
}

export interface Equipment {
  id: string;
  title: string;
  description: string;
  category: 'rent' | 'purchase' | 'both';
  rentalPrice?: string;
  purchasePrice?: string;
  features: string[];
  image: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  image: string;
  bio: string;
  phone?: string;
  email?: string;
}

export interface Booking {
  id: string;
  customerName: string;
  phoneNumber: string;
  email: string;
  type: 'service' | 'equipment';
  itemSelected: string; // Title of service or equipment
  bookingDate: string;
  address: string;
  requirementDetails: string;
  status: 'Pending' | 'Confirmed' | 'Cancelled';
  createdAt: string;
  patientId?: string;
  assignedStaffId?: string;
  assignedStaffName?: string;
  assignedStaffRole?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  date: string;
}

export interface JobApplication {
  id: string;
  applicantName: string;
  phoneNumber: string;
  email: string;
  position: string;
  experienceYears: string;
  qualifications: string;
  coverMessage: string;
  status: 'Received' | 'Shortlisted' | 'Rejected';
  createdAt: string;
}

export interface Office {
  id: string;
  city: string;
  branchName: string;
  address: string;
  mapQuery: string;
  embedUrl: string;
  phone: string;
  email: string;
}

export interface StaffUser {
  userId: string;
  name: string;
  role: string;
  phoneNumber: string;
  email: string;
  password?: string;
  status: 'Active' | 'Deactivated';
  createdAt: string;
  updatedAt?: string;
}

export interface StaffProfileChangeRequest {
  id: string;
  staffId: string;
  currentName: string;
  currentRole: string;
  currentPhone: string;
  currentEmail: string;
  requestedName: string;
  requestedRole: string;
  requestedPhone: string;
  requestedEmail: string;
  reason?: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  adminNotes?: string;
  createdAt: string;
  requestedAt?: string;
  resolvedAt?: string;
}

export interface AttendanceLog {
  id: string;
  userId: string;
  staffName: string;
  role: string;
  checkInTime: string;
  checkOutTime: string | null;
  location: string;
  actionNotes: string;
  date: string;
  coordinates?: { lat: number; lng: number };
  checkOutCoordinates?: { lat: number; lng: number };
}

export interface VitalRecord {
  id: string;
  patientId: string;
  patientName: string;
  temperature: number; // in °F
  bpSystolic: number;  // Systolic BP (mmHg)
  bpDiastolic: number; // Diastolic BP (mmHg)
  heartRate: number;   // Pulse rate (BPM)
  timestamp: string;   // Log date string (YYYY-MM-DD)
}

export interface BrandSettings {
  id?: string;
  logoUrl: string;
  brandName: string;
  tagline: string;
  updatedAt?: string;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: 'patient' | 'staff' | 'admin';
  phone?: string;
  createdAt?: string;
}

export type AuthModalMode = 'login' | 'signup' | 'forgot_password' | 'reset_password';



