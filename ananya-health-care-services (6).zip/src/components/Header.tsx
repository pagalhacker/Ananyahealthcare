import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import { 
  Phone, 
  Mail, 
  Menu, 
  X, 
  CalendarCheck, 
  ShieldCheck, 
  Heart, 
  LogIn, 
  LogOut, 
  UserCircle2, 
  KeyRound,
  Sparkles,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AuthModal } from './AuthModal';
import { getStoredCurrentUser, signOut } from '../lib/auth';
import { UserProfile } from '../types';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onBookNow: (itemName?: string, type?: 'service' | 'equipment') => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  onBookNow,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalInitialMode, setAuthModalInitialMode] = useState<'login' | 'signup' | 'forgot_password'>('login');
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(getStoredCurrentUser());
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  useEffect(() => {
    const handleAuthChange = () => {
      setCurrentUser(getStoredCurrentUser());
    };
    const handleOpenAuthEvent = (e: CustomEvent) => {
      const mode = e.detail?.mode || 'login';
      openAuth(mode);
    };

    window.addEventListener('ananya_auth_changed', handleAuthChange);
    window.addEventListener('storage', handleAuthChange);
    window.addEventListener('ananya_open_auth', handleOpenAuthEvent as EventListener);
    return () => {
      window.removeEventListener('ananya_auth_changed', handleAuthChange);
      window.removeEventListener('storage', handleAuthChange);
      window.removeEventListener('ananya_open_auth', handleOpenAuthEvent as EventListener);
    };
  }, []);

  const getNavMenuItems = () => {
    const baseItems = [
      { id: 'home', label: 'Home' },
      { id: 'services', label: 'Services' },
      { id: 'equipment', label: 'Medical Equipment' },
      { id: 'team', label: 'Our Team' },
      { id: 'careers', label: 'Careers' },
      { id: 'contact', label: 'Contact Us' },
      { id: 'family-portal', label: 'Family Portal', icon: Heart },
    ];

    if (currentUser?.role === 'admin') {
      return [
        { id: 'admin', label: 'Admin Operations Hub', icon: ShieldCheck, badge: 'ADMIN' },
        { id: 'profile', label: 'My Profile', icon: UserCircle2 },
        ...baseItems
      ];
    }

    if (currentUser?.role === 'staff') {
      return [
        { id: 'profile', label: 'Staff Duty & Profile', icon: Clock, badge: 'STAFF' },
        ...baseItems
      ];
    }

    return [
      { id: 'profile', label: 'My Profile', icon: UserCircle2 },
      ...baseItems
    ];
  };

  const menuItems = getNavMenuItems();

  const handleTabClick = (tabId: string) => {
    if (tabId === 'profile' && !currentUser) {
      openAuth('login');
      return;
    }
    setCurrentTab(tabId);
    setIsOpen(false);
    setShowUserDropdown(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSignOut = async () => {
    await signOut();
    setCurrentUser(null);
    setShowUserDropdown(false);
  };

  const openAuth = (mode: 'login' | 'signup' | 'forgot_password' = 'login') => {
    setAuthModalInitialMode(mode);
    setIsAuthModalOpen(true);
    setIsOpen(false);
  };

  return (
    <header className="relative w-full z-50">
      {/* Top Professional Contacts Strip */}
      <div className="bg-brand-navy text-white text-xs py-2.5 px-4 md:px-8 flex flex-col sm:flex-row justify-between items-center gap-3 border-b border-white/10 font-sans">
        <div className="flex flex-row flex-wrap items-center justify-center sm:justify-start gap-x-6 gap-y-2 w-full sm:w-auto">
          <a
            href="tel:+917734931740"
            className="flex items-center gap-2 hover:text-brand-magenta transition-colors duration-200"
          >
            <span className="w-4 flex justify-center shrink-0">
              <Phone className="w-3.5 h-3.5 text-brand-magenta" />
            </span>
            <span className="font-medium">+91 77349 31740</span>
          </a>
          <a
            href="tel:+918955725234"
            className="flex items-center gap-2 hover:text-brand-magenta transition-colors duration-200"
          >
            <span className="w-4 flex justify-center shrink-0">
              <Phone className="w-3.5 h-3.5 text-brand-magenta" />
            </span>
            <span className="font-medium">+91 89557 25234</span>
          </a>
          <span className="hidden sm:inline text-white/40">|</span>
          <a
            href="mailto:ananyahealthcare1@gmail.com"
            className="flex items-center gap-2 hover:text-brand-magenta transition-colors duration-200 text-white/90"
          >
            <span className="w-4 flex justify-center shrink-0">
              <Mail className="w-3.5 h-3.5 text-brand-magenta" />
            </span>
            <span className="font-medium">ananyahealthcare1@gmail.com</span>
          </a>
        </div>
        <div className="hidden sm:flex items-center gap-4">
          <span className="text-white/80">Support Hours: 24/7 Available</span>
        </div>
      </div>

      {/* Main Sticky Navbar */}
      <nav className="bg-white/90 backdrop-blur-md shadow-sm sticky top-0 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex justify-between items-center">
          {/* Brand Logo */}
          <div
            onClick={() => handleTabClick('home')}
            className="cursor-pointer py-1"
          >
            <Logo layout="horizontal" iconSize={54} />
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-${item.id}`}
                  onClick={() => handleTabClick(item.id)}
                  className={`relative px-4 py-2 text-sm font-semibold rounded-lg transition-all duration-200 flex items-center gap-1.5 cursor-pointer ${
                    isActive
                      ? 'text-brand-magenta bg-brand-magenta/5'
                      : 'text-brand-navy hover:text-brand-magenta hover:bg-gray-50'
                  }`}
                >
                  {Icon && (
                    item.id === 'family-portal' ? (
                      <motion.div
                        animate={{
                          scale: [1, 1.25, 1, 1.25, 1],
                        }}
                        transition={{
                          duration: 1.4,
                          repeat: Infinity,
                          ease: "easeInOut",
                          times: [0, 0.2, 0.4, 0.6, 1],
                        }}
                        className="inline-block shrink-0"
                      >
                        <Icon className="w-4 h-4 text-brand-magenta" fill="currentColor" fillOpacity={isActive ? 1 : 0.3} />
                      </motion.div>
                    ) : (
                      <Icon className={`w-4 h-4 ${isActive ? 'text-brand-magenta' : 'text-brand-navy/60'}`} />
                    )
                  )}
                  {item.label}
                  {isActive && (
                    <motion.div
                      layoutId="activeTabUnderline"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-magenta mx-4"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* User Auth & Call to Action CTA */}
          <div className="hidden lg:flex items-center gap-3">
            {/* User Profile / Auth button */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-gray-50 hover:bg-gray-100 border border-gray-200 transition-colors text-xs font-semibold text-brand-navy cursor-pointer shadow-xs"
                >
                  <div className="w-8 h-8 rounded-full bg-brand-magenta text-white flex items-center justify-center font-bold text-xs shadow-xs">
                    {(currentUser.name || 'U').charAt(0).toUpperCase()}
                  </div>
                  <div className="text-left max-w-[130px] truncate">
                    <div className="flex items-center gap-1.5">
                      <p className="truncate leading-tight font-bold text-brand-navy">{currentUser.name || 'User'}</p>
                    </div>
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-md uppercase tracking-wider inline-block ${
                      currentUser.role === 'admin'
                        ? 'bg-amber-100 text-amber-900 border border-amber-200'
                        : currentUser.role === 'staff'
                        ? 'bg-brand-magenta/10 text-brand-magenta border border-brand-magenta/20'
                        : 'bg-emerald-50 text-emerald-800'
                    }`}>
                      {currentUser.role === 'admin' ? 'Admin' : currentUser.role === 'staff' ? (currentUser.id?.startsWith('ANA') ? currentUser.id : 'Staff') : 'Patient'}
                    </span>
                  </div>
                </button>

                {showUserDropdown && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-gray-100 py-2 z-50 animate-in fade-in zoom-in-95">
                    <div 
                      onClick={() => handleTabClick('profile')}
                      className="px-4 py-3 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors"
                      title="View Profile Details"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs font-bold text-gray-900 truncate">{currentUser.name}</p>
                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-brand-magenta/10 text-brand-magenta uppercase">
                          {currentUser.role}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-500 truncate mt-0.5">{currentUser.email}</p>
                    </div>

                    <button
                      onClick={() => handleTabClick('profile')}
                      className="w-full px-4 py-2.5 text-left text-xs text-gray-800 hover:bg-gray-50 flex items-center gap-2 cursor-pointer font-bold"
                    >
                      <UserCircle2 className="w-4 h-4 text-brand-magenta" />
                      View My Profile & Duties
                    </button>

                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => handleTabClick('admin')}
                        className="w-full px-4 py-2.5 text-left text-xs text-gray-800 hover:bg-brand-navy/5 flex items-center gap-2 cursor-pointer font-bold text-brand-navy"
                      >
                        <ShieldCheck className="w-4 h-4 text-brand-magenta" />
                        Admin Operations Hub
                      </button>
                    )}

                    {currentUser.role === 'staff' && (
                      <button
                        onClick={() => handleTabClick('profile')}
                        className="w-full px-4 py-2.5 text-left text-xs text-gray-800 hover:bg-brand-magenta/5 flex items-center gap-2 cursor-pointer font-bold text-brand-magenta"
                      >
                        <Clock className="w-4 h-4 text-brand-navy" />
                        Staff Duty & Attendance Chart
                      </button>
                    )}

                    <button
                      onClick={() => handleTabClick('family-portal')}
                      className="w-full px-4 py-2 text-left text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2 cursor-pointer"
                    >
                      <Heart className="w-4 h-4 text-red-500" />
                      Family Health Portal
                    </button>

                    <div className="border-t border-gray-100 my-1" />

                    <button
                      onClick={handleSignOut}
                      className="w-full px-4 py-2 text-left text-xs text-red-600 hover:bg-red-50 flex items-center gap-2 cursor-pointer font-semibold"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out ({currentUser.name?.split(' ')[0]})
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => openAuth('login')}
                  id="header-btn-login"
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold text-brand-navy border border-gray-200 hover:border-brand-magenta hover:text-brand-magenta hover:bg-brand-magenta/5 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign In</span>
                </button>
                <button
                  onClick={() => openAuth('signup')}
                  id="header-btn-register"
                  className="px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-brand-navy hover:bg-brand-navy-light transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <UserCircle2 className="w-3.5 h-3.5 text-brand-magenta-light" />
                  <span>Register</span>
                </button>
              </div>
            )}

            {/* Book Staff/Equip CTA - Hide for logged-in staff */}
            {currentUser?.role !== 'staff' && (
              <button
                onClick={() => onBookNow()}
                id="header-cta-book"
                className="bg-brand-magenta hover:bg-brand-magenta-light text-white text-sm font-semibold px-5 py-2.5 rounded-full shadow-lg shadow-brand-magenta/15 hover:shadow-brand-magenta/25 active:scale-95 transition-all duration-200 flex items-center gap-2 cursor-pointer"
              >
                <CalendarCheck className="w-4 h-4" />
                Book Staff / Equip
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => setIsOpen(!isOpen)}
              id="mobile-menu-btn"
              className="text-brand-navy hover:text-brand-magenta p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200 cursor-pointer"
              aria-label="Toggle Menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Sidebar Navigation Drawer */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black z-40 lg:hidden"
            />

            {/* Sidebar Content */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-80 max-w-[85vw] bg-white shadow-2xl z-50 p-6 flex flex-col justify-between lg:hidden"
            >
              <div>
                {/* Drawer Header */}
                <div className="flex justify-between items-center pb-6 border-b border-gray-100 mb-6 gap-2">
                  <div className="flex items-center gap-2">
                    <Logo layout="icon-only" iconSize={40} />
                    <span className="font-display font-bold text-sm text-brand-navy tracking-tight leading-snug">
                      Ananya Health Care services
                    </span>
                  </div>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="p-1.5 rounded-lg text-gray-400 hover:text-brand-magenta hover:bg-gray-100 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Mobile User Profile Section */}
                <div className="mb-4 pb-4 border-b border-gray-100">
                  {currentUser ? (
                    <div className="p-3.5 bg-gray-50 rounded-2xl border border-gray-200/80 space-y-3">
                      <div className="flex items-center justify-between">
                        <div 
                          onClick={() => handleTabClick('profile')}
                          className="flex items-center gap-2.5 cursor-pointer flex-grow min-w-0"
                        >
                          <div className="w-10 h-10 rounded-full bg-brand-magenta text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0">
                            {(currentUser.name || 'U').charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-gray-900 truncate">{currentUser.name || 'User'}</p>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider inline-block mt-0.5 ${
                              currentUser.role === 'admin'
                                ? 'bg-amber-100 text-amber-900'
                                : currentUser.role === 'staff'
                                ? 'bg-brand-magenta/10 text-brand-magenta'
                                : 'bg-emerald-50 text-emerald-800'
                            }`}>
                              {currentUser.role === 'admin' ? 'Administrator' : currentUser.role === 'staff' ? (currentUser.id?.startsWith('ANA') ? currentUser.id : 'Healthcare Staff') : 'Patient Account'}
                            </span>
                          </div>
                        </div>
                        <button
                          onClick={handleSignOut}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-xl text-xs cursor-pointer shrink-0 ml-1"
                          title="Sign Out"
                        >
                          <LogOut className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-1 border-t border-gray-200/60">
                        <button
                          onClick={() => handleTabClick('profile')}
                          className="w-full py-2 bg-white hover:bg-gray-100 text-brand-navy border border-gray-200 text-xs font-bold rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <UserCircle2 className="w-3.5 h-3.5 text-brand-magenta" /> Profile
                        </button>
                        {currentUser.role === 'admin' ? (
                          <button
                            onClick={() => handleTabClick('admin')}
                            className="w-full py-2 bg-brand-navy hover:bg-brand-navy-light text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <ShieldCheck className="w-3.5 h-3.5 text-brand-magenta" /> Admin Hub
                          </button>
                        ) : currentUser.role === 'staff' ? (
                          <button
                            onClick={() => handleTabClick('profile')}
                            className="w-full py-2 bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Clock className="w-3.5 h-3.5" /> Duty Charts
                          </button>
                        ) : (
                          <button
                            onClick={() => handleTabClick('family-portal')}
                            className="w-full py-2 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Heart className="w-3.5 h-3.5" /> Health Log
                          </button>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <button
                        onClick={() => openAuth('login')}
                        className="flex-1 py-2.5 bg-brand-magenta/10 hover:bg-brand-magenta/20 text-brand-magenta font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <LogIn className="w-3.5 h-3.5" />
                        Sign In
                      </button>
                      <button
                        onClick={() => openAuth('signup')}
                        className="flex-1 py-2.5 bg-brand-navy hover:bg-brand-navy-light text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                      >
                        <UserCircle2 className="w-3.5 h-3.5 text-brand-magenta-light" />
                        Create Account
                      </button>
                    </div>
                  )}
                </div>

                {/* Drawer Links */}
                <div className="flex flex-col gap-2">
                  {menuItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = currentTab === item.id;
                    return (
                      <button
                        key={item.id}
                        id={`mob-nav-${item.id}`}
                        onClick={() => handleTabClick(item.id)}
                        className={`w-full px-4 py-3 text-left font-semibold rounded-lg flex items-center gap-3 transition-colors ${
                          isActive
                            ? 'text-brand-magenta bg-brand-magenta/5'
                            : 'text-brand-navy hover:text-brand-magenta hover:bg-gray-50'
                        }`}
                      >
                        {Icon && (
                          item.id === 'family-portal' ? (
                            <motion.div
                              animate={{
                                scale: [1, 1.25, 1, 1.25, 1],
                              }}
                              transition={{
                                duration: 1.4,
                                repeat: Infinity,
                                ease: "easeInOut",
                                times: [0, 0.2, 0.4, 0.6, 1],
                              }}
                              className="inline-block shrink-0"
                            >
                              <Icon className="w-5 h-5 text-brand-magenta" fill="currentColor" fillOpacity={isActive ? 1 : 0.3} />
                            </motion.div>
                          ) : (
                            <Icon className={`w-5 h-5 ${isActive ? 'text-brand-magenta' : 'text-brand-navy/60'}`} />
                          )
                        )}
                        {item.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Drawer Footer Call Action */}
              <div className="border-t border-gray-100 pt-6 flex flex-col gap-4">
                {currentUser?.role !== 'staff' && (
                  <button
                    onClick={() => {
                      setIsOpen(false);
                      onBookNow();
                    }}
                    className="w-full bg-brand-magenta hover:bg-brand-magenta-light text-white font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-brand-magenta/20 transition-all cursor-pointer"
                  >
                    <CalendarCheck className="w-5 h-5" />
                    Book Now
                  </button>
                )}
                <div className="text-center text-xs text-gray-500">
                  <p>Inquiries: 7734931740 / 8955725234</p>
                  <p className="mt-1">ananyahealthcare1@gmail.com</p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Global Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialMode={authModalInitialMode}
        onOpenStaffPortal={() => handleTabClick('admin')}
        onAuthSuccess={(user) => {
          setCurrentUser(user);
          setCurrentTab('profile');
        }}
      />
    </header>
  );
};
