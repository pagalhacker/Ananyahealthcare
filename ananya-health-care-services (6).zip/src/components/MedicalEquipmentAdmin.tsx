import React, { useState, useEffect, useRef } from 'react';
import { Equipment } from '../types';
import { 
  getLocalEquipmentCatalog, 
  updateEquipmentItem, 
  addEquipmentItem, 
  deleteEquipmentItem, 
  resetEquipmentCatalogToDefault, 
  syncEquipmentWithFirestore, 
  EQUIPMENT_UPDATED_EVENT 
} from '../utils/equipmentHelper';
import { 
  Stethoscope, 
  Upload, 
  Image as ImageIcon, 
  Trash2, 
  Edit3, 
  Plus, 
  DollarSign, 
  Check, 
  X, 
  RefreshCw, 
  AlertCircle, 
  Sparkles, 
  CheckCircle2, 
  Search, 
  Tag, 
  Eye, 
  RotateCcw,
  Sliders,
  CheckSquare,
  HelpCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Curated high quality clinical equipment preset photos for easy selection
const PRESET_EQUIPMENT_PHOTOS = [
  { name: 'Wheelchair', url: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=600' },
  { name: 'Oxygen Concentrator', url: 'https://images.unsplash.com/photo-1584515901387-a7a1a63376af?auto=format&fit=crop&q=80&w=600' },
  { name: 'Hospital Cardiac Bed', url: 'https://images.unsplash.com/photo-1586773860418-d3b3ac96317d?auto=format&fit=crop&q=80&w=600' },
  { name: 'Multipara Monitor', url: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=600' },
  { name: 'Air Mattress', url: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=600' },
  { name: 'BiPAP / CPAP Machine', url: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=600' },
  { name: 'Suction Apparatus', url: 'https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?auto=format&fit=crop&q=80&w=600' },
  { name: '3-Channel ECG Unit', url: 'https://images.unsplash.com/photo-1603398938378-e54eab446dde?auto=format&fit=crop&q=80&w=600' },
  { name: 'Medical Walker', url: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&q=80&w=600' },
  { name: 'IV Drip Stand & Fluids', url: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=600' }
];

export const MedicalEquipmentAdmin: React.FC = () => {
  const [equipmentList, setEquipmentList] = useState<Equipment[]>(getLocalEquipmentCatalog());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<'all' | 'rent' | 'purchase' | 'missing-photo'>('all');
  const [isSyncing, setIsSyncing] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Modal State for Photo Upload / Change
  const [editingPhotoItem, setEditingPhotoItem] = useState<Equipment | null>(null);
  const [photoUrlInput, setPhotoUrlInput] = useState('');
  const [selectedPresetUrl, setSelectedPresetUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Modal State for Full Item Edit or Add New
  const [editingItem, setEditingItem] = useState<Equipment | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newItemData, setNewItemData] = useState<Omit<Equipment, 'id'>>({
    title: '',
    description: '',
    category: 'both',
    rentalPrice: '₹3,000 / month',
    purchasePrice: '₹20,000',
    features: ['Clinical-grade quality', 'Sanitized & calibrated', 'Doorstep delivery & installation'],
    image: PRESET_EQUIPMENT_PHOTOS[0].url
  });

  // Load and sync with Firestore on component mount
  useEffect(() => {
    const handleSync = async () => {
      setIsSyncing(true);
      const synced = await syncEquipmentWithFirestore();
      setEquipmentList(synced);
      setIsSyncing(false);
    };
    handleSync();

    const onUpdate = (e: CustomEvent) => {
      if (e.detail) {
        setEquipmentList(e.detail);
      } else {
        setEquipmentList(getLocalEquipmentCatalog());
      }
    };

    window.addEventListener(EQUIPMENT_UPDATED_EVENT, onUpdate as EventListener);
    return () => {
      window.removeEventListener(EQUIPMENT_UPDATED_EVENT, onUpdate as EventListener);
    };
  }, []);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Quick Rent Price update
  const handleUpdateRentPrice = async (item: Equipment, newPrice: string) => {
    try {
      const updatedList = await updateEquipmentItem(item.id, { rentalPrice: newPrice });
      setEquipmentList(updatedList);
      showToast(`Updated rental price for "${item.title}" to ${newPrice || 'N/A'}`);
    } catch (e) {
      showToast('Failed to update rental price', 'error');
    }
  };

  // Quick Purchase Price update
  const handleUpdatePurchasePrice = async (item: Equipment, newPrice: string) => {
    try {
      const updatedList = await updateEquipmentItem(item.id, { purchasePrice: newPrice });
      setEquipmentList(updatedList);
      showToast(`Updated purchase price for "${item.title}" to ${newPrice || 'N/A'}`);
    } catch (e) {
      showToast('Failed to update purchase price', 'error');
    }
  };

  // Remove Photo from equipment
  const handleRemovePhoto = async (item: Equipment) => {
    if (!window.confirm(`Are you sure you want to remove the photo for "${item.title}"?`)) return;
    try {
      const updatedList = await updateEquipmentItem(item.id, { image: '' });
      setEquipmentList(updatedList);
      showToast(`Photo removed for "${item.title}"`);
    } catch (e) {
      showToast('Failed to remove photo', 'error');
    }
  };

  // Save new photo from modal (File upload, pasted URL, or selected preset)
  const handleSavePhotoModal = async () => {
    if (!editingPhotoItem) return;
    const finalImage = photoUrlInput.trim() || selectedPresetUrl;
    try {
      const updatedList = await updateEquipmentItem(editingPhotoItem.id, { image: finalImage });
      setEquipmentList(updatedList);
      showToast(`Photo updated successfully for "${editingPhotoItem.title}"`);
      setEditingPhotoItem(null);
      setPhotoUrlInput('');
      setSelectedPresetUrl('');
    } catch (e) {
      showToast('Failed to save photo', 'error');
    }
  };

  // Handle local File Upload convert to base64
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) {
        showToast('Image size should be less than 3MB', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setPhotoUrlInput(reader.result);
          setSelectedPresetUrl('');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Delete Equipment Item
  const handleDeleteItem = async (item: Equipment) => {
    if (!window.confirm(`Are you sure you want to delete "${item.title}" from the catalog?`)) return;
    try {
      const updatedList = await deleteEquipmentItem(item.id);
      setEquipmentList(updatedList);
      showToast(`Deleted "${item.title}" from catalog`);
    } catch (e) {
      showToast('Failed to delete equipment', 'error');
    }
  };

  // Save full equipment edits
  const handleSaveFullEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;
    try {
      const updatedList = await updateEquipmentItem(editingItem.id, editingItem);
      setEquipmentList(updatedList);
      showToast(`Saved changes for "${editingItem.title}"`);
      setEditingItem(null);
    } catch (e) {
      showToast('Failed to save item edits', 'error');
    }
  };

  // Create new Equipment
  const handleCreateNewItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemData.title.trim()) {
      showToast('Please enter an equipment title', 'error');
      return;
    }
    try {
      const updatedList = await addEquipmentItem(newItemData);
      setEquipmentList(updatedList);
      showToast(`Added "${newItemData.title}" to equipment catalog`);
      setIsCreatingNew(false);
      setNewItemData({
        title: '',
        description: '',
        category: 'both',
        rentalPrice: '₹3,000 / month',
        purchasePrice: '₹20,000',
        features: ['Clinical-grade quality', 'Sanitized & calibrated', 'Doorstep delivery & installation'],
        image: PRESET_EQUIPMENT_PHOTOS[0].url
      });
    } catch (e) {
      showToast('Failed to create equipment item', 'error');
    }
  };

  // Reset to default catalog
  const handleResetCatalog = async () => {
    if (!window.confirm('Reset all medical equipment catalog items to original defaults? Custom prices and added items will be replaced.')) return;
    try {
      const resetList = await resetEquipmentCatalogToDefault();
      setEquipmentList(resetList);
      showToast('Equipment catalog reset to defaults');
    } catch (e) {
      showToast('Failed to reset catalog', 'error');
    }
  };

  // Filtered equipment list
  const searchLower = (searchQuery || '').trim().toLowerCase();
  const filteredList = equipmentList.filter((item) => {
    const titleLower = (item.title || '').toLowerCase();
    const descLower = (item.description || '').toLowerCase();
    const matchesSearch = !searchLower || titleLower.includes(searchLower) || descLower.includes(searchLower);

    if (!matchesSearch) return false;

    if (filterCategory === 'rent') return !!item.rentalPrice && item.rentalPrice.trim() !== '';
    if (filterCategory === 'purchase') return !!item.purchasePrice && item.purchasePrice.trim() !== '';
    if (filterCategory === 'missing-photo') return !item.image || item.image.trim() === '';
    return true;
  });

  return (
    <div className="space-y-8 font-sans">
      {/* Toast Banner */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`p-4 rounded-2xl text-xs font-bold flex items-center justify-between shadow-lg border ${
              toastMessage.type === 'success'
                ? 'bg-emerald-500 text-white border-emerald-600'
                : 'bg-rose-500 text-white border-rose-600'
            }`}
          >
            <div className="flex items-center gap-2">
              {toastMessage.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 shrink-0" />
              )}
              <span>{toastMessage.text}</span>
            </div>
            <button onClick={() => setToastMessage(null)} className="p-1 hover:opacity-80">
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-brand-navy via-slate-900 to-brand-navy text-white p-6 md:p-8 rounded-3xl border border-white/10 shadow-lg relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-2 max-w-2xl relative z-10">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/10 px-3 py-1 rounded-full border border-brand-magenta/20">
            <Stethoscope className="w-3.5 h-3.5" /> Medical Equipment Control Panel
          </div>
          <h2 className="font-display font-black text-2xl md:text-3xl text-white">
            Equipment Catalog & Pricing Manager
          </h2>
          <p className="text-gray-300 text-xs md:text-sm leading-relaxed">
            Manage medical equipment photos, modify rental prices, set purchase rates, and update features. All changes sync in real-time across the client catalog and booking forms.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 z-10 shrink-0">
          <button
            onClick={() => setIsCreatingNew(true)}
            className="bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold py-3 px-4 rounded-2xl shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" /> Add New Equipment
          </button>
          
          <button
            onClick={handleResetCatalog}
            title="Reset catalog to default preset list"
            className="bg-white/10 hover:bg-white/20 text-white text-xs font-bold py-3 px-3.5 rounded-2xl border border-white/20 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
          </button>
        </div>
      </div>

      {/* Statistics Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-navy/10 text-brand-navy flex items-center justify-center shrink-0">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-gray-400 font-bold uppercase block">Total Items</span>
            <span className="text-xl font-display font-black text-brand-navy">{equipmentList.length}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <Tag className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-gray-400 font-bold uppercase block">Available for Rent</span>
            <span className="text-xl font-display font-black text-emerald-700">
              {equipmentList.filter(e => e.rentalPrice && e.rentalPrice.trim() !== '').length}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-magenta/10 text-brand-magenta flex items-center justify-center shrink-0">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-gray-400 font-bold uppercase block">Available to Buy</span>
            <span className="text-xl font-display font-black text-brand-magenta">
              {equipmentList.filter(e => e.purchasePrice && e.purchasePrice.trim() !== '').length}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <ImageIcon className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-gray-400 font-bold uppercase block">Missing Photo</span>
            <span className="text-xl font-display font-black text-amber-700">
              {equipmentList.filter(e => !e.image || e.image.trim() === '').length}
            </span>
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col sm:flex-row justify-between items-center gap-4">
        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search equipment by title or feature..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-gray-200 rounded-xl text-xs font-sans text-gray-800 focus:outline-none focus:border-brand-magenta"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {[
            { id: 'all', label: `All (${equipmentList.length})` },
            { id: 'rent', label: 'For Rent' },
            { id: 'purchase', label: 'For Purchase' },
            { id: 'missing-photo', label: 'Missing Photo' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterCategory(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                filterCategory === tab.id
                  ? 'bg-brand-navy text-white shadow-sm'
                  : 'bg-slate-100 text-gray-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Equipment Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredList.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-3xl border border-gray-150 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col justify-between group"
          >
            {/* Top Image Box with Photo Management Overlay */}
            <div className="relative h-52 bg-slate-100 overflow-hidden group/img">
              {item.image && item.image.trim() !== '' ? (
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover/img:scale-105"
                  onError={(e) => {
                    // Fallback on image load error
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=600';
                  }}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 text-gray-400 p-4 text-center">
                  <ImageIcon className="w-10 h-10 mb-2 opacity-50 text-gray-400" />
                  <span className="text-xs font-bold text-gray-500">No Photo Attached</span>
                  <span className="text-[10px] text-gray-400 mt-0.5">Click below to upload or select a photo</span>
                </div>
              )}

              {/* Badges */}
              <div className="absolute top-3 left-3 flex gap-1.5 flex-wrap z-10">
                {item.rentalPrice && (
                  <span className="text-[10px] font-bold bg-brand-navy text-white px-2.5 py-1 rounded-full uppercase tracking-wider shadow-sm">
                    Rent
                  </span>
                )}
                {item.purchasePrice && (
                  <span className="text-[10px] font-bold bg-brand-magenta text-white px-2.5 py-1 rounded-full uppercase tracking-wider shadow-sm">
                    Buy
                  </span>
                )}
              </div>

              {/* Photo Action Overlay Controls */}
              <div className="absolute inset-0 bg-slate-900/70 backdrop-blur-[2px] opacity-0 group-hover/img:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-4 z-20">
                <button
                  onClick={() => {
                    setEditingPhotoItem(item);
                    setPhotoUrlInput(item.image || '');
                    setSelectedPresetUrl('');
                  }}
                  className="bg-white text-brand-navy hover:bg-brand-magenta hover:text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer w-full max-w-[180px] justify-center"
                >
                  <Upload className="w-3.5 h-3.5" />
                  {item.image ? 'Change Photo' : 'Add Photo'}
                </button>

                {item.image && (
                  <button
                    onClick={() => handleRemovePhoto(item)}
                    className="bg-rose-600 hover:bg-rose-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer w-full max-w-[180px] justify-center"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Remove Photo
                  </button>
                )}
              </div>
            </div>

            {/* Content Body */}
            <div className="p-6 space-y-4 flex-grow flex flex-col justify-between">
              <div>
                {/* Title & Category Header */}
                <div className="flex justify-between items-start gap-2">
                  <h3 className="font-display font-bold text-base text-brand-navy line-clamp-1" title={item.title}>
                    {item.title}
                  </h3>
                  <button
                    onClick={() => setEditingItem(item)}
                    className="p-1.5 text-gray-400 hover:text-brand-magenta hover:bg-brand-magenta/10 rounded-lg transition-all shrink-0 cursor-pointer"
                    title="Edit full equipment details"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-gray-500 text-xs mt-1.5 leading-relaxed line-clamp-2">
                  {item.description}
                </p>
              </div>

              {/* RENT PRICE CHANGE BOX */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-gray-200 space-y-2.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-brand-navy text-[11px] flex items-center gap-1">
                    <DollarSign className="w-3.5 h-3.5 text-brand-magenta" /> Rental Price Rate:
                  </span>
                  <span className="text-[10px] text-gray-400 font-mono">Editable</span>
                </div>

                {/* Direct Rent Price Input & Quick Preset Chips */}
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={item.rentalPrice || ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        setEquipmentList(prev => prev.map(i => i.id === item.id ? { ...i, rentalPrice: val } : i));
                      }}
                      onBlur={(e) => handleUpdateRentPrice(item, e.target.value)}
                      placeholder="e.g. ₹4,500 / month (or empty)"
                      className="w-full px-3 py-1.5 bg-white border border-gray-200 rounded-xl text-xs font-mono font-bold text-brand-navy focus:outline-none focus:border-brand-magenta"
                    />
                  </div>

                  {/* Quick Preset Rent Rates */}
                  <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[10px]">
                    <span className="text-gray-400 shrink-0 font-medium">Quick Set:</span>
                    {['₹500 / day', '₹1,500 / week', '₹3,000 / month', '₹4,500 / month', '₹6,000 / month'].map((rate) => (
                      <button
                        key={rate}
                        onClick={() => handleUpdateRentPrice(item, rate)}
                        className={`px-2 py-0.5 rounded-md font-mono shrink-0 transition-all cursor-pointer ${
                          item.rentalPrice === rate
                            ? 'bg-brand-navy text-white font-bold'
                            : 'bg-white border border-gray-200 text-gray-600 hover:border-brand-magenta'
                        }`}
                      >
                        {rate}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Purchase Price Input */}
                <div className="pt-2 border-t border-gray-200/60 flex items-center justify-between gap-2 text-xs">
                  <span className="text-gray-500 font-medium text-[11px] shrink-0">Purchase Rate:</span>
                  <input
                    type="text"
                    value={item.purchasePrice || ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      setEquipmentList(prev => prev.map(i => i.id === item.id ? { ...i, purchasePrice: val } : i));
                    }}
                    onBlur={(e) => handleUpdatePurchasePrice(item, e.target.value)}
                    placeholder="e.g. ₹35,000"
                    className="w-36 px-2.5 py-1 bg-white border border-gray-200 rounded-lg text-xs font-mono font-bold text-brand-magenta text-right focus:outline-none focus:border-brand-magenta"
                  />
                </div>
              </div>

              {/* Features snippet */}
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Features ({item.features.length}):</span>
                <ul className="text-[11px] text-gray-600 space-y-0.5">
                  {item.features.slice(0, 2).map((feat, idx) => (
                    <li key={idx} className="truncate flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-500 shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Controls Bar */}
            <div className="p-4 bg-slate-50/80 border-t border-gray-100 flex justify-between items-center gap-2">
              <button
                onClick={() => {
                  setEditingPhotoItem(item);
                  setPhotoUrlInput(item.image || '');
                  setSelectedPresetUrl('');
                }}
                className="text-xs text-brand-navy hover:text-brand-magenta font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                {item.image ? 'Edit Photo' : '+ Add Photo'}
              </button>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setEditingItem(item)}
                  className="p-2 text-gray-600 hover:text-brand-navy hover:bg-gray-200 rounded-xl transition-all cursor-pointer"
                  title="Full Details Edit"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDeleteItem(item)}
                  className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-xl transition-all cursor-pointer"
                  title="Delete Equipment"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredList.length === 0 && (
        <div className="bg-white rounded-3xl p-12 text-center border border-gray-200 space-y-3">
          <Stethoscope className="w-12 h-12 text-gray-300 mx-auto" />
          <h3 className="font-display font-bold text-lg text-brand-navy">No Equipment Items Found</h3>
          <p className="text-xs text-gray-500 max-w-md mx-auto">
            No equipment items match your search filter "{searchQuery}". Try clearing your query or add a new equipment item.
          </p>
          <button
            onClick={() => { setSearchQuery(''); setFilterCategory('all'); }}
            className="mt-2 bg-brand-navy text-white text-xs font-bold px-4 py-2 rounded-xl"
          >
            Clear Filters
          </button>
        </div>
      )}

      {/* PHOTO UPLOAD & SELECTION MODAL */}
      <AnimatePresence>
        {editingPhotoItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl border border-gray-200 shadow-2xl w-full max-w-2xl overflow-hidden font-sans flex flex-col max-h-[90vh]"
            >
              {/* Modal Header */}
              <div className="p-6 bg-brand-navy text-white flex justify-between items-center border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-brand-magenta/20 border border-brand-magenta/30 flex items-center justify-center">
                    <ImageIcon className="w-5 h-5 text-brand-magenta" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-lg text-white">
                      Manage Photo for "{editingPhotoItem.title}"
                    </h3>
                    <p className="text-xs text-gray-300">
                      Upload from computer, paste an image link, or choose from our clinical presets.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setEditingPhotoItem(null)}
                  className="p-2 text-gray-400 hover:text-white rounded-xl transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto space-y-6">
                
                {/* Current Image Preview */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block">
                    Current Photo Preview:
                  </label>
                  <div className="h-44 rounded-2xl bg-slate-100 border border-gray-200 overflow-hidden relative flex items-center justify-center">
                    {(photoUrlInput.trim() || selectedPresetUrl) ? (
                      <img
                        src={photoUrlInput.trim() || selectedPresetUrl}
                        alt="Preview"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=600';
                        }}
                      />
                    ) : (
                      <div className="text-center text-gray-400 p-4">
                        <ImageIcon className="w-10 h-10 mx-auto mb-1 opacity-40" />
                        <span className="text-xs font-bold">No Photo Selected</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Option 1: File Upload */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block">
                    Option 1: Upload Photo File from Device
                  </label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-3 px-4 bg-slate-50 hover:bg-slate-100 border-2 border-dashed border-gray-300 hover:border-brand-magenta rounded-2xl text-xs font-bold text-brand-navy transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-brand-magenta" />
                    Select Image File (.png, .jpg, .webp)
                  </button>
                </div>

                {/* Option 2: Image URL Input */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block">
                    Option 2: Paste Image URL
                  </label>
                  <input
                    type="url"
                    value={photoUrlInput}
                    onChange={(e) => {
                      setPhotoUrlInput(e.target.value);
                      setSelectedPresetUrl('');
                    }}
                    placeholder="https://example.com/equipment-photo.jpg"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-gray-200 rounded-xl text-xs font-sans text-gray-800 focus:outline-none focus:border-brand-magenta"
                  />
                </div>

                {/* Option 3: Presets Gallery */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block">
                    Option 3: Choose From Clinical Preset Gallery
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {PRESET_EQUIPMENT_PHOTOS.map((preset) => (
                      <button
                        key={preset.name}
                        onClick={() => {
                          setSelectedPresetUrl(preset.url);
                          setPhotoUrlInput('');
                        }}
                        className={`p-1.5 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden group ${
                          (selectedPresetUrl === preset.url || photoUrlInput === preset.url)
                            ? 'border-brand-magenta bg-brand-magenta/10 ring-2 ring-brand-magenta'
                            : 'border-gray-200 hover:border-brand-navy'
                        }`}
                      >
                        <div className="h-16 rounded-lg bg-slate-100 overflow-hidden mb-1">
                          <img
                            src={preset.url}
                            alt={preset.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <span className="text-[10px] font-bold text-brand-navy block truncate">
                          {preset.name}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

              </div>

              {/* Modal Footer */}
              <div className="p-4 bg-slate-50 border-t border-gray-200 flex justify-between items-center gap-3">
                <button
                  onClick={() => {
                    setPhotoUrlInput('');
                    setSelectedPresetUrl('');
                  }}
                  className="text-xs text-rose-600 hover:underline font-bold"
                >
                  Clear Selection
                </button>

                <div className="flex gap-2">
                  <button
                    onClick={() => setEditingPhotoItem(null)}
                    className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-gray-700 text-xs font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSavePhotoModal}
                    className="px-5 py-2 bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer"
                  >
                    Save Photo
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FULL ITEM EDIT OR CREATE MODAL */}
      <AnimatePresence>
        {(editingItem || isCreatingNew) && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl border border-gray-200 shadow-2xl w-full max-w-2xl overflow-hidden font-sans flex flex-col max-h-[90vh]"
            >
              {/* Header */}
              <div className="p-6 bg-brand-navy text-white flex justify-between items-center border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-brand-magenta/20 border border-brand-magenta/30 flex items-center justify-center">
                    <Stethoscope className="w-5 h-5 text-brand-magenta" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-lg text-white">
                      {isCreatingNew ? 'Add New Medical Equipment' : `Edit "${editingItem?.title}"`}
                    </h3>
                    <p className="text-xs text-gray-300">
                      Update title, rates, category, features, and description.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => { setEditingItem(null); setIsCreatingNew(false); }}
                  className="p-2 text-gray-400 hover:text-white rounded-xl transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form Body */}
              <form
                onSubmit={isCreatingNew ? handleCreateNewItem : handleSaveFullEdit}
                className="p-6 overflow-y-auto space-y-4"
              >
                {/* Title */}
                <div>
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block mb-1">
                    Equipment Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={isCreatingNew ? newItemData.title : (editingItem?.title || '')}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (isCreatingNew) setNewItemData(p => ({ ...p, title: val }));
                      else if (editingItem) setEditingItem(p => p ? { ...p, title: val } : null);
                    }}
                    placeholder="e.g. Electric Hospital Bed with Remote"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-gray-200 rounded-xl text-xs font-sans text-gray-800 focus:outline-none focus:border-brand-magenta font-bold"
                  />
                </div>

                {/* Category & Pricing */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block mb-1">
                      Availability Mode
                    </label>
                    <select
                      value={isCreatingNew ? newItemData.category : (editingItem?.category || 'both')}
                      onChange={(e) => {
                        const val = e.target.value as 'rent' | 'purchase' | 'both';
                        if (isCreatingNew) setNewItemData(p => ({ ...p, category: val }));
                        else if (editingItem) setEditingItem(p => p ? { ...p, category: val } : null);
                      }}
                      className="w-full px-3 py-2.5 bg-slate-50 border border-gray-200 rounded-xl text-xs font-sans text-gray-800 focus:outline-none focus:border-brand-magenta"
                    >
                      <option value="both">Rent & Purchase</option>
                      <option value="rent">Rent Only</option>
                      <option value="purchase">Purchase Only</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block mb-1">
                      Rental Price
                    </label>
                    <input
                      type="text"
                      value={isCreatingNew ? newItemData.rentalPrice || '' : (editingItem?.rentalPrice || '')}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (isCreatingNew) setNewItemData(p => ({ ...p, rentalPrice: val }));
                        else if (editingItem) setEditingItem(p => p ? { ...p, rentalPrice: val } : null);
                      }}
                      placeholder="₹4,500 / month"
                      className="w-full px-3 py-2.5 bg-slate-50 border border-gray-200 rounded-xl text-xs font-mono font-bold text-brand-navy focus:outline-none focus:border-brand-magenta"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block mb-1">
                      Purchase Price
                    </label>
                    <input
                      type="text"
                      value={isCreatingNew ? newItemData.purchasePrice || '' : (editingItem?.purchasePrice || '')}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (isCreatingNew) setNewItemData(p => ({ ...p, purchasePrice: val }));
                        else if (editingItem) setEditingItem(p => p ? { ...p, purchasePrice: val } : null);
                      }}
                      placeholder="₹35,000"
                      className="w-full px-3 py-2.5 bg-slate-50 border border-gray-200 rounded-xl text-xs font-mono font-bold text-brand-magenta focus:outline-none focus:border-brand-magenta"
                    />
                  </div>
                </div>

                {/* Image URL */}
                <div>
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block mb-1">
                    Photo URL
                  </label>
                  <input
                    type="url"
                    value={isCreatingNew ? newItemData.image : (editingItem?.image || '')}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (isCreatingNew) setNewItemData(p => ({ ...p, image: val }));
                      else if (editingItem) setEditingItem(p => p ? { ...p, image: val } : null);
                    }}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="w-full px-4 py-2.5 bg-slate-50 border border-gray-200 rounded-xl text-xs font-sans text-gray-800 focus:outline-none focus:border-brand-magenta"
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block mb-1">
                    Description
                  </label>
                  <textarea
                    rows={3}
                    value={isCreatingNew ? newItemData.description : (editingItem?.description || '')}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (isCreatingNew) setNewItemData(p => ({ ...p, description: val }));
                      else if (editingItem) setEditingItem(p => p ? { ...p, description: val } : null);
                    }}
                    placeholder="High purity medical grade equipment with safety alarms and continuous operation support..."
                    className="w-full px-4 py-2 bg-slate-50 border border-gray-200 rounded-xl text-xs font-sans text-gray-800 focus:outline-none focus:border-brand-magenta"
                  />
                </div>

                {/* Features (Comma separated) */}
                <div>
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider block mb-1">
                    Key Features (Separate items by comma)
                  </label>
                  <input
                    type="text"
                    value={
                      isCreatingNew
                        ? newItemData.features.join(', ')
                        : (editingItem?.features.join(', ') || '')
                    }
                    onChange={(e) => {
                      const feats = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                      if (isCreatingNew) setNewItemData(p => ({ ...p, features: feats }));
                      else if (editingItem) setEditingItem(p => p ? { ...p, features: feats } : null);
                    }}
                    placeholder="Lightweight, Silent operation, High safety alarms"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-gray-200 rounded-xl text-xs font-sans text-gray-800 focus:outline-none focus:border-brand-magenta"
                  />
                </div>

                {/* Submit Buttons */}
                <div className="pt-4 border-t border-gray-200 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => { setEditingItem(null); setIsCreatingNew(false); }}
                    className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-gray-700 text-xs font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer"
                  >
                    {isCreatingNew ? 'Create Equipment' : 'Save Changes'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
