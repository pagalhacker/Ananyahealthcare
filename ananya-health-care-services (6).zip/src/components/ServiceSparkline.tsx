import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { VitalRecord } from '../types';

interface ServiceSparklineProps {
  data: VitalRecord[];
  metric: 'temperature' | 'bloodPressure' | 'heartRate';
}

export const ServiceSparkline: React.FC<ServiceSparklineProps> = ({ data, metric }) => {
  // Sort data chronologically to ensure the sparkline is drawn left-to-right correctly
  const sortedData = [...data].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  // Formatting dates for tooltips and X-Axis
  const formatXAxis = (tickItem: string) => {
    try {
      const d = new Date(tickItem);
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } catch {
      return tickItem;
    }
  };

  // Custom styling for Tooltip
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const dateStr = formatXAxis(payload[0].payload.timestamp);
      const name = payload[0].payload.patientName;
      return (
        <div className="bg-slate-900 text-white p-3.5 rounded-2xl border border-slate-800 shadow-xl text-xs font-sans space-y-1.5">
          <p className="font-bold text-[10px] text-gray-400 uppercase tracking-wider border-b border-slate-800 pb-1 flex justify-between gap-4">
            <span>{name}</span>
            <span>{dateStr}</span>
          </p>
          {payload.map((pld: any, idx: number) => (
            <div key={idx} className="flex items-center justify-between gap-6 font-semibold">
              <span className="flex items-center gap-1.5 text-gray-300">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: pld.color }} />
                {pld.name}:
              </span>
              <span className="text-white font-mono">{pld.value} {pld.unit}</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  if (sortedData.length === 0) {
    return (
      <div className="h-32 flex items-center justify-center bg-gray-50 border border-dashed border-gray-200 rounded-2xl text-xs text-gray-400 font-medium">
        No Vitals Data to Display
      </div>
    );
  }

  return (
    <div className="w-full h-32 relative">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={sortedData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
          <defs>
            <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2}/>
              <stop offset="95%" stopColor="#ef4444" stopOpacity={0.0}/>
            </linearGradient>
            <linearGradient id="colorPulse" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#d946ef" stopOpacity={0.2}/>
              <stop offset="95%" stopColor="#d946ef" stopOpacity={0.0}/>
            </linearGradient>
            <linearGradient id="colorBPSys" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15}/>
              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0}/>
            </linearGradient>
            <linearGradient id="colorBPDia" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.15}/>
              <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0}/>
            </linearGradient>
          </defs>

          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
          <XAxis 
            dataKey="timestamp" 
            hide 
          />
          <YAxis 
            hide 
            domain={['auto', 'auto']} 
          />
          <Tooltip content={<CustomTooltip />} />

          {metric === 'temperature' && (
            <Area
              name="Temperature"
              unit="°F"
              type="monotone"
              dataKey="temperature"
              stroke="#ef4444"
              strokeWidth={2.5}
              fillOpacity={1}
              fill="url(#colorTemp)"
              activeDot={{ r: 6, stroke: '#ffffff', strokeWidth: 2 }}
            />
          )}

          {metric === 'heartRate' && (
            <Area
              name="Heart Rate"
              unit=" bpm"
              type="monotone"
              dataKey="heartRate"
              stroke="#d946ef"
              strokeWidth={2.5}
              fillOpacity={1}
              fill="url(#colorPulse)"
              activeDot={{ r: 6, stroke: '#ffffff', strokeWidth: 2 }}
            />
          )}

          {metric === 'bloodPressure' && (
            <>
              <Area
                name="Systolic BP"
                unit=" mmHg"
                type="monotone"
                dataKey="bpSystolic"
                stroke="#3b82f6"
                strokeWidth={2.2}
                fillOpacity={1}
                fill="url(#colorBPSys)"
                activeDot={{ r: 5, stroke: '#ffffff', strokeWidth: 1.5 }}
              />
              <Area
                name="Diastolic BP"
                unit=" mmHg"
                type="monotone"
                dataKey="bpDiastolic"
                stroke="#06b6d4"
                strokeWidth={2.2}
                fillOpacity={1}
                fill="url(#colorBPDia)"
                activeDot={{ r: 5, stroke: '#ffffff', strokeWidth: 1.5 }}
              />
            </>
          )}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
