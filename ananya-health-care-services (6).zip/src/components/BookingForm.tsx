import React, { useState, useEffect } from 'react';
import { SERVICES } from '../data';
import { Booking, Equipment, UserProfile } from '../types';
import { getLocalEquipmentCatalog, EQUIPMENT_UPDATED_EVENT } from '../utils/equipmentHelper';
import { 
  Calendar, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  ClipboardList, 
  CheckCircle2, 
  ArrowRight, 
  Loader2, 
  Lock, 
  UserPlus, 
  LogIn, 
  ShieldCheck, 
  Activity, 
  FileText, 
  HeartHandshake,
  AlertCircle
} from 'lucide-react';
import { motion } from 'motion/react';
import { saveToFirestore } from '../lib/firebase';
import { getStoredCurrentUser } from '../lib/auth';

interface BookingFormProps {
  preselectedItem?: string;
  preselectedType?: 'service' | 'equipment';
  onBookingSuccess: (booking: Booking) => void;
  onViewBookings: () => void;
}

export const BookingForm: React.FC<BookingFormProps> = ({
  preselectedItem = '',
  preselectedType = 'service',
  onBookingSuccess,
  onViewBookings,
}) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(getStoredCurrentUser());

  // Listen to auth state changes
  useEffect(() => {
    const handleAuthChange = () => {
      setCurrentUser(getStoredCurrentUser());
    };
    window.addEventListener('ananya_auth_changed', handleAuthChange);
    window.addEventListener('storage', handleAuthChange);
    return () => {
      window.removeEventListener('ananya_auth_changed', handleAuthChange);
      window.removeEventListener('storage', handleAuthChange);
    };
  }, []);

  // Form state
  const [formData, setFormData] = useState({
    customerName: currentUser?.name || '',
    phoneNumber: currentUser?.phone || '',
    email: currentUser?.email || '',
    type: 'service' as 'service' | 'equipment',
    itemSelected: '',
    bookingDate: '',
    address: '',
    requirementDetails: '',
  });

  // Auto-populate when user logs in
  useEffect(() => {
    if (currentUser) {
      setFormData((prev) => ({
        ...prev,
        customerName: prev.customerName || currentUser.name || '',
        phoneNumber: prev.phoneNumber || currentUser.phone || '',
        email: prev.email || currentUser.email || '',
      }));
    }
  }, [currentUser]);

  // Errors state
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successBooking, setSuccessBooking] = useState<Booking | null>(null);

  // Set today as min date
  const [minDate, setMinDate] = useState('');

  useEffect(() => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    setMinDate(`${year}-${month}-${day}`);
  }, []);

  const [equipmentList, setEquipmentList] = useState<Equipment[]>(getLocalEquipmentCatalog());

  useEffect(() => {
    const onUpdate = (e: CustomEvent) => {
      if (e.detail) setEquipmentList(e.detail);
      else setEquipmentList(getLocalEquipmentCatalog());
    };
    window.addEventListener(EQUIPMENT_UPDATED_EVENT, onUpdate as EventListener);
    return () => {
      window.removeEventListener(EQUIPMENT_UPDATED_EVENT, onUpdate as EventListener);
    };
  }, []);

  // Update form if pre-selections change
  useEffect(() => {
    if (preselectedItem) {
      setFormData((prev) => ({
        ...prev,
        type: preselectedType,
        itemSelected: preselectedItem,
      }));
    } else {
      // Set default item based on type
      const defaultItem = preselectedType === 'service' 
        ? SERVICES[0]?.title || '' 
        : equipmentList[0]?.title || '';
      setFormData((prev) => ({
        ...prev,
        type: preselectedType,
        itemSelected: defaultItem,
      }));
    }
  }, [preselectedItem, preselectedType, equipmentList]);

  // When selection type changes, update the preselected item
  const handleTypeChange = (type: 'service' | 'equipment') => {
    const defaultItem = type === 'service' 
      ? SERVICES[0]?.title || '' 
      : equipmentList[0]?.title || '';
    setFormData((prev) => ({
      ...prev,
      type,
      itemSelected: defaultItem,
    }));
    if (errors.type || errors.itemSelected) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy.type;
        delete copy.itemSelected;
        return copy;
      });
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    // Clear error
    if (errors[name]) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy[name];
        return copy;
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.customerName.trim()) {
      newErrors.customerName = 'Customer name is required';
    } else if (formData.customerName.length < 3) {
      newErrors.customerName = 'Name must be at least 3 characters long';
    }

    const phoneRegex = /^[6-9]\d{9}$/;
    if (!formData.phoneNumber) {
      newErrors.phoneNumber = 'Phone number is required';
    } else if (!phoneRegex.test(formData.phoneNumber.replace(/[\s-]/g, ''))) {
      newErrors.phoneNumber = 'Please enter a valid 10-digit Indian phone number starting with 6-9';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email) {
      newErrors.email = 'Email address is required';
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.itemSelected) {
      newErrors.itemSelected = 'Please select a service or equipment';
    }

    if (!formData.bookingDate) {
      newErrors.bookingDate = 'Please select a preferred date';
    } else {
      const selectedDate = new Date(formData.bookingDate);
      const todayDate = new Date();
      todayDate.setHours(0, 0, 0, 0);
      if (selectedDate < todayDate) {
        newErrors.bookingDate = 'Booking date cannot be in the past';
      }
    }

    if (!formData.address.trim()) {
      newErrors.address = 'Service delivery address is required';
    } else if (formData.address.length < 10) {
      newErrors.address = 'Please provide a detailed address including landmark (minimum 10 characters)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentUser) {
      setErrors({ auth: 'Authentication required. Please sign in or register to complete your booking.' });
      window.dispatchEvent(new CustomEvent('ananya_open_auth', { detail: { mode: 'signup' } }));
      return;
    }

    if (!validateForm()) {
      // Scroll to the first error
      const firstErrorKey = Object.keys(errors)[0];
      const element = document.getElementsByName(firstErrorKey)[0];
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }

    setIsSubmitting(true);

    // Simulate server request delay
    setTimeout(() => {
      const newBooking: Booking = {
        id: `ANANYA-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        customerName: (formData.customerName || currentUser.name || '').trim(),
        phoneNumber: (formData.phoneNumber || currentUser.phone || '').replace(/[\s-]/g, ''),
        email: (formData.email || currentUser.email || '').trim().toLowerCase(),
        type: formData.type,
        itemSelected: formData.itemSelected,
        bookingDate: formData.bookingDate,
        address: (formData.address || '').trim(),
        requirementDetails: (formData.requirementDetails || '').trim(),
        status: 'Pending',
        patientId: `PAT${Math.floor(1000 + Math.random() * 9000)}`,
        createdAt: new Date().toISOString(),
      };

      // Store in local storage
      const existingBookingsStr = localStorage.getItem('ananya_bookings');
      const existingBookings: Booking[] = existingBookingsStr ? JSON.parse(existingBookingsStr) : [];
      existingBookings.unshift(newBooking);
      localStorage.setItem('ananya_bookings', JSON.stringify(existingBookings));

      // Sync to Firebase Firestore
      saveToFirestore('bookings', newBooking.id, newBooking);

      setIsSubmitting(false);
      setSuccessBooking(newBooking);
      onBookingSuccess(newBooking);
    }, 1200);
  };

  const resetForm = () => {
    setFormData({
      customerName: currentUser?.name || '',
      phoneNumber: currentUser?.phone || '',
      email: currentUser?.email || '',
      type: 'service',
      itemSelected: SERVICES[0]?.title || '',
      bookingDate: '',
      address: '',
      requirementDetails: '',
    });
    setSuccessBooking(null);
    setErrors({});
  };

  const handleOpenAuth = (mode: 'login' | 'signup') => {
    window.dispatchEvent(new CustomEvent('ananya_open_auth', { detail: { mode } }));
  };

  // SUCCESS VIEW
  if (successBooking) {
    return (
      <div className="max-w-xl mx-auto bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden mt-8">
        <div className="bg-brand-navy p-8 text-center relative overflow-hidden">
          {/* Accent decoration */}
          <div className="absolute -top-16 -right-16 w-36 h-36 bg-brand-magenta/10 rounded-full blur-xl" />
          <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-brand-navy-light/20 rounded-full blur-xl" />
          
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white/10 rounded-full mb-4">
            <CheckCircle2 className="w-10 h-10 text-brand-magenta" />
          </div>
          <h2 className="font-display font-bold text-2xl text-white">Booking Registered Successfully!</h2>
          <p className="text-gray-300 text-sm mt-1 font-mono">ID: {successBooking.id}</p>
        </div>

        <div className="p-8 space-y-6">
          <p className="text-gray-600 text-sm text-center leading-relaxed font-sans">
            Thank you, <strong className="text-brand-navy">{successBooking.customerName}</strong>! Our healthcare coordinator will contact you on <strong className="text-brand-navy">{successBooking.phoneNumber}</strong> within <strong className="text-brand-magenta">1 to 2 hours</strong> to confirm staff allocation and shift schedules.
          </p>

          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 space-y-3 text-sm font-sans">
            <div className="flex justify-between border-b border-gray-200/60 pb-2">
              <span className="text-gray-500">Requirement Type:</span>
              <span className="font-bold text-brand-navy capitalize">{successBooking.type}</span>
            </div>
            <div className="flex justify-between border-b border-gray-200/60 pb-2">
              <span className="text-gray-500">Selected Item:</span>
              <span className="font-bold text-brand-navy">{successBooking.itemSelected}</span>
            </div>
            <div className="flex justify-between border-b border-gray-200/60 pb-2">
              <span className="text-gray-500">Preferred Date:</span>
              <span className="font-bold text-brand-navy">{successBooking.bookingDate}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Delivery Address:</span>
              <span className="font-bold text-brand-navy text-right max-w-[60%] truncate" title={successBooking.address}>
                {successBooking.address}
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={onViewBookings}
              className="flex-1 bg-brand-navy hover:bg-brand-navy-light text-white font-bold py-3.5 px-6 rounded-xl transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer text-sm"
            >
              View My Bookings <ArrowRight className="w-4 h-4 text-brand-magenta" />
            </button>
            <button
              onClick={resetForm}
              className="flex-1 border border-gray-200 hover:bg-gray-50 text-gray-700 font-bold py-3.5 px-6 rounded-xl transition-all cursor-pointer text-sm"
            >
              Register Another Booking
            </button>
          </div>
        </div>
      </div>
    );
  }

  // AUTHENTICATION GUARD (User not logged in)
  if (!currentUser) {
    return (
      <div className="max-w-4xl mx-auto my-6">
        <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
          {/* Top Banner */}
          <div className="bg-brand-navy text-white p-8 md:p-12 relative overflow-hidden text-center">
            <div className="absolute top-0 right-0 w-64 h-64 bg-brand-magenta/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-navy-light/30 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 max-w-2xl mx-auto space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/10 text-brand-magenta border border-white/10 shadow-inner">
                <Lock className="w-8 h-8" />
              </div>
              <h2 className="font-display font-black text-2xl sm:text-3xl md:text-4xl text-white">
                Account Required for Healthcare Booking
              </h2>
              <p className="text-gray-300 text-sm sm:text-base leading-relaxed">
                To guarantee clinical safety, staff ID verification, daily vitals tracking, and family access, you must be logged in to book nursing care or medical equipment.
              </p>

              {/* Preselected Item Tag */}
              {preselectedItem && (
                <div className="inline-flex items-center gap-2 bg-brand-magenta/20 border border-brand-magenta/30 text-white px-4 py-2 rounded-xl text-xs font-semibold mt-2">
                  <ClipboardList className="w-4 h-4 text-brand-magenta-light" />
                  <span>
                    Your Selection: <strong className="text-brand-magenta-light">{preselectedItem}</strong> ({preselectedType})
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Action CTAs & Highlights */}
          <div className="p-8 md:p-12 space-y-10">
            {/* Direct Action Buttons */}
            <div className="max-w-md mx-auto flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => handleOpenAuth('signup')}
                id="btn-booking-register"
                className="flex-1 py-4 px-6 bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold rounded-2xl shadow-lg shadow-brand-magenta/25 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
              >
                <UserPlus className="w-4 h-4" />
                <span>Create User Account (Register)</span>
              </button>

              <button
                onClick={() => handleOpenAuth('login')}
                id="btn-booking-login"
                className="flex-1 py-4 px-6 bg-brand-navy hover:bg-brand-navy-light text-white font-bold rounded-2xl shadow-md active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In to Existing Account</span>
              </button>
            </div>

            {/* Why Registration is Essential Grid */}
            <div className="border-t border-gray-100 pt-8">
              <h3 className="text-center font-display font-bold text-lg text-brand-navy mb-6">
                Why is user registration mandatory for Ananya Health Care bookings?
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex gap-4 p-4 rounded-2xl bg-slate-50 border border-gray-100">
                  <div className="w-10 h-10 rounded-xl bg-brand-magenta/10 text-brand-magenta flex items-center justify-center shrink-0">
                    <Activity className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-brand-navy">Live Patient Vitals Tracking</h4>
                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                      Your assigned caregiver logs SPO2, Blood Pressure, Pulse, and Glucose readings directly into your patient portal.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 p-4 rounded-2xl bg-slate-50 border border-gray-100">
                  <div className="w-10 h-10 rounded-xl bg-brand-navy/10 text-brand-navy flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-brand-navy">Verified Caregivers & Shifts</h4>
                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                      Every attending nurse and medical attendant is KYC & police-verified with logged GPS duty timestamps.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 p-4 rounded-2xl bg-slate-50 border border-gray-100">
                  <div className="w-10 h-10 rounded-xl bg-green-50 text-green-700 flex items-center justify-center shrink-0">
                    <HeartHandshake className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-brand-navy">Family Health Portal Access</h4>
                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                      Stay connected with remote relatives. Share real-time patient recovery updates securely.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 p-4 rounded-2xl bg-slate-50 border border-gray-100">
                  <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-brand-navy">Digital Receipts & Invoices</h4>
                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                      Download tax invoices, medical equipment calibration certificates, and rental agreements seamlessly.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Emergency Contact Strip */}
            <div className="text-center bg-brand-magenta/5 border border-brand-magenta/15 p-4 rounded-2xl text-xs text-brand-navy">
              <span>Need immediate emergency hospital assistance? Call 24/7 Coordinator: </span>
              <strong className="text-brand-magenta font-bold ml-1">+91 77349 31740 / +91 89557 25234</strong>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ACTIVE LOGGED-IN BOOKING FORM
  return (
    <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden grid grid-cols-1 lg:grid-cols-12 max-w-5xl mx-auto">
      
      {/* Side Info Panel */}
      <div className="lg:col-span-5 bg-brand-navy text-white p-8 md:p-12 flex flex-col justify-between relative overflow-hidden">
        {/* Accent graphics */}
        <div className="absolute -top-24 -left-24 w-60 h-60 bg-brand-magenta/5 rounded-full blur-3xl" />
        <div className="absolute bottom-10 -right-20 w-44 h-44 bg-brand-navy-light/40 rounded-full blur-2xl" />

        <div className="relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 bg-brand-magenta/10 text-brand-magenta-light px-3 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider border border-brand-magenta/20">
            <ClipboardList className="w-3.5 h-3.5" /> Verified User Booking
          </div>
          <h2 className="font-display font-bold text-3xl md:text-4xl text-white tracking-tight leading-tight">
            Schedule Staff or Equipment
          </h2>
          <p className="text-gray-300 text-sm leading-relaxed font-sans">
            Please fill out this secure form. Upon submission, your request is logged directly under your patient profile and dispatched to our staff coordinator portal.
          </p>

          <div className="space-y-4 pt-4 text-xs font-sans text-gray-300 border-t border-white/10">
            <div className="flex gap-3">
              <CheckCircle2 className="w-5 h-5 text-brand-magenta shrink-0 mt-0.5" />
              <p>Certified Registered Nursing staff matched specifically to clinical requirements.</p>
            </div>
            <div className="flex gap-3">
              <CheckCircle2 className="w-5 h-5 text-brand-magenta shrink-0 mt-0.5" />
              <p>Thorough sanitization and testing on all medical equipment rentals before dispatch.</p>
            </div>
            <div className="flex gap-3">
              <CheckCircle2 className="w-5 h-5 text-brand-magenta shrink-0 mt-0.5" />
              <p>24/7 dedicated escalation support desk for long-term home packages.</p>
            </div>
          </div>
        </div>

        <div className="relative z-10 pt-10 border-t border-white/10 mt-8">
          <p className="text-xs text-gray-400">Immediate Phone Assistance:</p>
          <p className="font-display font-bold text-lg text-brand-magenta mt-1">7734931740 / 8955725234</p>
          <p className="text-xs text-gray-300 mt-1">ananyahealthcare1@gmail.com</p>
        </div>
      </div>

      {/* Actual Form Panel */}
      <form onSubmit={handleSubmit} className="lg:col-span-7 p-8 md:p-12 space-y-6 font-sans">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-4">
          <div>
            <h3 className="font-display font-bold text-2xl text-brand-navy">Registration Form</h3>
            <p className="text-xs text-gray-500 mt-0.5">Please provide patient and service details</p>
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-50 border border-green-200 text-green-800 rounded-full text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-green-600" />
            <span>Verified: {currentUser.name || currentUser.email}</span>
          </div>
        </div>

        {errors.auth && (
          <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errors.auth}</span>
          </div>
        )}
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {/* Customer Name */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-brand-magenta" /> Patient / Customer Name
            </label>
            <div className="relative">
              <input
                type="text"
                name="customerName"
                value={formData.customerName}
                onChange={handleInputChange}
                placeholder="Full Name of patient/guardian"
                className={`w-full bg-gray-50 border ${errors.customerName ? 'border-red-400 focus:ring-red-100' : 'border-gray-200 focus:border-brand-magenta focus:ring-brand-magenta/10'} px-4 py-3 rounded-xl text-sm transition-all focus:outline-none focus:ring-4`}
              />
            </div>
            {errors.customerName && <p className="text-red-500 text-xs font-medium">{errors.customerName}</p>}
          </div>

          {/* Phone Number */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-brand-magenta" /> Contact Phone Number
            </label>
            <input
              type="tel"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleInputChange}
              placeholder="e.g. 7734931740"
              className={`w-full bg-gray-50 border ${errors.phoneNumber ? 'border-red-400 focus:ring-red-100' : 'border-gray-200 focus:border-brand-magenta focus:ring-brand-magenta/10'} px-4 py-3 rounded-xl text-sm transition-all focus:outline-none focus:ring-4`}
            />
            {errors.phoneNumber && <p className="text-red-500 text-xs font-medium">{errors.phoneNumber}</p>}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {/* Email */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-brand-magenta" /> Email Address
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              placeholder="e.g. ananya@gmail.com"
              className={`w-full bg-gray-50 border ${errors.email ? 'border-red-400 focus:ring-red-100' : 'border-gray-200 focus:border-brand-magenta focus:ring-brand-magenta/10'} px-4 py-3 rounded-xl text-sm transition-all focus:outline-none focus:ring-4`}
            />
            {errors.email && <p className="text-red-500 text-xs font-medium">{errors.email}</p>}
          </div>

          {/* Booking Date */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-brand-magenta" /> Preferred Start Date
            </label>
            <input
              type="date"
              name="bookingDate"
              min={minDate}
              value={formData.bookingDate}
              onChange={handleInputChange}
              className={`w-full bg-gray-50 border ${errors.bookingDate ? 'border-red-400 focus:ring-red-100' : 'border-gray-200 focus:border-brand-magenta focus:ring-brand-magenta/10'} px-4 py-3 rounded-xl text-sm transition-all focus:outline-none focus:ring-4`}
            />
            {errors.bookingDate && <p className="text-red-500 text-xs font-medium">{errors.bookingDate}</p>}
          </div>
        </div>

        {/* Selection Type (Tabs style inside form) */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
            What do you need to book?
          </label>
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => handleTypeChange('service')}
              className={`py-3 px-4 rounded-xl text-sm font-semibold transition-all border flex items-center justify-center gap-2 cursor-pointer ${
                formData.type === 'service'
                  ? 'bg-brand-navy text-white border-brand-navy shadow-md shadow-brand-navy/10'
                  : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
              }`}
            >
              <User className={`w-4 h-4 ${formData.type === 'service' ? 'text-brand-magenta' : 'text-gray-400'}`} />
              Nursing / Care Staff
            </button>
            <button
              type="button"
              onClick={() => handleTypeChange('equipment')}
              className={`py-3 px-4 rounded-xl text-sm font-semibold transition-all border flex items-center justify-center gap-2 cursor-pointer ${
                formData.type === 'equipment'
                  ? 'bg-brand-navy text-white border-brand-navy shadow-md shadow-brand-navy/10'
                  : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
              }`}
            >
              <Calendar className={`w-4 h-4 ${formData.type === 'equipment' ? 'text-brand-magenta' : 'text-gray-400'}`} />
              Medical Equipment
            </button>
          </div>
        </div>

        {/* Specific Requirement Dropdown */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1.5">
            <ClipboardList className="w-3.5 h-3.5 text-brand-magenta" /> Select Specific {formData.type === 'service' ? 'Service' : 'Equipment'}
          </label>
          <select
            name="itemSelected"
            value={formData.itemSelected}
            onChange={handleInputChange}
            className="w-full bg-gray-50 border border-gray-200 focus:border-brand-magenta focus:ring-brand-magenta/10 px-4 py-3 rounded-xl text-sm focus:outline-none focus:ring-4 focus:bg-white"
          >
            {formData.type === 'service'
              ? SERVICES.map((srv) => (
                  <option key={srv.id} value={srv.title}>
                    {srv.title} ({srv.rates})
                  </option>
                ))
              : equipmentList.map((eq) => (
                  <option key={eq.id} value={eq.title}>
                    {eq.title} {eq.rentalPrice ? `(Rent: ${eq.rentalPrice})` : `(Buy: ${eq.purchasePrice})`}
                  </option>
                ))}
          </select>
        </div>

        {/* Address */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-brand-magenta" /> Detailed Service Address
          </label>
          <textarea
            name="address"
            rows={3}
            value={formData.address}
            onChange={handleInputChange}
            placeholder="Please enter the exact house address, street, ward number, area, landmark, and pincode..."
            className={`w-full bg-gray-50 border ${errors.address ? 'border-red-400 focus:ring-red-100' : 'border-gray-200 focus:border-brand-magenta focus:ring-brand-magenta/10'} px-4 py-3 rounded-xl text-sm transition-all focus:outline-none focus:ring-4 focus:bg-white resize-none`}
          />
          {errors.address && <p className="text-red-500 text-xs font-medium">{errors.address}</p>}
        </div>

        {/* Specific Instructions / Description notes */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
            Special Requirements / Patient Condition (Optional)
          </label>
          <textarea
            name="requirementDetails"
            rows={2}
            value={formData.requirementDetails}
            onChange={handleInputChange}
            placeholder="e.g., patient is semi-conscious post-stroke, needs catheterization support, prefers female nurse, etc."
            className="w-full bg-gray-50 border border-gray-200 focus:border-brand-magenta focus:ring-brand-magenta/10 px-4 py-3 rounded-xl text-sm focus:outline-none focus:ring-4 focus:bg-white resize-none"
          />
        </div>

        {/* Submit button */}
        <button
          type="submit"
          id="btn-submit-booking"
          disabled={isSubmitting}
          className="w-full bg-brand-magenta hover:bg-brand-magenta-light disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-bold py-4 px-6 rounded-xl transition-all shadow-lg shadow-brand-magenta/20 hover:shadow-brand-magenta/30 flex items-center justify-center gap-2 active:scale-98 cursor-pointer text-base mt-2"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Logging Secure Booking...
            </>
          ) : (
            <>
              <CheckCircle2 className="w-5 h-5 text-white" />
              Register Healthcare Booking
            </>
          )}
        </button>
      </form>
    </div>
  );
};
