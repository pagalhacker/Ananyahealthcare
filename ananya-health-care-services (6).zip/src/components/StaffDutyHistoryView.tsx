import React, { useState } from 'react';
import { PatientDutyRecord } from '../utils/dutyHistoryHelper';
import { 
  User, 
  MapPin, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Activity, 
  Search, 
  FileText, 
  Sparkles, 
  ChevronDown, 
  ChevronUp, 
  Building2, 
  BadgeCheck, 
  ShieldCheck, 
  Phone, 
  Stethoscope, 
  HeartHandshake
} from 'lucide-react';
import { PatientVitalsWidget } from './PatientVitalsWidget';

interface StaffDutyHistoryViewProps {
  duties: PatientDutyRecord[];
  staffName: string;
  staffId: string;
  staffRole: string;
  onRefresh?: () => void;
}

export const StaffDutyHistoryView: React.FC<StaffDutyHistoryViewProps> = ({
  duties,
  staffName,
  staffId,
  staffRole,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Completed' | 'Ongoing'>('All');
  const [expandedDutyId, setExpandedDutyId] = useState<string | null>(null);
  const [selectedVitalsPatient, setSelectedVitalsPatient] = useState<{ id: string; name: string } | null>(null);

  // Filter duties
  const filteredDuties = duties.filter((d) => {
    const matchesSearch = 
      d.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.locationAddress.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.locality.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.serviceTitle.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'All' || d.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Calculate overall metrics
  const totalPatientsServed = duties.length;
  const totalDaysOnDuty = duties.reduce((acc, d) => acc + (d.totalDays || 0), 0);
  const totalShiftsLogged = duties.reduce((acc, d) => acc + (d.totalShifts || 0), 0);
  const totalHoursWorked = duties.reduce((acc, d) => acc + (d.totalHours || 0), 0);

  const toggleExpand = (dutyId: string) => {
    setExpandedDutyId(expandedDutyId === dutyId ? null : dutyId);
  };

  return (
    <div className="space-y-6 font-sans">
      
      {/* Header and Summary Bar */}
      <div className="bg-gradient-to-br from-brand-navy to-brand-navy-light text-white p-6 sm:p-8 rounded-3xl shadow-lg border border-white/10 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-brand-magenta/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/10 pb-6 mb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-brand-magenta uppercase tracking-wider">
              <BadgeCheck className="w-4 h-4 text-brand-magenta" />
              <span>Official Staff Clinical Record</span>
            </div>
            <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
              Patient Duty & Attendance History
            </h2>
            <p className="text-xs sm:text-sm text-gray-300">
              मरीज़ सेवा इतिहास — Complete log of assigned patients, duty locations, duration in days, and daily shift attendance.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/10 text-right">
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">Staff Profile</span>
            <span className="font-bold text-white text-sm">{staffName}</span>
            <span className="text-[11px] font-mono text-brand-magenta-light font-bold block">{staffId} • {staffRole}</span>
          </div>
        </div>

        {/* 4 Core Summary KPI Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 relative z-10">
          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
            <span className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider block">Patients Served</span>
            <p className="text-2xl sm:text-3xl font-extrabold text-white mt-0.5">{totalPatientsServed}</p>
            <span className="text-[10px] text-emerald-400 font-medium">100% Verified</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
            <span className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider block">Total Days on Duty</span>
            <p className="text-2xl sm:text-3xl font-extrabold text-brand-magenta-light mt-0.5">{totalDaysOnDuty} Days</p>
            <span className="text-[10px] text-gray-300 font-medium">Home & Clinical Visits</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
            <span className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider block">Total Shifts Logged</span>
            <p className="text-2xl sm:text-3xl font-extrabold text-white mt-0.5">{totalShiftsLogged}</p>
            <span className="text-[10px] text-emerald-400 font-medium">GPS Authenticated</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
            <span className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider block">Total Duty Hours</span>
            <p className="text-2xl sm:text-3xl font-extrabold text-brand-magenta-light mt-0.5">{totalHoursWorked} hrs</p>
            <span className="text-[10px] text-gray-300 font-medium">Cumulative Time</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-gray-200 shadow-sm flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-3">
        <div className="relative flex-grow max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search by Patient Name, Location (Jaipur, Kota, Mansarovar), or ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-gray-50 border border-gray-200 pl-10 pr-4 py-2.5 rounded-xl text-xs font-medium focus:outline-none focus:border-brand-magenta focus:ring-2 focus:ring-brand-magenta/10"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500 font-medium hidden md:inline">Status:</span>
          {(['All', 'Completed', 'Ongoing'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                statusFilter === st
                  ? 'bg-brand-magenta text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Patient Duty Records List */}
      {filteredDuties.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-dashed border-gray-200 p-8 space-y-3">
          <div className="w-14 h-14 bg-gray-100 text-gray-400 rounded-2xl flex items-center justify-center mx-auto">
            <HeartHandshake className="w-7 h-7" />
          </div>
          <h3 className="font-display font-bold text-lg text-brand-navy">No Patient Duties Matching Criteria</h3>
          <p className="text-xs text-gray-500 max-w-md mx-auto">
            Try adjusting your search terms or filters to find specific patient duty records.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredDuties.map((duty) => {
            const isExpanded = expandedDutyId === duty.id;
            return (
              <div
                key={duty.id}
                className="bg-white rounded-3xl border border-gray-200 shadow-sm hover:shadow-md transition-all overflow-hidden"
              >
                {/* Main Card Header / Quick Overview */}
                <div className="p-5 sm:p-6 border-b border-gray-100">
                  <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
                    
                    {/* Patient & Service Title */}
                    <div className="space-y-1.5 flex-grow">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-bold uppercase tracking-wider bg-brand-magenta/10 text-brand-magenta px-2.5 py-0.5 rounded-full">
                          {duty.serviceTitle}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                            duty.status === 'Completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {duty.status === 'Completed' ? '✓ Completed Duty' : '● Ongoing Active Shift'}
                        </span>
                        <span className="text-[11px] font-mono font-bold bg-brand-navy/5 text-brand-navy px-2 py-0.5 rounded border border-gray-200">
                          ID: {duty.patientId}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <h3 className="font-display font-extrabold text-xl text-brand-navy flex items-center gap-2">
                          <User className="w-5 h-5 text-brand-magenta" />
                          <span>{duty.patientName}</span>
                        </h3>
                        {duty.patientAge && (
                          <span className="text-xs text-gray-500 font-medium">
                            ({duty.patientAge} Yrs, {duty.patientGender || 'Patient'})
                          </span>
                        )}
                      </div>

                      {/* Location & Address Badge */}
                      <p className="text-xs text-gray-600 flex items-start gap-1.5 pt-0.5">
                        <MapPin className="w-4 h-4 text-brand-magenta shrink-0 mt-0.5" />
                        <span>
                          <strong className="text-brand-navy">{duty.locality}, {duty.city}:</strong> {duty.locationAddress}
                        </span>
                      </p>
                    </div>

                    {/* Duty Duration & Days Pill (Prominently displayed) */}
                    <div className="flex flex-wrap sm:flex-col items-start sm:items-end gap-2 shrink-0 bg-slate-50 sm:bg-transparent p-3 sm:p-0 rounded-2xl border border-gray-100 sm:border-none w-full sm:w-auto">
                      <div className="bg-brand-magenta text-white px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 shadow-md shadow-brand-magenta/20">
                        <Calendar className="w-4 h-4 text-white" />
                        <span>ड्यूटी अवधि: {duty.totalDays} Days ({duty.totalHours} hrs)</span>
                      </div>

                      <div className="text-left sm:text-right text-xs text-gray-500">
                        <span className="block font-bold text-brand-navy">
                          📅 {duty.startDate} to {duty.endDate}
                        </span>
                        <span className="text-[11px] text-gray-400">
                          {duty.totalShifts} Shifts Logged
                        </span>
                      </div>
                    </div>

                  </div>

                  {/* Clinical Requirements Snippet */}
                  {duty.clinicalRequirement && (
                    <div className="mt-4 p-3 bg-brand-magenta/5 rounded-xl border border-brand-magenta/10 text-xs text-brand-navy leading-relaxed">
                      <strong className="text-brand-magenta block mb-0.5">Clinical Care & Protocol:</strong>
                      {duty.clinicalRequirement}
                    </div>
                  )}

                  {/* Highlights Bullet points */}
                  {duty.dutyHighlights && duty.dutyHighlights.length > 0 && (
                    <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-gray-600">
                      {duty.dutyHighlights.map((hl, idx) => (
                        <div key={idx} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{hl}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Action Bar */}
                  <div className="mt-4 pt-4 border-t border-gray-100 flex flex-wrap justify-between items-center gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedVitalsPatient({ id: duty.patientId, name: duty.patientName })}
                        className="px-3.5 py-1.5 bg-brand-magenta/10 hover:bg-brand-magenta text-brand-magenta hover:text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                      >
                        <Activity className="w-3.5 h-3.5" /> View Patient Vitals Chart
                      </button>

                      {duty.patientPhone && (
                        <a
                          href={`tel:${duty.patientPhone.replace(/\D/g, '')}`}
                          className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
                        >
                          <Phone className="w-3 h-3 text-brand-magenta" /> {duty.patientPhone}
                        </a>
                      )}
                    </div>

                    <button
                      onClick={() => toggleExpand(duty.id)}
                      className="px-3.5 py-1.5 bg-gray-100 hover:bg-gray-200 text-brand-navy rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <span>{isExpanded ? 'Hide Daily Attendance Shift Logs' : `View Daily Logs (${duty.dailyLogs.length})`}</span>
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Expandable Daily Shift Attendance Log Table */}
                {isExpanded && (
                  <div className="p-5 bg-gray-50/80 border-t border-gray-100 space-y-3">
                    <h4 className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-brand-magenta" />
                      <span>Daily Shift Logs & Attendance Timestamps ({duty.totalDays} Days)</span>
                    </h4>

                    {duty.dailyLogs.length === 0 ? (
                      <p className="text-xs text-gray-500 italic">No specific sub-logs recorded for this duty.</p>
                    ) : (
                      <div className="overflow-x-auto bg-white rounded-2xl border border-gray-200 shadow-sm">
                        <table className="w-full text-left text-xs">
                          <thead>
                            <tr className="bg-gray-100/70 text-gray-600 uppercase font-bold border-b border-gray-200 text-[11px]">
                              <th className="py-2.5 px-3">Shift Date</th>
                              <th className="py-2.5 px-3">Check-In</th>
                              <th className="py-2.5 px-3">Check-Out</th>
                              <th className="py-2.5 px-3">Hours</th>
                              <th className="py-2.5 px-3">Location & GPS Status</th>
                              <th className="py-2.5 px-3">Shift Action Notes & Vitals</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                            {duty.dailyLogs.map((log) => {
                              const inTime = log.checkInTime ? new Date(log.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'N/A';
                              const outTime = log.checkOutTime ? new Date(log.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'In Progress';
                              return (
                                <tr key={log.id} className="hover:bg-gray-50/80">
                                  <td className="py-2.5 px-3 font-bold text-brand-navy whitespace-nowrap">
                                    {log.date}
                                  </td>
                                  <td className="py-2.5 px-3 font-mono font-bold text-emerald-700">
                                    {inTime}
                                  </td>
                                  <td className="py-2.5 px-3 font-mono font-bold text-gray-700">
                                    {outTime}
                                  </td>
                                  <td className="py-2.5 px-3 font-bold text-brand-navy">
                                    {log.shiftHours} hrs
                                  </td>
                                  <td className="py-2.5 px-3">
                                    <span className="block truncate max-w-xs text-gray-800 font-medium">
                                      {log.location}
                                    </span>
                                    <span className="inline-flex items-center gap-1 text-[10px] text-emerald-700 font-bold">
                                      ✓ GPS Verified
                                    </span>
                                  </td>
                                  <td className="py-2.5 px-3 text-gray-600 max-w-sm">
                                    <p className="truncate" title={log.actionNotes}>
                                      {log.actionNotes}
                                    </p>
                                    {log.vitalsRecorded && (
                                      <span className="inline-block mt-0.5 text-[10px] bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded font-bold">
                                        Vitals Logged
                                      </span>
                                    )}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}

              </div>
            );
          })}
        </div>
      )}

      {/* Patient Vitals Modal */}
      {selectedVitalsPatient && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-3xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto border border-gray-200">
            <div className="flex justify-between items-center border-b border-gray-100 pb-3">
              <div>
                <h3 className="font-display font-extrabold text-lg text-brand-navy">
                  Clinical Vitals: {selectedVitalsPatient.name}
                </h3>
                <span className="text-xs font-mono font-bold text-brand-magenta">
                  Patient ID: {selectedVitalsPatient.id}
                </span>
              </div>
              <button
                onClick={() => setSelectedVitalsPatient(null)}
                className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 font-bold text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <PatientVitalsWidget 
              patientId={selectedVitalsPatient.id} 
              patientName={selectedVitalsPatient.name}
              allowLogging={true}
            />

            <div className="pt-2 text-right">
              <button
                onClick={() => setSelectedVitalsPatient(null)}
                className="px-5 py-2 bg-brand-navy text-white text-xs font-bold rounded-xl hover:bg-brand-navy-light cursor-pointer shadow-md"
              >
                Close Chart
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
