import React, { useState, useEffect } from 'react';
import { Booking } from '../types';
import { PatientVitalsWidget } from './PatientVitalsWidget';
import { ensurePatientIdsOnBookings } from '../utils/vitalsHelper';
import { Heart, Search, Calendar, MapPin, Shield, HelpCircle, Activity, UserCheck, AlertCircle } from 'lucide-react';

export const FamilyPortal: React.FC = () => {
  const [patientIdInput, setPatientIdInput] = useState<string>('');
  const [searchedId, setSearchedId] = useState<string>('');
  const [matchedBooking, setMatchedBooking] = useState<Booking | null>(null);
  const [allBookings, setAllBookings] = useState<Booking[]>([]);
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Preloaded sample bookings to guarantee the portal always resolves PAT-1001 to PAT-1004
  const sampleBookings: Booking[] = [
    {
      id: 'ANANYA-1718290000-451',
      customerName: 'Aarav Singhal',
      phoneNumber: '9829012345',
      email: 'aarav.singhal@gmail.com',
      type: 'service',
      itemSelected: 'Home Nursing Care',
      bookingDate: '2026-07-15',
      address: 'Plot No. 12, Sector 4, Malviya Nagar, Jaipur, RJ',
      requirementDetails: 'Post-op cardiac recovery, requires twice-daily blood sugar checks and catheter flushing.',
      status: 'Confirmed',
      createdAt: '2026-07-12T09:30:00.000Z',
    },
    {
      id: 'ANANYA-1718291000-882',
      customerName: 'Rukmani Devi',
      phoneNumber: '8005512345',
      email: 'devi.ruk@yahoo.co.in',
      type: 'service',
      itemSelected: 'Elderly Care Services',
      bookingDate: '2026-07-20',
      address: 'H.No. 45-B, Vaishali Nagar, near Hanuman Temple, Jaipur, RJ',
      requirementDetails: 'Alzheimer care. Patient wanders around, needs highly attentive 24-hour female caretaker.',
      status: 'Pending',
      createdAt: '2026-07-13T01:15:00.000Z',
    },
    {
      id: 'ANANYA-1718292000-119',
      customerName: 'Vinay Rathore',
      phoneNumber: '7014498765',
      email: 'vinay_rathore77@gmail.com',
      type: 'equipment',
      itemSelected: 'Oxygen Concentrator (5L / 10L)',
      bookingDate: '2026-07-14',
      address: '245, Mansarovar Scheme, Jaipur, RJ - 302020',
      requirementDetails: 'Rental request for 1 month. Patient is COPD chronic bronchitis sufferer.',
      status: 'Confirmed',
      createdAt: '2026-07-12T18:45:00.000Z',
    },
    {
      id: 'ANANYA-1718293000-302',
      customerName: 'Kiran Sharma',
      phoneNumber: '9414054321',
      email: 'kiran.sharma@hotmail.com',
      type: 'equipment',
      itemSelected: 'Premium Foldable Wheelchair',
      bookingDate: '2026-07-18',
      address: 'C-31, Jawahar Nagar, Jaipur, RJ',
      requirementDetails: 'Short term rental for grandmother visiting Jaipur for sightseeing.',
      status: 'Cancelled',
      createdAt: '2026-07-11T14:22:00.000Z',
    },
  ];

  // Load bookings from localStorage to resolve IDs
  const loadBookings = () => {
    const stored = localStorage.getItem('ananya_bookings');
    let bookingsParsed: Booking[] = [];
    if (stored) {
      bookingsParsed = JSON.parse(stored);
    } else {
      bookingsParsed = sampleBookings;
      localStorage.setItem('ananya_bookings', JSON.stringify(bookingsParsed));
    }
    const withIds = ensurePatientIdsOnBookings(bookingsParsed);
    setAllBookings(withIds);
  };

  useEffect(() => {
    loadBookings();
  }, []);

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg('');
    setMatchedBooking(null);

    const inputCleaned = patientIdInput.trim().toUpperCase().replace(/[\s-]/g, '');
    if (!inputCleaned) {
      setErrorMsg('Please enter a valid Patient ID (e.g. PAT1001).');
      return;
    }

    // Find patient in confirmed or pending bookings (support both PAT1001 and legacy PAT-1001)
    const found = allBookings.find((b) => {
      const pId = (b.patientId || '').toUpperCase().replace(/[\s-]/g, '');
      return pId === inputCleaned || pId.includes(inputCleaned);
    });

    if (found) {
      setMatchedBooking(found);
      setSearchedId(found.patientId ? found.patientId.replace('PAT-', 'PAT') : inputCleaned);
    } else {
      setErrorMsg(`No active patient care records found matching ID "${patientIdInput}".`);
    }
  };

  return (
    <div className="space-y-8 py-6 max-w-5xl mx-auto font-sans">
      {/* Editorial Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/5 border border-brand-magenta/10 px-3.5 py-1.5 rounded-full">
          Secure Family Portal
        </span>
        <h2 className="font-display font-black text-3xl md:text-4xl text-brand-navy">
          Ananya Family Vitals & Progress Tracker
        </h2>
        <p className="text-sm text-gray-500 leading-relaxed">
          Monitor your loved one's vital statistics, clinical charts, and daily care history using the unique Patient ID generated by our medical administrators.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Side: Lookup & Information */}
        <div className="lg:col-span-5 space-y-6">
          {/* Lookup Panel */}
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-xl space-y-4">
            <h3 className="font-display font-bold text-lg text-brand-navy flex items-center gap-2">
              <Search className="w-5 h-5 text-brand-magenta" /> Search Patient Record
            </h3>
            
            <form onSubmit={handleSearch} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-gray-400 uppercase">Enter Patient ID</label>
                <div className="relative mt-1">
                  <input
                    type="text"
                    placeholder="e.g. PAT1001"
                    value={patientIdInput}
                    onChange={(e) => setPatientIdInput(e.target.value)}
                    className="w-full bg-slate-50 border border-gray-250 px-4 py-3 rounded-2xl focus:outline-none focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5 font-mono font-bold text-brand-navy tracking-wider"
                  />
                </div>
              </div>

              {errorMsg && (
                <div className="bg-red-50 border border-red-200 text-red-800 text-xs py-2 px-3 rounded-xl flex items-center gap-1.5 font-semibold">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  {errorMsg}
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold py-3 px-4 rounded-2xl shadow-lg shadow-brand-magenta/10 hover:shadow-brand-magenta/20 active:scale-95 transition-all duration-150 cursor-pointer flex justify-center items-center gap-2 text-sm"
              >
                <Search className="w-4 h-4" /> Verify & Access Portal
              </button>
            </form>
          </div>

          {/* Guide Card */}
          <div className="bg-brand-navy text-white p-6 rounded-3xl space-y-4 shadow-xl">
            <h4 className="font-display font-bold text-base flex items-center gap-2 text-white">
              <HelpCircle className="w-5 h-5 text-brand-magenta shrink-0" /> Portal Instructions
            </h4>
            <div className="space-y-3 text-xs text-gray-300 leading-relaxed font-sans">
              <div className="flex gap-2.5 items-start">
                <span className="w-5 h-5 bg-white/10 text-brand-magenta rounded-full flex items-center justify-center font-bold font-mono text-[10px] shrink-0 mt-0.5">1</span>
                <p>When you book care staff (Nursing/Attendant) or equipment, our coordinators assign a secure unique <strong>Patient ID (PAT1234 / PATXXXX)</strong>.</p>
              </div>
              <div className="flex gap-2.5 items-start">
                <span className="w-5 h-5 bg-white/10 text-brand-magenta rounded-full flex items-center justify-center font-bold font-mono text-[10px] shrink-0 mt-0.5">2</span>
                <p>Nurses and clinical staff use their secure workspace to record daily vitals like <strong>Temperature, Blood Pressure</strong>, and <strong>Pulse</strong> on your behalf.</p>
              </div>
              <div className="flex gap-2.5 items-start">
                <span className="w-5 h-5 bg-white/10 text-brand-magenta rounded-full flex items-center justify-center font-bold font-mono text-[10px] shrink-0 mt-0.5">3</span>
                <p>Telemetry metrics are plotted in real time using <strong>Recharts</strong>, allowing immediate detection of health trends or progress anomalies.</p>
              </div>
            </div>
            <div className="pt-3 border-t border-white/10 flex items-center gap-2 text-[11px] text-gray-400">
              <Shield className="w-4 h-4 text-brand-magenta shrink-0" />
              <span>HIPAA Compliant & HIPAA Secure logs</span>
            </div>
          </div>
        </div>

        {/* Right Side: Interactive Vitals Tracking Display */}
        <div className="lg:col-span-7">
          {matchedBooking ? (
            <div className="space-y-6">
              {/* Patient Profile Quick Summary */}
              <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-xl space-y-4">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-4 border-b border-gray-100">
                  <div>
                    <span className="text-[10px] bg-brand-navy text-white font-extrabold px-2.5 py-1 rounded-full tracking-wider font-mono uppercase">
                      Active Patient File
                    </span>
                    <h3 className="font-display font-black text-xl text-brand-navy mt-1.5 flex items-center gap-1.5">
                      <UserCheck className="w-5 h-5 text-brand-magenta" /> {matchedBooking.customerName}
                    </h3>
                  </div>
                  <div className="bg-emerald-50 text-emerald-800 font-bold text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-emerald-100 self-start sm:self-center">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    Care Active
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
                  <div className="space-y-1 bg-slate-50 p-3 rounded-xl border border-gray-150">
                    <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Primary Care Package</span>
                    <p className="font-bold text-brand-navy truncate">{matchedBooking.itemSelected}</p>
                  </div>
                  <div className="space-y-1 bg-slate-50 p-3 rounded-xl border border-gray-150">
                    <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Start Date</span>
                    <p className="font-bold text-brand-navy flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-brand-magenta" /> {matchedBooking.bookingDate}
                    </p>
                  </div>
                  <div className="col-span-1 sm:col-span-2 space-y-1 bg-slate-50 p-3 rounded-xl border border-gray-150">
                    <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Deploy Location / Address</span>
                    <p className="font-semibold text-brand-navy flex items-start gap-1 leading-relaxed text-xs">
                      <MapPin className="w-3.5 h-3.5 text-brand-magenta shrink-0 mt-0.5" />
                      {matchedBooking.address}
                    </p>
                  </div>
                </div>
              </div>

              {/* Patient Vitals Tracker Box */}
              <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-xl space-y-4">
                <h3 className="font-display font-bold text-lg text-brand-navy flex items-center gap-2">
                  <Activity className="w-5 h-5 text-brand-magenta" /> Loved One's Vitals Trends
                </h3>
                <p className="text-xs text-gray-500">
                  You are authorized to view vital logs and monitor progress charts. Please note that logging new vitals or modifying clinical entries is restricted to care staff and medical administrators.
                </p>

                <PatientVitalsWidget
                  patientId={matchedBooking.patientId || ''}
                  patientName={matchedBooking.customerName}
                  allowLogging={false} // Disabled for family members, only available for staff or admin as requested!
                />
              </div>
            </div>
          ) : (
            <div className="bg-white border border-gray-100 rounded-3xl p-12 text-center shadow-xl space-y-4 flex flex-col items-center justify-center min-h-[400px]">
              <div className="p-4 bg-brand-magenta/5 rounded-full text-brand-magenta mb-2">
                <Heart className="w-12 h-12 stroke-1 text-brand-magenta fill-brand-magenta/10 shrink-0" />
              </div>
              <h3 className="font-display font-black text-xl text-brand-navy">Waiting for Patient ID</h3>
              <p className="text-sm text-gray-500 max-w-sm mx-auto leading-relaxed">
                Enter your loved one's secure Patient ID on the left, or select one of our preloaded clinical test cases to explore the telemetry logs and trends!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
