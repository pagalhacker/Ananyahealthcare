import React, { useState, useEffect } from 'react';
import { UserProfile, Booking, StaffUser, AttendanceLog, StaffProfileChangeRequest } from '../types';
import { BOOKINGS_STORAGE_KEY, ensurePatientIdsOnBookings } from '../utils/vitalsHelper';
import { getStaffPatientDuties, PatientDutyRecord, syncDutyHistoryWithDb, DUTY_HISTORY_UPDATED_EVENT } from '../utils/dutyHistoryHelper';
import { updatePassword, sendPasswordResetEmail, signOut } from '../lib/auth';
import { PatientVitalsWidget } from './PatientVitalsWidget';
import { StaffDutyHistoryView } from './StaffDutyHistoryView';
import { 
  UserCircle2, 
  Calendar, 
  Clock, 
  ShieldCheck, 
  KeyRound, 
  Lock, 
  Mail, 
  Phone, 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  Heart, 
  Stethoscope, 
  Package, 
  CalendarCheck, 
  LogOut, 
  Sparkles, 
  Copy, 
  Check, 
  RefreshCw, 
  ChevronRight, 
  Activity, 
  User, 
  Eye, 
  EyeOff, 
  PlusCircle,
  FileText,
  BadgeCheck,
  Building2,
  ExternalLink,
  ShieldAlert,
  Send,
  HelpCircle,
  Clock3
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ProfilePortalProps {
  currentUser: UserProfile;
  setCurrentTab: (tab: string) => void;
  onBookNow: (itemName?: string, type?: 'service' | 'equipment') => void;
}

export const ProfilePortal: React.FC<ProfilePortalProps> = ({
  currentUser,
  setCurrentTab,
  onBookNow,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'bookings' | 'attendance' | 'security' | 'personal'>('overview');
  
  // Customer Bookings State
  const [userBookings, setUserBookings] = useState<Booking[]>([]);
  const [allBookings, setAllBookings] = useState<Booking[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedVitalsBooking, setSelectedVitalsBooking] = useState<Booking | null>(null);
  const [bookingFilter, setBookingFilter] = useState<'all' | 'service' | 'equipment'>('all');

  // Staff User State
  const [staffInfo, setStaffInfo] = useState<StaffUser | null>(null);
  const [staffAttendance, setStaffAttendance] = useState<AttendanceLog[]>([]);
  const [staffDuties, setStaffDuties] = useState<PatientDutyRecord[]>([]);
  const [todayCheckedIn, setTodayCheckedIn] = useState<boolean>(false);
  const [todayLog, setTodayLog] = useState<AttendanceLog | null>(null);

  // Security / Password State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [passwordMsg, setPasswordMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [passwordLoading, setPasswordLoading] = useState(false);

  // Forgot password state
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotMsg, setForgotMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Profile Edit State
  const [editName, setEditName] = useState(currentUser.name || '');
  const [editPhone, setEditPhone] = useState(currentUser.phone || '');
  const [editRole, setEditRole] = useState('');
  const [editEmail, setEditEmail] = useState(currentUser.email || '');
  const [editReason, setEditReason] = useState('');
  const [profileUpdatedMsg, setProfileUpdatedMsg] = useState<{ type: 'success' | 'info' | 'error'; text: string } | null>(null);
  const [myProfileRequests, setMyProfileRequests] = useState<StaffProfileChangeRequest[]>([]);
  const [isSubmittingProfileRequest, setIsSubmittingProfileRequest] = useState(false);

  // Load user data
  useEffect(() => {
    // 1. Load bookings
    try {
      const storedBookings = localStorage.getItem(BOOKINGS_STORAGE_KEY);
      let parsedBookings: Booking[] = [];
      if (storedBookings) {
        try {
          parsedBookings = JSON.parse(storedBookings);
        } catch {
          parsedBookings = [];
        }
      }
      const withIds = ensurePatientIdsOnBookings(parsedBookings);
      setAllBookings(withIds);

      const userEmail = (currentUser.email || '').trim().toLowerCase();
      const userPhone = (currentUser.phone || '').replace(/\D/g, '');
      const userName = (currentUser.name || '').trim().toLowerCase();

      const matched = withIds.filter((b) => {
        const bEmail = (b.email || '').trim().toLowerCase();
        const bPhone = (b.phoneNumber || '').replace(/\D/g, '');
        const bName = (b.customerName || '').trim().toLowerCase();

        const emailMatch = userEmail && bEmail && (bEmail === userEmail || bEmail.includes(userEmail) || userEmail.includes(bEmail));
        const phoneMatch = userPhone && bPhone && (bPhone.includes(userPhone) || userPhone.includes(bPhone));
        const nameMatch = userName && bName && (bName === userName || bName.includes(userName));

        return emailMatch || phoneMatch || nameMatch;
      });
      setUserBookings(matched);
    } catch (e) {
      console.warn('Failed to load user bookings', e);
    }

    // 2. Load staff info if staff role or matching staff email
    try {
      const storedStaff = localStorage.getItem('ananya_staff_users');
      let staffList: StaffUser[] = [];
      if (storedStaff) {
        try {
          staffList = JSON.parse(storedStaff);
        } catch {
          staffList = [];
        }
      }

      const userEmail = (currentUser.email || '').trim().toLowerCase();
      const matchedStaff = staffList.find(
        (s) => (s.email && s.email.trim().toLowerCase() === userEmail) || s.userId === currentUser.id
      );

      if (matchedStaff) {
        setStaffInfo(matchedStaff);
        setEditName(matchedStaff.name);
        setEditPhone(matchedStaff.phoneNumber);
        setEditRole(matchedStaff.role);
        setEditEmail(matchedStaff.email);
      } else if (currentUser.role === 'staff') {
        // Fallback default staff profile
        const defaultS: StaffUser = {
          userId: currentUser.id && currentUser.id.startsWith('ANA') ? currentUser.id : 'ANA1001',
          name: currentUser.name || 'Healthcare Caregiver',
          role: 'Healthcare Caregiver',
          phoneNumber: currentUser.phone || '+91 77349 31740',
          email: currentUser.email,
          password: 'Ananya@123',
          status: 'Active',
          createdAt: currentUser.createdAt || new Date().toISOString()
        };
        setStaffInfo(defaultS);
        setEditName(defaultS.name);
        setEditPhone(defaultS.phoneNumber);
        setEditRole(defaultS.role);
        setEditEmail(defaultS.email);
      }

      // 3. Load attendance logs
      const storedAttendance = localStorage.getItem('ananya_staff_attendance');
      let attendanceList: AttendanceLog[] = [];
      if (storedAttendance) {
        try {
          attendanceList = JSON.parse(storedAttendance);
        } catch {
          attendanceList = [];
        }
      }

      const targetStaffId = matchedStaff?.userId || (currentUser.id.startsWith('ANA') ? currentUser.id : 'ANA1001');
      const filteredLogs = attendanceList.filter((a) => a.userId === targetStaffId || a.staffName.toLowerCase() === currentUser.name.toLowerCase());
      setStaffAttendance(filteredLogs);

      // Load past patient duties & assignments
      const duties = getStaffPatientDuties(targetStaffId, currentUser.name, matchedStaff?.role || staffInfo?.role);
      setStaffDuties(duties);

      // Sync latest from database
      syncDutyHistoryWithDb().then(() => {
        const refreshed = getStaffPatientDuties(targetStaffId, currentUser.name, matchedStaff?.role || staffInfo?.role);
        setStaffDuties(refreshed);
      });

      const todayStr = new Date().toISOString().split('T')[0];
      const today = filteredLogs.find((a) => a.date === todayStr || (a.checkInTime && a.checkInTime.startsWith(todayStr)));
      if (today) {
        setTodayLog(today);
        setTodayCheckedIn(!today.checkOutTime);
      }

      // 4. Load staff profile change requests
      loadStaffProfileRequests(targetStaffId, currentUser.email);
    } catch (e) {
      console.warn('Failed to load staff details', e);
    }

    const handleDutyUpdated = () => {
      const storedStaff = localStorage.getItem('ananya_staff_users');
      let staffList: StaffUser[] = [];
      if (storedStaff) {
        try { staffList = JSON.parse(storedStaff); } catch {}
      }
      const userEmail = (currentUser.email || '').trim().toLowerCase();
      const matchedStaff = staffList.find(
        (s) => (s.email && s.email.trim().toLowerCase() === userEmail) || s.userId === currentUser.id
      );
      const targetStaffId = matchedStaff?.userId || (currentUser.id.startsWith('ANA') ? currentUser.id : 'ANA1001');
      const refreshed = getStaffPatientDuties(targetStaffId, currentUser.name, matchedStaff?.role || staffInfo?.role);
      setStaffDuties(refreshed);
    };

    window.addEventListener(DUTY_HISTORY_UPDATED_EVENT, handleDutyUpdated);
    window.addEventListener('storage', handleDutyUpdated);
    return () => {
      window.removeEventListener(DUTY_HISTORY_UPDATED_EVENT, handleDutyUpdated);
      window.removeEventListener('storage', handleDutyUpdated);
    };
  }, [currentUser]);

  const loadStaffProfileRequests = async (staffId: string, email: string) => {
    try {
      let reqs: StaffProfileChangeRequest[] = [];
      const res = await fetch('/api/staff-profile-requests');
      if (res.ok) {
        const json = await res.json();
        if (Array.isArray(json.requests)) {
          reqs = json.requests;
        }
      } else {
        const local = localStorage.getItem('ananya_staff_profile_requests');
        if (local) reqs = JSON.parse(local);
      }

      const filtered = reqs.filter(r => 
        r.staffId === staffId || 
        (r.currentEmail && r.currentEmail.toLowerCase() === email.toLowerCase()) ||
        (r.requestedEmail && r.requestedEmail.toLowerCase() === email.toLowerCase())
      );
      setMyProfileRequests(filtered);
    } catch {
      const local = localStorage.getItem('ananya_staff_profile_requests');
      if (local) {
        try {
          const reqs: StaffProfileChangeRequest[] = JSON.parse(local);
          setMyProfileRequests(reqs.filter(r => r.staffId === staffId));
        } catch {}
      }
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(text);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSignOut = async () => {
    await signOut();
    localStorage.removeItem('ananya_logged_staff_id');
    setCurrentTab('home');
    window.location.reload();
  };

  // Change Password Handler
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMsg(null);

    if (newPassword.length < 6) {
      setPasswordMsg({ type: 'error', text: 'New password must be at least 6 characters long.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordMsg({ type: 'error', text: 'New passwords do not match. Please re-enter.' });
      return;
    }

    setPasswordLoading(true);

    try {
      // 1. If staff, also update staff password in ananya_staff_users
      if (staffInfo || currentUser.role === 'staff') {
        const storedStaff = localStorage.getItem('ananya_staff_users');
        let staffList: StaffUser[] = storedStaff ? JSON.parse(storedStaff) : [];
        const targetId = staffInfo?.userId || currentUser.id;
        const targetEmail = currentUser.email.toLowerCase();

        const idx = staffList.findIndex(
          (s) => s.userId === targetId || (s.email && s.email.toLowerCase() === targetEmail)
        );

        if (idx !== -1) {
          staffList[idx].password = newPassword;
          localStorage.setItem('ananya_staff_users', JSON.stringify(staffList));
          setStaffInfo({ ...staffList[idx] });
        }
      }

      // 2. Update via auth library (Supabase & Local DB)
      const res = await updatePassword(newPassword);
      if (res.success) {
        setPasswordMsg({ type: 'success', text: 'Your password has been changed successfully!' });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        setPasswordMsg({ type: 'error', text: res.message || 'Failed to update password.' });
      }
    } catch (err: any) {
      setPasswordMsg({ type: 'error', text: err.message || 'Error updating password.' });
    } finally {
      setPasswordLoading(false);
    }
  };

  // Forgot Password / Email Reset Handler
  const handleTriggerForgotPassword = async () => {
    setForgotLoading(true);
    setForgotMsg(null);
    try {
      const res = await sendPasswordResetEmail(currentUser.email);
      if (res.success) {
        setForgotMsg({ 
          type: 'success', 
          text: `A password reset link has been dispatched to ${currentUser.email}. Please check your email inbox.` 
        });
      } else {
        setForgotMsg({ type: 'error', text: res.message || 'Could not send reset email.' });
      }
    } catch (err: any) {
      setForgotMsg({ type: 'error', text: err.message || 'Failed to send reset link.' });
    } finally {
      setForgotLoading(false);
    }
  };

  // Save profile information updates
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileUpdatedMsg(null);

    if (isStaff) {
      // Staff profile modifications require admin approval
      const targetStaffId = staffInfo?.userId || (currentUser.id && currentUser.id.startsWith('ANA') ? currentUser.id : 'ANA1001');
      const reqId = 'REQ-' + Date.now();
      const newRequest: StaffProfileChangeRequest = {
        id: reqId,
        staffId: targetStaffId,
        currentName: staffInfo?.name || currentUser.name || '',
        currentRole: staffInfo?.role || 'Healthcare Caregiver',
        currentPhone: staffInfo?.phoneNumber || currentUser.phone || '',
        currentEmail: staffInfo?.email || currentUser.email || '',
        requestedName: editName.trim(),
        requestedRole: editRole.trim() || staffInfo?.role || 'Healthcare Caregiver',
        requestedPhone: editPhone.trim(),
        requestedEmail: editEmail.trim() || currentUser.email,
        reason: editReason.trim() || 'Staff requested personal information update',
        status: 'Pending',
        createdAt: new Date().toISOString(),
        requestedAt: new Date().toISOString()
      };

      setIsSubmittingProfileRequest(true);
      try {
        // Send to backend API to store in Supabase/PostgreSQL database
        const res = await fetch('/api/staff-profile-requests', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newRequest),
        });

        // Also update local storage for immediate offline sync
        const stored = localStorage.getItem('ananya_staff_profile_requests');
        let list: StaffProfileChangeRequest[] = stored ? JSON.parse(stored) : [];
        list.unshift(newRequest);
        localStorage.setItem('ananya_staff_profile_requests', JSON.stringify(list));

        setMyProfileRequests(prev => [newRequest, ...prev]);
        setProfileUpdatedMsg({
          type: 'info',
          text: 'Your profile update request has been submitted for Admin Approval! Once approved by the administrator, your name, role, phone, and email will be permanently updated in the central database.'
        });
        setEditReason('');
      } catch (err: any) {
        setProfileUpdatedMsg({
          type: 'error',
          text: 'Failed to submit profile request. Please check connection.'
        });
      } finally {
        setIsSubmittingProfileRequest(false);
      }
      return;
    }

    // Customer / Patient Profile direct update
    const updatedUser: UserProfile = {
      ...currentUser,
      name: editName.trim() || currentUser.name,
      phone: editPhone.trim() || currentUser.phone,
    };

    localStorage.setItem('ananya_auth_user', JSON.stringify(updatedUser));
    window.dispatchEvent(new CustomEvent('ananya_auth_changed', { detail: updatedUser }));
    setProfileUpdatedMsg({
      type: 'success',
      text: 'Profile details updated successfully!'
    });
    setTimeout(() => setProfileUpdatedMsg(null), 3500);
  };

  // Filter bookings
  const filteredBookings = userBookings.filter((b) => {
    if (bookingFilter !== 'all' && b.type !== bookingFilter) return false;
    return true;
  });

  const isStaff = currentUser.role === 'staff' || Boolean(staffInfo);
  const isAdmin = currentUser.role === 'admin';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 space-y-8 font-sans">
      
      {/* 1. Header Banner & Profile Snapshot Card */}
      <div className="bg-gradient-to-br from-brand-navy via-brand-navy to-brand-magenta rounded-3xl p-6 sm:p-10 text-white shadow-2xl relative overflow-hidden">
        {/* Ambient subtle glow decoration */}
        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-brand-magenta/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 -top-20 w-60 h-60 bg-white/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="flex items-center gap-4 sm:gap-6">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-white flex items-center justify-center font-bold text-2xl sm:text-3xl shadow-inner shrink-0">
              {(currentUser.name || 'U').charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1.5">
                <span className="text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider bg-white/20 backdrop-blur-sm text-white border border-white/20 flex items-center gap-1">
                  {isAdmin ? (
                    <>
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      Administrator
                    </>
                  ) : isStaff ? (
                    <>
                      <Stethoscope className="w-3.5 h-3.5 text-brand-magenta-light" />
                      Healthcare Staff
                    </>
                  ) : (
                    <>
                      <Heart className="w-3.5 h-3.5 text-pink-400" />
                      Patient / Family Member
                    </>
                  )}
                </span>
                {isStaff && staffInfo?.userId && (
                  <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-brand-magenta text-white border border-white/20 shadow-sm">
                    Access ID: {staffInfo.userId}
                  </span>
                )}
              </div>
              <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-white tracking-tight">
                {currentUser.name || 'Valued Member'}
              </h1>
              <p className="text-xs sm:text-sm text-white/80 mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
                <span className="flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-white/70" /> {currentUser.email}
                </span>
                {currentUser.phone && (
                  <span className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-white/70" /> {currentUser.phone}
                  </span>
                )}
              </p>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            {isAdmin && (
              <button
                onClick={() => setCurrentTab('admin')}
                className="px-4 py-2.5 rounded-xl bg-white text-brand-navy hover:bg-gray-100 font-bold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-brand-magenta" /> Open Admin Hub
              </button>
            )}
            
            {isStaff && (
              <button
                onClick={() => setCurrentTab('admin')}
                className="px-4 py-2.5 rounded-xl bg-white text-brand-navy hover:bg-gray-100 font-bold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <Stethoscope className="w-4 h-4 text-brand-magenta" /> Staff Duty Hub
              </button>
            )}

            {!isStaff && !isAdmin && (
              <button
                onClick={() => onBookNow()}
                className="px-4 py-2.5 rounded-xl bg-white text-brand-magenta hover:bg-gray-100 font-bold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <CalendarCheck className="w-4 h-4" /> Book New Service
              </button>
            )}

            <button
              onClick={handleSignOut}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold text-xs transition-all flex items-center gap-2 cursor-pointer ml-auto md:ml-0"
            >
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>
        </div>
      </div>

      {/* 2. Navigation Sub-Tabs */}
      <div className="flex overflow-x-auto no-scrollbar gap-2 border-b border-gray-200 pb-2">
        <button
          onClick={() => setActiveSubTab('overview')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
            activeSubTab === 'overview'
              ? 'bg-brand-navy text-white shadow-md'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <UserCircle2 className="w-4 h-4" /> Overview & Profile
        </button>

        {!isStaff && (
          <button
            onClick={() => setActiveSubTab('bookings')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
              activeSubTab === 'bookings'
                ? 'bg-brand-magenta text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <CalendarCheck className="w-4 h-4" /> My Booking History ({userBookings.length})
          </button>
        )}

        {isStaff && (
          <button
            onClick={() => setActiveSubTab('attendance')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
              activeSubTab === 'attendance'
                ? 'bg-brand-magenta text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Clock className="w-4 h-4" /> Patient Duty & Attendance History ({staffDuties.length})
          </button>
        )}

        <button
          onClick={() => setActiveSubTab('security')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
            activeSubTab === 'security'
              ? 'bg-brand-navy text-white shadow-md'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <Lock className="w-4 h-4" /> Password & Security
        </button>

        <button
          onClick={() => setActiveSubTab('personal')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
            activeSubTab === 'personal'
              ? 'bg-brand-navy text-white shadow-md'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <User className="w-4 h-4" /> Edit Details
        </button>
      </div>

      {/* 3. SUB-TAB CONTENT PANELS */}

      {/* === SUB-TAB 1: OVERVIEW & PROFILE === */}
      {activeSubTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Personal Info Summary Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-gray-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-gray-100 pb-4">
              <h3 className="font-display font-extrabold text-lg text-brand-navy">Personal Details</h3>
              <span className="text-[10px] uppercase font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                Verified
              </span>
            </div>

            <div className="space-y-3.5 text-xs">
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500 font-medium">Full Name</span>
                <span className="font-bold text-brand-navy">{currentUser.name || 'Not Provided'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500 font-medium">Registered Email</span>
                <span className="font-semibold text-brand-navy">{currentUser.email}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500 font-medium">Contact Phone</span>
                <span className="font-bold text-brand-navy">{currentUser.phone || '+91 77349 31740'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500 font-medium">Account Role</span>
                <span className="font-bold capitalize text-brand-magenta">{currentUser.role || 'Patient'}</span>
              </div>
              {isStaff && staffInfo?.userId && (
                <div className="flex justify-between py-1.5 border-b border-gray-50">
                  <span className="text-gray-500 font-medium">Staff ID</span>
                  <span className="font-mono font-bold text-brand-magenta">{staffInfo.userId}</span>
                </div>
              )}
              {isStaff && staffInfo?.role && (
                <div className="flex justify-between py-1.5 border-b border-gray-50">
                  <span className="text-gray-500 font-medium">Designation</span>
                  <span className="font-bold text-brand-navy">{staffInfo.role}</span>
                </div>
              )}
            </div>

            <button
              onClick={() => setActiveSubTab('personal')}
              className="w-full py-2.5 px-4 bg-gray-50 hover:bg-gray-100 text-brand-navy rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Update Information
            </button>
          </div>

          {/* Quick Metrics / Activity Card */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* If Patient: Quick Booking Summary */}
            {!isStaff && (
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-gray-200 shadow-sm space-y-5">
                <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                  <div>
                    <h3 className="font-display font-extrabold text-lg text-brand-navy">Active Healthcare Bookings</h3>
                    <p className="text-xs text-gray-500 mt-0.5">Your home nursing, attendant, and medical equipment inquiries.</p>
                  </div>
                  <button
                    onClick={() => setActiveSubTab('bookings')}
                    className="text-xs text-brand-magenta hover:underline font-bold flex items-center gap-1 cursor-pointer"
                  >
                    View All ({userBookings.length}) <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {userBookings.length === 0 ? (
                  <div className="text-center py-8 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                    <CalendarCheck className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                    <h4 className="text-sm font-bold text-gray-800">No active bookings yet</h4>
                    <p className="text-xs text-gray-500 max-w-sm mx-auto mt-1 mb-4">
                      Book certified ICU nurses, home attendants, physiotherapy, or rent clinical equipment.
                    </p>
                    <button
                      onClick={() => onBookNow()}
                      className="px-5 py-2.5 bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
                    >
                      <PlusCircle className="w-4 h-4" /> Book Staff / Equipment Now
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {userBookings.slice(0, 3).map((b) => (
                      <div
                        key={b.id}
                        className="p-4 rounded-2xl border border-gray-100 hover:border-brand-magenta/30 bg-gray-50/70 transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-brand-navy">{b.itemSelected}</span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                b.status === 'Confirmed'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : b.status === 'Cancelled'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {b.status}
                            </span>
                            {b.patientId && (
                              <span className="text-[10px] font-mono font-bold bg-brand-magenta/10 text-brand-magenta px-2 py-0.5 rounded">
                                ID: {b.patientId}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-gray-500 flex items-center gap-3">
                            <span>📅 {b.bookingDate}</span>
                            <span>📍 {b.address}</span>
                          </p>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center">
                          {b.patientId && (
                            <button
                              onClick={() => setSelectedVitalsBooking(b)}
                              className="px-3 py-1.5 bg-brand-magenta/10 hover:bg-brand-magenta text-brand-magenta hover:text-white rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <Activity className="w-3.5 h-3.5" /> Vitals
                            </button>
                          )}
                          <button
                            onClick={() => setActiveSubTab('bookings')}
                            className="px-3 py-1.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-xs font-semibold cursor-pointer"
                          >
                            Details
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* If Staff: Attendance Snapshot */}
            {isStaff && (
              <div className="bg-white rounded-3xl p-6 sm:p-7 border border-gray-200 shadow-sm space-y-5">
                <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                  <div>
                    <h3 className="font-display font-extrabold text-lg text-brand-navy">Today's Duty & Attendance Status</h3>
                    <p className="text-xs text-gray-500 mt-0.5">Field staff shift tracking and location log.</p>
                  </div>
                  <button
                    onClick={() => setActiveSubTab('attendance')}
                    className="text-xs text-brand-magenta hover:underline font-bold flex items-center gap-1 cursor-pointer"
                  >
                    View Duty Logs <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-brand-navy/5 border border-brand-navy/10 space-y-1">
                    <span className="text-[11px] text-gray-500 font-semibold uppercase">Total Recorded Shifts</span>
                    <p className="text-2xl font-extrabold text-brand-navy">{staffAttendance.length}</p>
                    <p className="text-[11px] text-emerald-600 font-medium">100% attendance verified</p>
                  </div>

                  <div className="p-4 rounded-2xl bg-brand-magenta/5 border border-brand-magenta/10 space-y-1">
                    <span className="text-[11px] text-brand-magenta font-semibold uppercase">Staff Authorization</span>
                    <p className="text-base font-extrabold text-brand-navy">{staffInfo?.role || 'Healthcare Staff'}</p>
                    <p className="text-[11px] font-mono text-brand-magenta font-bold">ID: {staffInfo?.userId || 'ANA1001'}</p>
                  </div>
                </div>

                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-emerald-950">Active Caregiver Duty Profile</h4>
                      <p className="text-[11px] text-emerald-800">You are authorized to log attendance and access patient vitals charts.</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setCurrentTab('admin')}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm cursor-pointer"
                  >
                    Open Staff Portal
                  </button>
                </div>
              </div>
            )}

            {/* Quick Security Status */}
            <div className="bg-white rounded-3xl p-6 border border-gray-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex items-center gap-3.5">
                <div className="p-3 bg-brand-navy/10 rounded-2xl text-brand-navy">
                  <ShieldCheck className="w-6 h-6 text-brand-magenta" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-brand-navy">Account Security & Credentials</h4>
                  <p className="text-xs text-gray-500">Manage password, recover access ID, or trigger password reset link.</p>
                </div>
              </div>
              <button
                onClick={() => setActiveSubTab('security')}
                className="px-4 py-2.5 bg-brand-navy hover:bg-brand-navy-light text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer whitespace-nowrap"
              >
                Change Password
              </button>
            </div>

          </div>

        </div>
      )}

      {/* === SUB-TAB 2: MY BOOKINGS (PATIENT / CUSTOMER) === */}
      {activeSubTab === 'bookings' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-100 pb-5">
              <div>
                <h3 className="font-display font-extrabold text-xl text-brand-navy">My Booking History & Orders</h3>
                <p className="text-xs text-gray-500 mt-1">
                  Track and review all your home healthcare services, attendant duties, and medical equipment rentals.
                </p>
              </div>

              {/* Filter controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setBookingFilter('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                    bookingFilter === 'all' ? 'bg-brand-magenta text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  All ({userBookings.length})
                </button>
                <button
                  onClick={() => setBookingFilter('service')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                    bookingFilter === 'service' ? 'bg-brand-magenta text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  Services
                </button>
                <button
                  onClick={() => setBookingFilter('equipment')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                    bookingFilter === 'equipment' ? 'bg-brand-magenta text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  Equipment
                </button>
              </div>
            </div>

            {filteredBookings.length === 0 ? (
              <div className="text-center py-12 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                <CalendarCheck className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <h4 className="text-base font-bold text-gray-800">No bookings matching filter</h4>
                <p className="text-xs text-gray-500 max-w-sm mx-auto mt-1 mb-5">
                  You can register a new patient for 24/7 ICU nursing, elder care attendants, physiotherapy, or oxygen concentrators.
                </p>
                <button
                  onClick={() => onBookNow()}
                  className="px-6 py-3 bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
                >
                  <CalendarCheck className="w-4 h-4" /> Book Staff / Equipment Now
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredBookings.map((b) => (
                  <div
                    key={b.id}
                    className="p-5 rounded-2xl border border-gray-200 hover:border-brand-magenta/40 bg-white hover:shadow-md transition-all space-y-4 relative"
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-brand-navy">{b.itemSelected}</span>
                          <span
                            className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                              b.status === 'Confirmed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : b.status === 'Cancelled'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {b.status}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 font-medium">Patient: <strong>{b.customerName}</strong></p>
                      </div>

                      {b.patientId && (
                        <div className="flex items-center gap-1.5 bg-brand-magenta/10 px-2.5 py-1 rounded-lg border border-brand-magenta/20">
                          <span className="text-[11px] font-mono font-bold text-brand-magenta">{b.patientId}</span>
                          <button
                            onClick={() => handleCopy(b.patientId || '')}
                            className="text-brand-magenta hover:text-brand-navy p-0.5"
                            title="Copy Patient ID"
                          >
                            {copiedId === b.patientId ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 bg-gray-50 p-3 rounded-xl">
                      <div>
                        <span className="text-gray-400 block text-[10px] uppercase font-bold">Booking Date</span>
                        <span className="font-semibold text-brand-navy">{b.bookingDate}</span>
                      </div>
                      <div>
                        <span className="text-gray-400 block text-[10px] uppercase font-bold">Order Type</span>
                        <span className="font-semibold capitalize text-brand-navy">{b.type}</span>
                      </div>
                      <div className="col-span-2 pt-1 border-t border-gray-100">
                        <span className="text-gray-400 block text-[10px] uppercase font-bold">Service Location</span>
                        <span className="font-medium text-gray-700 truncate block">{b.address}</span>
                      </div>
                    </div>

                    {b.assignedStaffName && (
                      <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-100 text-xs flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Stethoscope className="w-4 h-4 text-emerald-600 shrink-0" />
                          <div>
                            <p className="font-bold text-emerald-950">Assigned: {b.assignedStaffName}</p>
                            <p className="text-[10px] text-emerald-700">{b.assignedStaffRole || 'Duty Nurse'}</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {b.requirementDetails && (
                      <p className="text-xs text-gray-500 italic bg-gray-50/50 p-2 rounded-lg">
                        "{b.requirementDetails}"
                      </p>
                    )}

                    <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                      <button
                        onClick={() => setCurrentTab('family-portal')}
                        className="text-xs text-brand-magenta hover:underline font-bold inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Heart className="w-3.5 h-3.5" /> Open Family Live Tracker
                      </button>

                      {b.patientId && (
                        <button
                          onClick={() => setSelectedVitalsBooking(b)}
                          className="px-3.5 py-1.5 bg-brand-magenta text-white font-bold rounded-xl text-xs shadow-sm hover:bg-brand-magenta-light transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                          <Activity className="w-3.5 h-3.5" /> View Vitals
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* === SUB-TAB 3: ATTENDANCE & PATIENT DUTY HISTORY (STAFF ONLY) === */}
      {activeSubTab === 'attendance' && isStaff && (
        <div className="space-y-6">
          <StaffDutyHistoryView
            duties={staffDuties}
            staffName={currentUser.name}
            staffId={staffInfo?.userId || (currentUser.id && currentUser.id.startsWith('ANA') ? currentUser.id : 'ANA1001')}
            staffRole={staffInfo?.role || currentUser.role || 'Healthcare Staff'}
          />
        </div>
      )}

      {/* === SUB-TAB 4: PASSWORD & SECURITY (CHANGE PASSWORD & FORGOT PASSWORD) === */}
      {activeSubTab === 'security' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Change Password Form */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-5">
            <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
              <div className="p-2.5 bg-brand-magenta/10 text-brand-magenta rounded-xl">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-display font-extrabold text-lg text-brand-navy">Change Account Password</h3>
                <p className="text-xs text-gray-500">Update your security password for regular login access.</p>
              </div>
            </div>

            {passwordMsg && (
              <div
                className={`p-3.5 rounded-xl text-xs flex items-start gap-2 ${
                  passwordMsg.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-red-50 text-red-700 border border-red-200'
                }`}
              >
                {passwordMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                )}
                <span>{passwordMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                  New Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    placeholder="Enter new password (min 6 characters)"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 px-4 py-2.5 rounded-xl text-xs font-medium focus:outline-none focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                  Confirm New Password
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Re-enter new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 px-4 py-2.5 rounded-xl text-xs font-medium focus:outline-none focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5"
                />
              </div>

              <button
                type="submit"
                disabled={passwordLoading}
                className="w-full py-3 bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {passwordLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <>
                    <KeyRound className="w-4 h-4" /> Update Password
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Forgot Password / Recovery Box */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
                <div className="p-2.5 bg-brand-navy/10 text-brand-navy rounded-xl">
                  <Mail className="w-5 h-5 text-brand-magenta" />
                </div>
                <div>
                  <h3 className="font-display font-extrabold text-lg text-brand-navy">Password Reset & Recovery</h3>
                  <p className="text-xs text-gray-500">Need to recover your credentials via registered email?</p>
                </div>
              </div>

              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-900 leading-relaxed">
                <p className="font-bold mb-1">Registered Verification Address:</p>
                <p className="font-mono font-bold text-brand-navy bg-white px-3 py-2 rounded-xl border border-amber-200 break-all">
                  {currentUser.email}
                </p>
                <p className="mt-2 text-[11px] text-amber-800">
                  Clicking below will dispatch official password reset and recovery instructions directly to your verified email.
                </p>
              </div>

              {forgotMsg && (
                <div
                  className={`p-3.5 rounded-xl text-xs flex items-start gap-2 ${
                    forgotMsg.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-red-50 text-red-700 border border-red-200'
                  }`}
                >
                  {forgotMsg.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                  )}
                  <span>{forgotMsg.text}</span>
                </div>
              )}
            </div>

            <button
              onClick={handleTriggerForgotPassword}
              disabled={forgotLoading}
              className="w-full py-3 bg-brand-navy hover:bg-brand-navy-light text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {forgotLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
              ) : (
                <>
                  <Mail className="w-4 h-4" /> Send Reset Link to {currentUser.email}
                </>
              )}
            </button>
          </div>

        </div>
      )}

      {/* === SUB-TAB 5: EDIT PERSONAL INFORMATION === */}
      {activeSubTab === 'personal' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className={`${isStaff ? 'lg:col-span-7' : 'lg:col-span-8'} space-y-6`}>
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-sm space-y-6">
              <div className="border-b border-gray-100 pb-4">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-display font-extrabold text-xl text-brand-navy">
                    {isStaff ? 'Staff Profile & Database Records' : 'Edit Personal Information'}
                  </h3>
                  {isStaff && (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide bg-amber-100 text-amber-800 border border-amber-200">
                      Approval Required
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500">
                  {isStaff 
                    ? 'Submit changes to your professional identity. For security and database accuracy, modifications require Administrator review before being applied to the live database.' 
                    : 'Keep your contact information up-to-date for fast care coordination.'}
                </p>
              </div>

              {isStaff && (
                <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-blue-900 leading-relaxed">
                  <ShieldAlert className="w-5 h-5 text-brand-navy shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block text-brand-navy mb-0.5">Staff Database Synchronization Policy:</span>
                    Your full name, clinical role, contact phone, and email are synced with the central database. Any modifications will be queued for Admin Approval to prevent unauthorized credential alterations.
                  </div>
                </div>
              )}

              {profileUpdatedMsg && (
                <div className={`p-4 rounded-2xl border flex items-start gap-2.5 text-xs ${
                  profileUpdatedMsg.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : profileUpdatedMsg.type === 'info'
                    ? 'bg-amber-50 text-amber-900 border-amber-200'
                    : 'bg-red-50 text-red-800 border-red-200'
                }`}>
                  {profileUpdatedMsg.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : profileUpdatedMsg.type === 'info' ? (
                    <Clock3 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  )}
                  <span className="font-medium">{profileUpdatedMsg.text}</span>
                </div>
              )}

              <form onSubmit={handleSaveProfile} className="space-y-4">
                {isStaff && staffInfo?.userId && (
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                      Staff Access ID (Fixed)
                    </label>
                    <input
                      type="text"
                      disabled
                      value={staffInfo.userId}
                      className="w-full bg-gray-100 border border-gray-200 px-4 py-2.5 rounded-xl text-xs font-mono font-bold text-gray-600 cursor-not-allowed"
                    />
                  </div>
                )}

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    placeholder="Enter full name"
                    className="w-full bg-gray-50 border border-gray-200 px-4 py-2.5 rounded-xl text-xs font-semibold text-brand-navy focus:outline-none focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5"
                  />
                </div>

                {isStaff ? (
                  <>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                        Designated Role / Specialization
                      </label>
                      <select
                        value={editRole}
                        onChange={(e) => setEditRole(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 px-4 py-2.5 rounded-xl text-xs font-semibold text-brand-navy focus:outline-none focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5"
                      >
                        <option value="Senior Nurse">Senior Nurse (GNM / B.Sc Nursing)</option>
                        <option value="Junior Nurse">Junior Nurse (ANM / Associate)</option>
                        <option value="Healthcare Caregiver">Healthcare Caregiver (Elderly & Post-Op)</option>
                        <option value="Physiotherapist">Physiotherapist (BPT / MPT Specialist)</option>
                        <option value="Medical Attendant">Medical Attendant / Aide</option>
                        <option value="Critical Care Nurse">Critical Care Nurse (ICU Specialist)</option>
                      </select>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                        Mobile Phone Number
                      </label>
                      <input
                        type="tel"
                        required
                        value={editPhone}
                        onChange={(e) => setEditPhone(e.target.value)}
                        placeholder="e.g. +91 77349 31740"
                        className="w-full bg-gray-50 border border-gray-200 px-4 py-2.5 rounded-xl text-xs font-semibold text-brand-navy focus:outline-none focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5"
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                        Official Email Address
                      </label>
                      <input
                        type="email"
                        required
                        value={editEmail}
                        onChange={(e) => setEditEmail(e.target.value)}
                        placeholder="staff@ananyacare.com"
                        className="w-full bg-gray-50 border border-gray-200 px-4 py-2.5 rounded-xl text-xs font-semibold text-brand-navy focus:outline-none focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5"
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                        Reason for Profile Change (For Administrator)
                      </label>
                      <textarea
                        rows={2}
                        value={editReason}
                        onChange={(e) => setEditReason(e.target.value)}
                        placeholder="e.g., Updated contact phone number or role change..."
                        className="w-full bg-gray-50 border border-gray-200 px-4 py-2 rounded-xl text-xs font-medium text-brand-navy focus:outline-none focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5 resize-none"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                        Contact Phone Number
                      </label>
                      <input
                        type="tel"
                        required
                        value={editPhone}
                        onChange={(e) => setEditPhone(e.target.value)}
                        placeholder="e.g. +91 77349 31740"
                        className="w-full bg-gray-50 border border-gray-200 px-4 py-2.5 rounded-xl text-xs font-semibold text-brand-navy focus:outline-none focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5"
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                        Registered Email (Read-Only)
                      </label>
                      <input
                        type="email"
                        disabled
                        value={currentUser.email}
                        className="w-full bg-gray-100 border border-gray-200 px-4 py-2.5 rounded-xl text-xs font-medium text-gray-500 cursor-not-allowed"
                      />
                      <p className="text-[11px] text-gray-400">Email address is permanently linked to your medical records.</p>
                    </div>
                  </>
                )}

                <button
                  type="submit"
                  disabled={isSubmittingProfileRequest}
                  className="w-full py-3.5 bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSubmittingProfileRequest ? (
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  ) : isStaff ? (
                    <>
                      <Send className="w-4 h-4" /> Submit Profile Change for Admin Approval
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" /> Save Updated Details
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Right Column: Status of Requests / Guidance */}
          {isStaff && (
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-gray-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                  <h4 className="font-display font-extrabold text-sm text-brand-navy flex items-center gap-2">
                    <Clock className="w-4 h-4 text-brand-magenta" /> Change Request History
                  </h4>
                  <button
                    onClick={() => {
                      const targetId = staffInfo?.userId || (currentUser.id && currentUser.id.startsWith('ANA') ? currentUser.id : 'ANA1001');
                      loadStaffProfileRequests(targetId, currentUser.email);
                    }}
                    className="text-xs text-brand-magenta hover:text-brand-magenta-light flex items-center gap-1 font-bold cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Refresh
                  </button>
                </div>

                {myProfileRequests.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <FileText className="w-8 h-8 mx-auto mb-2 opacity-30 text-brand-navy" />
                    <p className="text-xs font-semibold text-gray-500">No profile change requests found.</p>
                    <p className="text-[11px] text-gray-400 mt-1">When you submit updates to your name, role, or phone, approval status will appear here.</p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[450px] overflow-y-auto pr-1">
                    {myProfileRequests.map((req) => (
                      <div
                        key={req.id}
                        className={`p-3.5 rounded-2xl border transition-all ${
                          req.status === 'Approved'
                            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                            : req.status === 'Rejected'
                            ? 'bg-red-50/70 border-red-200 text-red-950'
                            : 'bg-amber-50/70 border-amber-200 text-amber-950'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                            req.status === 'Approved'
                              ? 'bg-emerald-200 text-emerald-900'
                              : req.status === 'Rejected'
                              ? 'bg-red-200 text-red-900'
                              : 'bg-amber-200 text-amber-900 animate-pulse'
                          }`}>
                            {req.status === 'Pending' ? '⏳ Awaiting Admin Approval' : req.status}
                          </span>
                          <span className="text-[10px] text-gray-500">
                            {req.requestedAt ? new Date(req.requestedAt).toLocaleDateString() : 'Recent'}
                          </span>
                        </div>

                        <div className="text-xs space-y-1 mt-2">
                          <p className="font-bold text-brand-navy">
                            {req.requestedName} <span className="font-normal text-gray-600">({req.requestedRole})</span>
                          </p>
                          <p className="text-[11px] text-gray-600 flex items-center gap-1">
                            <Phone className="w-3 h-3 text-brand-magenta" /> {req.requestedPhone}
                          </p>
                          {req.requestedEmail && (
                            <p className="text-[11px] text-gray-600 flex items-center gap-1">
                              <Mail className="w-3 h-3 text-brand-magenta" /> {req.requestedEmail}
                            </p>
                          )}
                          {req.reason && (
                            <p className="text-[11px] italic text-gray-500 bg-white/70 p-2 rounded-xl border border-black/5 mt-1.5">
                              Note: "{req.reason}"
                            </p>
                          )}
                          {req.status === 'Rejected' && req.adminNotes && (
                            <p className="text-[11px] font-bold text-red-700 bg-red-100/60 p-2 rounded-xl border border-red-200 mt-1.5">
                              Admin Reason: {req.adminNotes}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Database Synchronized Badge Info */}
              <div className="bg-brand-navy/5 rounded-3xl p-5 border border-brand-navy/10 text-xs text-brand-navy space-y-2">
                <div className="flex items-center gap-2 font-bold text-brand-navy">
                  <Building2 className="w-4 h-4 text-brand-magenta" /> Supabase Database Integrity
                </div>
                <p className="text-gray-600 text-[11px] leading-relaxed">
                  All approved profile modifications update directly in the PostgreSQL database and reflect across staff attendance rosters, shift records, and patient vital duty logs.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Patient Vitals Modal */}
      {selectedVitalsBooking && (
        <PatientVitalsWidget
          booking={selectedVitalsBooking}
          onClose={() => setSelectedVitalsBooking(null)}
        />
      )}

    </div>
  );
};
