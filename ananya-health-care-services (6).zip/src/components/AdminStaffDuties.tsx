import React, { useState, useEffect } from 'react';
import { 
  PatientDutyRecord, 
  getAllDutyHistory, 
  saveDutyRecord, 
  deleteDutyRecord, 
  syncDutyHistoryWithDb, 
  calculateDutyDays, 
  DUTY_HISTORY_UPDATED_EVENT 
} from '../utils/dutyHistoryHelper';
import { StaffUser } from '../types';
import { 
  Activity, 
  Calendar, 
  Clock, 
  MapPin, 
  User, 
  UserCheck, 
  Plus, 
  Search, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  X, 
  Building2, 
  ShieldCheck, 
  Phone, 
  FileText, 
  Sparkles, 
  ChevronDown, 
  ChevronUp, 
  Check, 
  AlertCircle,
  Stethoscope
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AdminStaffDutiesProps {
  staffUsers: StaffUser[];
}

export const AdminStaffDuties: React.FC<AdminStaffDutiesProps> = ({ staffUsers }) => {
  const [duties, setDuties] = useState<PatientDutyRecord[]>(getAllDutyHistory());
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStaffFilter, setSelectedStaffFilter] = useState('All');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<'All' | 'Ongoing' | 'Completed'>('All');
  const [selectedCityFilter, setSelectedCityFilter] = useState('All');
  const [expandedDutyId, setExpandedDutyId] = useState<string | null>(null);

  // Modal / Form state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDutyId, setEditingDutyId] = useState<string | null>(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Form fields
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState('');
  const [patientGender, setPatientGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [patientPhone, setPatientPhone] = useState('');
  const [city, setCity] = useState('Jaipur');
  const [locality, setLocality] = useState('Mansarovar');
  const [locationAddress, setLocationAddress] = useState('');
  const [assignedStaffId, setAssignedStaffId] = useState(staffUsers[0]?.userId || 'ANA1001');
  const [serviceTitle, setServiceTitle] = useState('ICU / Post-Operative Nursing Care');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  const [totalDays, setTotalDays] = useState<number>(14);
  const [totalShifts, setTotalShifts] = useState<number>(14);
  const [totalHours, setTotalHours] = useState<number>(168);
  const [status, setStatus] = useState<'Ongoing' | 'Completed'>('Ongoing');
  const [clinicalRequirement, setClinicalRequirement] = useState('');
  const [dutyHighlightsText, setDutyHighlightsText] = useState('');

  // Initial load and live DB sync
  useEffect(() => {
    syncDutyHistoryWithDb().then((synced) => {
      if (synced && synced.length > 0) {
        setDuties(synced);
      }
    });

    const handleUpdate = () => {
      setDuties(getAllDutyHistory());
    };

    window.addEventListener(DUTY_HISTORY_UPDATED_EVENT, handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener(DUTY_HISTORY_UPDATED_EVENT, handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  // Recalculate days when start or end date changes
  useEffect(() => {
    if (startDate && endDate) {
      const days = calculateDutyDays(startDate, endDate);
      setTotalDays(days);
      setTotalShifts(days);
      setTotalHours(days * 12);
    }
  }, [startDate, endDate]);

  // Open modal for new duty
  const openNewDutyModal = () => {
    setEditingDutyId(null);
    setPatientName('');
    setPatientAge('');
    setPatientGender('Male');
    setPatientPhone('');
    setCity('Jaipur');
    setLocality('Mansarovar');
    setLocationAddress('');
    setAssignedStaffId(staffUsers[0]?.userId || 'ANA1001');
    setServiceTitle('ICU / Post-Operative Nursing Care');
    const today = new Date().toISOString().split('T')[0];
    const twoWeeks = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    setStartDate(today);
    setEndDate(twoWeeks);
    setTotalDays(14);
    setTotalShifts(14);
    setTotalHours(168);
    setStatus('Ongoing');
    setClinicalRequirement('Continuous vital signs monitoring, medication administration, hygiene support, and clinical records maintenance.');
    setDutyHighlightsText('• Sponge bathing and pressure sore prevention\n• Strict medication schedule tracking\n• Daily vitals charted (BP, SPO2, Pulse, Temp)');
    setIsModalOpen(true);
  };

  // Open modal for editing existing duty
  const openEditDutyModal = (duty: PatientDutyRecord) => {
    setEditingDutyId(duty.id);
    setPatientName(duty.patientName);
    setPatientAge(duty.patientAge ? String(duty.patientAge) : '');
    setPatientGender((duty.patientGender as any) || 'Male');
    setPatientPhone(duty.patientPhone || '');
    setCity(duty.city || 'Jaipur');
    setLocality(duty.locality || '');
    setLocationAddress(duty.locationAddress || '');
    setAssignedStaffId(duty.assignedStaffId || staffUsers[0]?.userId || 'ANA1001');
    setServiceTitle(duty.serviceTitle);
    setStartDate(duty.startDate);
    setEndDate(duty.endDate);
    setTotalDays(duty.totalDays || 1);
    setTotalShifts(duty.totalShifts || 1);
    setTotalHours(duty.totalHours || 12);
    setStatus(duty.status);
    setClinicalRequirement(duty.clinicalRequirement || '');
    setDutyHighlightsText(duty.dutyHighlights ? duty.dutyHighlights.join('\n') : '');
    setIsModalOpen(true);
  };

  // Save Duty handler
  const handleSaveDutySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim()) {
      alert('Patient Name is required.');
      return;
    }
    if (!locationAddress.trim()) {
      alert('Duty Location Address is required.');
      return;
    }

    setIsSaving(true);
    const matchedStaff = staffUsers.find((s) => s.userId === assignedStaffId);
    const staffName = matchedStaff ? matchedStaff.name : 'Assigned Staff';
    const staffRole = matchedStaff ? matchedStaff.role : 'Healthcare Caregiver';

    const highlights = dutyHighlightsText
      .split('\n')
      .map((h) => h.replace(/^[•\-\*]\s*/, '').trim())
      .filter(Boolean);

    const dutyId = editingDutyId || `DUTY-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const patientId = editingDutyId 
      ? (duties.find(d => d.id === editingDutyId)?.patientId || `PAT-${Math.floor(1000 + Math.random() * 9000)}`)
      : `PAT-${Math.floor(1000 + Math.random() * 9000)}`;

    const newRecord: PatientDutyRecord = {
      id: dutyId,
      patientId: patientId,
      patientName: patientName.trim(),
      patientAge: patientAge ? parseInt(patientAge, 10) : undefined,
      patientGender: patientGender,
      patientPhone: patientPhone.trim(),
      city: city.trim(),
      locality: locality.trim(),
      locationAddress: locationAddress.trim(),
      serviceTitle: serviceTitle.trim(),
      serviceType: 'service',
      startDate: startDate,
      endDate: endDate,
      totalDays: Number(totalDays) || 1,
      totalShifts: Number(totalShifts) || Number(totalDays) || 1,
      totalHours: Number(totalHours) || (Number(totalDays) * 12),
      status: status,
      assignedStaffId: assignedStaffId,
      assignedStaffName: staffName,
      assignedStaffRole: staffRole,
      clinicalRequirement: clinicalRequirement.trim(),
      dutyHighlights: highlights.length > 0 ? highlights : [
        'Dedicated home patient care and vitals management',
        'Hygiene maintenance and daily medication protocol'
      ],
      dailyLogs: editingDutyId ? (duties.find(d => d.id === editingDutyId)?.dailyLogs || []) : []
    };

    saveDutyRecord(newRecord);
    setDuties(getAllDutyHistory());
    setIsSaving(false);
    setIsModalOpen(false);

    setActionSuccessMsg(
      editingDutyId 
        ? `Patient Duty for "${newRecord.patientName}" updated and synced with Database!`
        : `New Duty of ${newRecord.totalDays} Days assigned to ${staffName} (${newRecord.assignedStaffId}) and synced!`
    );
    setTimeout(() => setActionSuccessMsg(null), 5000);
  };

  // Delete duty handler
  const handleDeleteDuty = (duty: PatientDutyRecord) => {
    if (window.confirm(`Are you sure you want to delete the duty history for patient "${duty.patientName}" (${duty.totalDays} Days)?`)) {
      deleteDutyRecord(duty.id);
      setDuties(getAllDutyHistory());
      setActionSuccessMsg(`Duty record for "${duty.patientName}" deleted from Database.`);
      setTimeout(() => setActionSuccessMsg(null), 4000);
    }
  };

  // Quick toggle duty status
  const handleToggleStatus = (duty: PatientDutyRecord) => {
    const nextStatus = duty.status === 'Completed' ? 'Ongoing' : 'Completed';
    const updated: PatientDutyRecord = { ...duty, status: nextStatus };
    saveDutyRecord(updated);
    setDuties(getAllDutyHistory());
    setActionSuccessMsg(`Duty for "${duty.patientName}" marked as ${nextStatus}.`);
    setTimeout(() => setActionSuccessMsg(null), 3000);
  };

  // Filter duties
  const filteredDuties = duties.filter((d) => {
    const sTerm = searchTerm.toLowerCase().trim();
    const matchesSearch = 
      !sTerm ||
      d.patientName.toLowerCase().includes(sTerm) ||
      (d.locationAddress || '').toLowerCase().includes(sTerm) ||
      (d.locality || '').toLowerCase().includes(sTerm) ||
      (d.patientId || '').toLowerCase().includes(sTerm) ||
      (d.assignedStaffName || '').toLowerCase().includes(sTerm) ||
      (d.assignedStaffId || '').toLowerCase().includes(sTerm);

    const matchesStaff = selectedStaffFilter === 'All' || d.assignedStaffId === selectedStaffFilter;
    const matchesStatus = selectedStatusFilter === 'All' || d.status === selectedStatusFilter;
    const matchesCity = selectedCityFilter === 'All' || d.city?.toLowerCase() === selectedCityFilter.toLowerCase();

    return matchesSearch && matchesStaff && matchesStatus && matchesCity;
  });

  // Calculate high-level summary KPIs
  const totalDutiesCount = duties.length;
  const activeOngoingCount = duties.filter((d) => d.status === 'Ongoing').length;
  const completedCount = duties.filter((d) => d.status === 'Completed').length;
  const totalDaysServed = duties.reduce((acc, d) => acc + (d.totalDays || 0), 0);
  const totalHoursServed = duties.reduce((acc, d) => acc + (d.totalHours || 0), 0);

  // Extract unique cities
  const uniqueCities = Array.from(new Set(duties.map((d) => d.city).filter(Boolean)));

  return (
    <div className="space-y-6 font-sans">
      
      {/* Top Banner & Action Controls */}
      <div className="bg-gradient-to-br from-brand-navy to-brand-navy-light text-white p-6 sm:p-7 rounded-3xl shadow-lg border border-white/10 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-brand-magenta/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-white/10 mb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-brand-magenta uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-brand-magenta" />
              <span>Admin Operations • Staff Duty Allocation & Days Controller</span>
            </div>
            <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
              Staff Patient Duty & Deployment Manager
            </h2>
            <p className="text-xs sm:text-sm text-gray-300 max-w-2xl">
              स्टाफ ड्यूटी नियंत्रण — Control patient assignments, duty locations, total days worked (कितने दिन काम किया), and keep data synchronized with PostgreSQL database and staff profiles.
            </p>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={openNewDutyModal}
              className="w-full sm:w-auto bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold py-3 px-5 rounded-2xl transition-all shadow-lg shadow-brand-magenta/20 flex items-center justify-center gap-2 cursor-pointer active:scale-95 text-xs sm:text-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Assign New Patient Duty</span>
            </button>
          </div>
        </div>

        {/* 5 Core Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 relative z-10">
          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10">
            <span className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider block">Total Patient Duties</span>
            <p className="text-xl sm:text-2xl font-extrabold text-white mt-0.5">{totalDutiesCount}</p>
            <span className="text-[10px] text-emerald-400 font-medium">Database Synced</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10">
            <span className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider block">Ongoing Shifts</span>
            <p className="text-xl sm:text-2xl font-extrabold text-amber-400 mt-0.5">{activeOngoingCount}</p>
            <span className="text-[10px] text-gray-300 font-medium">Active on Field</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10">
            <span className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider block">Completed Duties</span>
            <p className="text-xl sm:text-2xl font-extrabold text-emerald-400 mt-0.5">{completedCount}</p>
            <span className="text-[10px] text-gray-300 font-medium">100% Verified</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10">
            <span className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider block">Total Duty Days</span>
            <p className="text-xl sm:text-2xl font-extrabold text-brand-magenta-light mt-0.5">{totalDaysServed} Days</p>
            <span className="text-[10px] text-gray-300 font-medium">Duration Control</span>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 col-span-2 sm:col-span-1">
            <span className="text-[10px] text-gray-300 font-semibold uppercase tracking-wider block">Total Duty Hours</span>
            <p className="text-xl sm:text-2xl font-extrabold text-white mt-0.5">{totalHoursServed} hrs</p>
            <span className="text-[10px] text-gray-300 font-medium">Logged Shifts</span>
          </div>
        </div>
      </div>

      {/* Action Notification Banner */}
      {actionSuccessMsg && (
        <div className="bg-emerald-50 text-emerald-800 p-4 rounded-2xl border border-emerald-200 text-xs sm:text-sm font-bold flex items-center gap-2.5 shadow-sm animate-in fade-in zoom-in-95">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-gray-200 shadow-sm space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
          
          {/* Search Box */}
          <div className="sm:col-span-5 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search by Patient Name, Staff Name, Locality, or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 pl-10 pr-4 py-2.5 rounded-xl text-xs font-medium focus:outline-none focus:border-brand-magenta focus:ring-2 focus:ring-brand-magenta/10"
            />
          </div>

          {/* Filter by Staff Member */}
          <div className="sm:col-span-3">
            <select
              value={selectedStaffFilter}
              onChange={(e) => setSelectedStaffFilter(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 px-3 py-2.5 rounded-xl text-xs font-bold text-brand-navy focus:outline-none focus:border-brand-magenta"
            >
              <option value="All">All Staff Members ({staffUsers.length})</option>
              {staffUsers.map((s) => (
                <option key={s.userId} value={s.userId}>
                  {s.name} ({s.userId})
                </option>
              ))}
            </select>
          </div>

          {/* Filter by Status */}
          <div className="sm:col-span-2">
            <select
              value={selectedStatusFilter}
              onChange={(e) => setSelectedStatusFilter(e.target.value as any)}
              className="w-full bg-gray-50 border border-gray-200 px-3 py-2.5 rounded-xl text-xs font-bold text-brand-navy focus:outline-none focus:border-brand-magenta"
            >
              <option value="All">All Statuses</option>
              <option value="Ongoing">Ongoing Shift</option>
              <option value="Completed">Completed Duty</option>
            </select>
          </div>

          {/* Filter by City */}
          <div className="sm:col-span-2">
            <select
              value={selectedCityFilter}
              onChange={(e) => setSelectedCityFilter(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 px-3 py-2.5 rounded-xl text-xs font-bold text-brand-navy focus:outline-none focus:border-brand-magenta"
            >
              <option value="All">All Cities</option>
              {uniqueCities.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick active filter indicator */}
        {(searchTerm || selectedStaffFilter !== 'All' || selectedStatusFilter !== 'All' || selectedCityFilter !== 'All') && (
          <div className="flex items-center justify-between pt-2 border-t border-gray-100 text-xs">
            <span className="text-gray-500 font-medium">
              Showing <strong className="text-brand-navy">{filteredDuties.length}</strong> of {duties.length} patient duty records
            </span>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedStaffFilter('All');
                setSelectedStatusFilter('All');
                setSelectedCityFilter('All');
              }}
              className="text-brand-magenta hover:underline font-bold text-xs cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Duty Records Grid / Cards */}
      {filteredDuties.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-dashed border-gray-200 p-8 space-y-3">
          <div className="w-14 h-14 bg-gray-100 text-gray-400 rounded-2xl flex items-center justify-center mx-auto">
            <Activity className="w-7 h-7" />
          </div>
          <h3 className="font-display font-bold text-lg text-brand-navy">No Staff Duties Found</h3>
          <p className="text-xs text-gray-500 max-w-md mx-auto">
            No patient duty records match your selected search or filter parameters. Click "Assign New Patient Duty" to create an assignment.
          </p>
          <button
            onClick={openNewDutyModal}
            className="mt-2 inline-flex items-center gap-1.5 bg-brand-magenta text-white text-xs font-bold px-4 py-2 rounded-xl shadow-sm hover:bg-brand-magenta-light transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Assign New Patient Duty
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredDuties.map((duty) => {
            const isExpanded = expandedDutyId === duty.id;
            return (
              <div
                key={duty.id}
                className="bg-white rounded-3xl border border-gray-200 shadow-sm hover:shadow-md transition-all overflow-hidden"
              >
                <div className="p-5 sm:p-6 border-b border-gray-100">
                  <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
                    
                    {/* Patient & Service Details */}
                    <div className="space-y-2 flex-grow min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-bold uppercase tracking-wider bg-brand-navy/10 text-brand-navy px-2.5 py-0.5 rounded-full">
                          {duty.serviceTitle}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                            duty.status === 'Completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {duty.status === 'Completed' ? '✓ Completed Duty' : '● Ongoing Active Shift'}
                        </span>
                        <span className="text-[11px] font-mono font-bold bg-gray-100 text-gray-700 px-2 py-0.5 rounded border border-gray-200">
                          Patient ID: {duty.patientId}
                        </span>
                      </div>

                      {/* Patient Name and assigned staff */}
                      <div className="flex flex-wrap items-center gap-3 pt-1">
                        <h3 className="font-display font-extrabold text-xl text-brand-navy flex items-center gap-2">
                          <User className="w-5 h-5 text-brand-magenta" />
                          <span>{duty.patientName}</span>
                        </h3>
                        {duty.patientAge && (
                          <span className="text-xs text-gray-500 font-medium">
                            ({duty.patientAge} Yrs, {duty.patientGender || 'Patient'})
                          </span>
                        )}
                      </div>

                      {/* Assigned Staff ID Badge */}
                      <div className="flex flex-wrap items-center gap-2 pt-0.5">
                        <div className="inline-flex items-center gap-1.5 bg-brand-magenta/10 border border-brand-magenta/20 px-3 py-1 rounded-xl text-xs font-bold text-brand-magenta">
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Assigned Staff: <strong>{duty.assignedStaffName}</strong></span>
                          <span className="font-mono bg-white px-1.5 py-0.2 rounded text-[10px] text-brand-navy">
                            {duty.assignedStaffId}
                          </span>
                        </div>
                        <span className="text-xs text-gray-500 hidden sm:inline">
                          ({duty.assignedStaffRole})
                        </span>
                      </div>

                      {/* Location & Address */}
                      <p className="text-xs text-gray-600 flex items-start gap-1.5 pt-1">
                        <MapPin className="w-4 h-4 text-brand-magenta shrink-0 mt-0.5" />
                        <span>
                          <strong className="text-brand-navy">{duty.locality}, {duty.city}:</strong> {duty.locationAddress}
                        </span>
                      </p>
                    </div>

                    {/* Duty Duration / Total Days Box (Prominent) */}
                    <div className="flex flex-wrap lg:flex-col items-start lg:items-end gap-2.5 shrink-0 bg-slate-50 lg:bg-transparent p-4 lg:p-0 rounded-2xl border border-gray-100 lg:border-none w-full lg:w-auto">
                      
                      {/* Prominent Days Pill */}
                      <div className="bg-brand-magenta text-white px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 shadow-md shadow-brand-magenta/20">
                        <Calendar className="w-4 h-4 text-white" />
                        <span>ड्यूटी अवधि: {duty.totalDays} Days ({duty.totalHours} hrs)</span>
                      </div>

                      <div className="text-left lg:text-right text-xs text-gray-500 space-y-0.5">
                        <span className="block font-bold text-brand-navy">
                          📅 {duty.startDate} to {duty.endDate}
                        </span>
                        <span className="text-[11px] text-gray-400 block">
                          {duty.totalShifts} Shifts Logged
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Clinical Protocols details */}
                  {duty.clinicalRequirement && (
                    <div className="mt-4 p-3.5 bg-brand-navy/5 rounded-2xl border border-brand-navy/10 text-xs text-brand-navy leading-relaxed">
                      <strong className="text-brand-navy block font-bold mb-0.5">Clinical Protocol & Duties:</strong>
                      {duty.clinicalRequirement}
                    </div>
                  )}

                  {/* Action Bar */}
                  <div className="mt-4 pt-4 border-t border-gray-100 flex flex-wrap justify-between items-center gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => openEditDutyModal(duty)}
                        className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-brand-navy rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5 text-brand-magenta" /> Edit Duty & Days
                      </button>

                      <button
                        onClick={() => handleToggleStatus(duty)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                          duty.status === 'Completed'
                            ? 'bg-amber-50 hover:bg-amber-100 text-amber-800'
                            : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        <Check className="w-3.5 h-3.5" />
                        {duty.status === 'Completed' ? 'Reopen as Ongoing' : 'Mark as Completed'}
                      </button>

                      <button
                        onClick={() => handleDeleteDuty(duty)}
                        className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl text-xs font-semibold transition-all flex items-center gap-1 cursor-pointer"
                        title="Delete Duty Record"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Delete
                      </button>
                    </div>

                    <button
                      onClick={() => setExpandedDutyId(isExpanded ? null : duty.id)}
                      className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-brand-navy rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <span>{isExpanded ? 'Hide Shift Logs' : `Daily Logs (${duty.dailyLogs?.length || 0})`}</span>
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Expandable shift log list */}
                {isExpanded && (
                  <div className="p-5 bg-gray-50/80 border-t border-gray-100 space-y-3">
                    <h4 className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-brand-magenta" />
                      <span>Daily Shift Logs & Attendance Timestamps ({duty.totalDays} Days)</span>
                    </h4>

                    {!duty.dailyLogs || duty.dailyLogs.length === 0 ? (
                      <p className="text-xs text-gray-500 italic bg-white p-3.5 rounded-xl border border-gray-200">
                        No individual attendance timestamp logs recorded yet for this patient duty.
                      </p>
                    ) : (
                      <div className="overflow-x-auto bg-white rounded-2xl border border-gray-200 shadow-sm">
                        <table className="w-full text-left text-xs">
                          <thead>
                            <tr className="bg-gray-50 text-gray-600 border-b border-gray-200">
                              <th className="py-2.5 px-3.5 font-bold">Shift Date</th>
                              <th className="py-2.5 px-3.5 font-bold">Check-In</th>
                              <th className="py-2.5 px-3.5 font-bold">Check-Out</th>
                              <th className="py-2.5 px-3.5 font-bold">Hours</th>
                              <th className="py-2.5 px-3.5 font-bold">Location / GPS</th>
                              <th className="py-2.5 px-3.5 font-bold">Clinical Notes</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                            {duty.dailyLogs.map((log) => (
                              <tr key={log.id} className="hover:bg-gray-50/60">
                                <td className="py-2.5 px-3.5 font-semibold text-brand-navy">{log.date}</td>
                                <td className="py-2.5 px-3.5 font-mono text-gray-700">
                                  {log.checkInTime ? new Date(log.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                                </td>
                                <td className="py-2.5 px-3.5 font-mono text-gray-700">
                                  {log.checkOutTime ? new Date(log.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Ongoing'}
                                </td>
                                <td className="py-2.5 px-3.5 font-bold text-brand-magenta">{log.shiftHours} hrs</td>
                                <td className="py-2.5 px-3.5 text-gray-600">
                                  <span>{log.location}</span>
                                  {log.gpsVerified && (
                                    <span className="text-[10px] text-emerald-600 font-bold block">✓ GPS Verified</span>
                                  )}
                                </td>
                                <td className="py-2.5 px-3.5 text-gray-600 max-w-xs truncate">{log.actionNotes || 'Duty active'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Duty Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl border border-gray-150 relative space-y-5 my-8 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-start border-b border-gray-100 pb-4">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-brand-magenta bg-brand-magenta/10 px-2.5 py-1 rounded-full">
                    {editingDutyId ? 'Edit Duty Details' : 'New Staff Duty Allocation'}
                  </span>
                  <h3 className="font-display font-extrabold text-xl text-brand-navy mt-1.5">
                    {editingDutyId ? 'Update Patient Duty & Duration' : 'Assign Patient Duty to Staff'}
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Changes will immediately synchronize to PostgreSQL database and the staff member's profile chart.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-all cursor-pointer shrink-0"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveDutySubmit} className="space-y-4">
                
                {/* 1. Assigned Staff Member */}
                <div className="bg-brand-navy/5 p-4 rounded-2xl border border-brand-navy/10 space-y-2">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4 text-brand-magenta" /> Select Staff Member to Deploy
                  </label>
                  <select
                    value={assignedStaffId}
                    onChange={(e) => setAssignedStaffId(e.target.value)}
                    className="w-full bg-white border border-gray-200 px-3.5 py-2.5 rounded-xl text-xs font-bold text-brand-navy focus:outline-none focus:border-brand-magenta"
                    required
                  >
                    {staffUsers.map((s) => (
                      <option key={s.userId} value={s.userId}>
                        {s.name} ({s.userId}) — {s.role} [{s.status}]
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Patient Personal Details */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2 flex flex-col gap-1">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                      Patient Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Smt. Sharda Sharma"
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 px-3.5 py-2.5 rounded-xl text-xs font-semibold focus:border-brand-magenta focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                        Age
                      </label>
                      <input
                        type="number"
                        placeholder="e.g. 68"
                        value={patientAge}
                        onChange={(e) => setPatientAge(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 px-3 py-2.5 rounded-xl text-xs font-semibold focus:border-brand-magenta focus:outline-none"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                        Gender
                      </label>
                      <select
                        value={patientGender}
                        onChange={(e) => setPatientGender(e.target.value as any)}
                        className="w-full bg-gray-50 border border-gray-200 px-2 py-2.5 rounded-xl text-xs font-semibold focus:border-brand-magenta focus:outline-none"
                      >
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* 3. Service Title and Patient Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                      Service / Clinical Category
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. ICU / Post-Operative Critical Care"
                      value={serviceTitle}
                      onChange={(e) => setServiceTitle(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 px-3.5 py-2.5 rounded-xl text-xs font-semibold focus:border-brand-magenta focus:outline-none"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                      Patient / Attendant Phone
                    </label>
                    <input
                      type="tel"
                      placeholder="e.g. 9414011223"
                      value={patientPhone}
                      onChange={(e) => setPatientPhone(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 px-3.5 py-2.5 rounded-xl text-xs font-semibold focus:border-brand-magenta focus:outline-none"
                    />
                  </div>
                </div>

                {/* 4. Location & Address */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                      City
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Jaipur"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 px-3.5 py-2.5 rounded-xl text-xs font-semibold focus:border-brand-magenta focus:outline-none"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                      Locality / Area
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Mansarovar"
                      value={locality}
                      onChange={(e) => setLocality(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 px-3.5 py-2.5 rounded-xl text-xs font-semibold focus:border-brand-magenta focus:outline-none"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                      Status
                    </label>
                    <select
                      value={status}
                      onChange={(e) => setStatus(e.target.value as any)}
                      className="w-full bg-gray-50 border border-gray-200 px-3 py-2.5 rounded-xl text-xs font-bold text-brand-navy focus:outline-none"
                    >
                      <option value="Ongoing">● Ongoing Shift</option>
                      <option value="Completed">✓ Completed Duty</option>
                    </select>
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                    Full Street Address / Residence *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Flat 304, Ganesham Heights, Near Swarn Path, Mansarovar, Jaipur"
                    value={locationAddress}
                    onChange={(e) => setLocationAddress(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 px-3.5 py-2.5 rounded-xl text-xs font-semibold focus:border-brand-magenta focus:outline-none"
                  />
                </div>

                {/* 5. Duty Dates & Duration in Days (Core user requirement) */}
                <div className="bg-amber-50/60 p-4 rounded-2xl border border-amber-200/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-brand-magenta" /> Duty Dates & Duration in Days (कितने दिन ड्यूटी की)
                    </label>
                    <span className="text-[11px] font-extrabold text-brand-magenta bg-white px-2.5 py-0.5 rounded-full border border-amber-200">
                      Total: {totalDays} Days
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="flex flex-col gap-1">
                      <span className="text-[11px] font-bold text-gray-700">Start Date</span>
                      <input
                        type="date"
                        required
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="bg-white border border-gray-200 px-3 py-2 rounded-xl text-xs font-semibold focus:outline-none focus:border-brand-magenta"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-[11px] font-bold text-gray-700">End Date</span>
                      <input
                        type="date"
                        required
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        className="bg-white border border-gray-200 px-3 py-2 rounded-xl text-xs font-semibold focus:outline-none focus:border-brand-magenta"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-[11px] font-bold text-gray-700">Custom Days</span>
                      <input
                        type="number"
                        min="1"
                        value={totalDays}
                        onChange={(e) => {
                          const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                          setTotalDays(val);
                          setTotalShifts(val);
                          setTotalHours(val * 12);
                        }}
                        className="bg-white border border-gray-200 px-3 py-2 rounded-xl text-xs font-bold text-brand-navy focus:outline-none focus:border-brand-magenta"
                      />
                    </div>
                  </div>
                </div>

                {/* 6. Clinical Protocol & Highlights */}
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                    Clinical Protocols & Care Instructions
                  </label>
                  <textarea
                    rows={2}
                    placeholder="e.g. ICU setup at home, continuous vitals monitoring, oxygen support, wound dressing."
                    value={clinicalRequirement}
                    onChange={(e) => setClinicalRequirement(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 p-3 rounded-xl text-xs focus:border-brand-magenta focus:outline-none"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                    Duty Highlights / Key Notes (One per line)
                  </label>
                  <textarea
                    rows={2}
                    placeholder="• Monitored daily vitals (BP, SPO2, Pulse)&#10;• Assisted with mobility and oral hygiene&#10;• Timely medication charting"
                    value={dutyHighlightsText}
                    onChange={(e) => setDutyHighlightsText(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 p-3 rounded-xl text-xs focus:border-brand-magenta focus:outline-none font-sans"
                  />
                </div>

                {/* Form Buttons */}
                <div className="flex gap-3 pt-3 border-t border-gray-100">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 py-3 px-4 rounded-xl border border-gray-200 text-gray-600 font-bold text-xs hover:bg-gray-50 transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 py-3 px-4 rounded-xl bg-brand-magenta hover:bg-brand-magenta-light text-white font-extrabold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isSaving ? (
                      <span>Syncing to Database...</span>
                    ) : (
                      <>
                        <Check className="w-4 h-4" />
                        <span>{editingDutyId ? 'Save & Sync Changes' : 'Assign & Sync Duty'}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
