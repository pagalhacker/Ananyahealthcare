import React, { useState, useEffect } from 'react';
import { getLocalBrandSettings, BRAND_UPDATED_EVENT, fetchAndSyncBrandSettings } from '../utils/brandHelper';

interface LogoProps {
  className?: string;
  layout?: 'horizontal' | 'vertical' | 'icon-only';
  iconSize?: number;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  layout = 'horizontal',
  iconSize = 48,
}) => {
  const [brandSettings, setBrandSettings] = useState(getLocalBrandSettings());

  useEffect(() => {
    // Initial sync with Firestore
    fetchAndSyncBrandSettings().then((synced) => {
      setBrandSettings(synced);
    });

    // Listen for live updates when changed in Admin Panel
    const handleUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        setBrandSettings(customEvent.detail);
      } else {
        setBrandSettings(getLocalBrandSettings());
      }
    };

    window.addEventListener(BRAND_UPDATED_EVENT, handleUpdate);
    return () => {
      window.removeEventListener(BRAND_UPDATED_EVENT, handleUpdate);
    };
  }, []);

  return (
    <div className={`flex items-center select-none ${layout === 'vertical' ? 'flex-col text-center' : 'flex-row gap-3'} ${className}`}>
      <img
        src={brandSettings.logoUrl}
        alt={`${brandSettings.brandName} Logo`}
        referrerPolicy="no-referrer"
        style={{ height: iconSize, width: 'auto' }}
        className="shrink-0 transition-transform duration-300 hover:scale-105 object-contain max-w-[220px]"
        onError={(e) => {
          // Fallback if image fails to load
          (e.target as HTMLImageElement).src = 'https://cdn.phototourl.com/free/2026-07-14-44a66428-3fc7-42cc-98ce-a35b8e19dccb.png';
        }}
      />

      {/* Brand Text styled dynamically */}
      {layout !== 'icon-only' && (
        <div className={`flex flex-col ${layout === 'vertical' ? 'items-center mt-3' : 'items-start'}`}>
          <span
            className="font-display font-black leading-none text-brand-navy tracking-tight"
            style={{
              fontSize: layout === 'vertical' ? '2.5rem' : '1.75rem',
              letterSpacing: '-0.02em',
            }}
          >
            {brandSettings.brandName}
          </span>
          <span
            className="font-display font-extrabold uppercase tracking-widest text-brand-magenta"
            style={{
              fontSize: layout === 'vertical' ? '0.85rem' : '0.625rem',
              marginTop: '0.25rem',
              letterSpacing: '0.18em',
            }}
          >
            {brandSettings.tagline}
          </span>
        </div>
      )}
    </div>
  );
};
