import React, { useState, useEffect } from 'react';
import { VitalRecord } from '../types';
import { ServiceSparkline } from './ServiceSparkline';
import { 
  getVitalsForPatient, 
  addVitalRecord, 
  deleteVitalRecord 
} from '../utils/vitalsHelper';
import { 
  Activity, 
  Heart, 
  TrendingUp, 
  History, 
  PlusCircle, 
  Trash2, 
  Check, 
  AlertCircle,
  Calendar,
  Thermometer,
  Clock
} from 'lucide-react';

interface PatientVitalsWidgetProps {
  patientId: string;
  patientName: string;
  allowLogging?: boolean; // True for Staff and Admin, False for Family or view-only
  onDataChanged?: () => void;
}

export const PatientVitalsWidget: React.FC<PatientVitalsWidgetProps> = ({
  patientId,
  patientName,
  allowLogging = false,
  onDataChanged
}) => {
  const [vitals, setVitals] = useState<VitalRecord[]>([]);
  const [activeMetric, setActiveMetric] = useState<'temperature' | 'bloodPressure' | 'heartRate'>('temperature');
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [showAddForm, setShowAddForm] = useState<boolean>(false);

  // Form fields
  const [temperature, setTemperature] = useState<string>('98.6');
  const [bpSystolic, setBpSystolic] = useState<string>('120');
  const [bpDiastolic, setBpDiastolic] = useState<string>('80');
  const [heartRate, setHeartRate] = useState<string>('72');
  const [timestamp, setTimestamp] = useState<string>('');

  // Notifications
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Reload data
  const reloadData = () => {
    setVitals(getVitalsForPatient(patientId));
  };

  useEffect(() => {
    reloadData();
    // Default log date as today's local date
    const today = new Date().toISOString().split('T')[0];
    setTimestamp(today);
  }, [patientId]);

  const handleAddVitals = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg('');
    setErrorMsg('');

    const tempVal = parseFloat(temperature);
    const sysVal = parseInt(bpSystolic);
    const diaVal = parseInt(bpDiastolic);
    const hrVal = parseInt(heartRate);

    // Form validation
    if (isNaN(tempVal) || tempVal < 90 || tempVal > 110) {
      setErrorMsg('Clinical temperature must be between 90°F and 110°F.');
      return;
    }
    if (isNaN(sysVal) || sysVal < 50 || sysVal > 250) {
      setErrorMsg('Systolic BP must be between 50 and 250 mmHg.');
      return;
    }
    if (isNaN(diaVal) || diaVal < 30 || diaVal > 150) {
      setErrorMsg('Diastolic BP must be between 30 and 150 mmHg.');
      return;
    }
    if (isNaN(hrVal) || hrVal < 30 || hrVal > 220) {
      setErrorMsg('Pulse rate must be between 30 and 220 bpm.');
      return;
    }
    if (!timestamp) {
      setErrorMsg('Please select a valid logging date.');
      return;
    }

    // Save record
    addVitalRecord({
      patientId: patientId,
      patientName: patientName,
      temperature: Number(tempVal.toFixed(1)),
      bpSystolic: sysVal,
      bpDiastolic: diaVal,
      heartRate: hrVal,
      timestamp: timestamp
    });

    reloadData();
    setSuccessMsg('Patient vitals recorded successfully and synced!');
    setShowAddForm(false);
    
    // Clear inputs
    setTemperature('98.6');
    setBpSystolic('120');
    setBpDiastolic('80');
    setHeartRate('72');

    if (onDataChanged) onDataChanged();

    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Delete this clinical vitals entry?')) {
      deleteVitalRecord(id);
      reloadData();
      if (onDataChanged) onDataChanged();
    }
  };

  const getLatestLog = () => {
    if (vitals.length === 0) return null;
    return [...vitals].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())[0];
  };

  const latest = getLatestLog();

  return (
    <div className="bg-slate-50 border border-gray-150 rounded-2xl p-4 sm:p-5 mt-3 space-y-4 shadow-sm text-gray-700">
      {/* Widget Header with action controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-brand-magenta shrink-0 animate-pulse" />
          <div>
            <div className="flex items-center gap-1.5">
              <h5 className="text-xs font-black uppercase tracking-wider text-brand-navy">
                Clinical Vitals Tracker
              </h5>
              <span className="text-[10px] bg-brand-navy text-white px-2 py-0.5 rounded-full font-mono font-bold uppercase shrink-0">
                {patientId}
              </span>
            </div>
            <p className="text-[10px] text-gray-500 font-medium">
              Vitals history and real-time trends for <strong>{patientName}</strong>
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          {allowLogging && (
            <button
              type="button"
              onClick={() => {
                setShowAddForm(!showAddForm);
                setShowHistory(false);
              }}
              className={`text-[10px] md:text-xs font-bold py-1.5 px-3 rounded-lg border flex items-center gap-1 cursor-pointer transition-all ${
                showAddForm
                  ? 'bg-brand-navy text-white border-brand-navy'
                  : 'bg-white text-brand-navy border-gray-200 hover:border-gray-300'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5" />
              {showAddForm ? 'Hide Form' : 'Log New Vitals'}
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              setShowHistory(!showHistory);
              setShowAddForm(false);
            }}
            className={`text-[10px] md:text-xs font-bold py-1.5 px-3 rounded-lg border flex items-center gap-1 cursor-pointer transition-all ${
              showHistory
                ? 'bg-brand-navy text-white border-brand-navy'
                : 'bg-white text-brand-navy border-gray-200 hover:border-gray-300'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            History ({vitals.length})
          </button>
        </div>
      </div>

      {/* Messages */}
      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs py-2 px-3 rounded-xl flex items-center gap-1.5 font-semibold">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          {successMsg}
        </div>
      )}
      {errorMsg && (
        <div className="bg-red-50 border border-red-200 text-red-800 text-xs py-2 px-3 rounded-xl flex items-center gap-1.5 font-semibold">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          {errorMsg}
        </div>
      )}

      {/* 1. Add Vitals Form */}
      {showAddForm && (
        <form onSubmit={handleAddVitals} className="bg-white border border-gray-150 p-4 rounded-xl space-y-3.5 shadow-inner">
          <p className="text-xs font-bold text-brand-navy flex items-center gap-1">
            📝 Record Measurements for {patientName}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase">Logging Date</label>
              <div className="relative mt-1">
                <Calendar className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input
                  type="date"
                  value={timestamp}
                  onChange={(e) => setTimestamp(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-gray-250 px-3 py-2.5 pl-9 rounded-lg focus:outline-none focus:border-brand-magenta font-semibold text-brand-navy"
                  required
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase flex items-center gap-0.5">
                <Thermometer className="w-3.5 h-3.5 text-red-500" /> Temp (°F)
              </label>
              <input
                type="number"
                step="0.1"
                placeholder="98.6"
                value={temperature}
                onChange={(e) => setTemperature(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-gray-250 px-3 py-2 rounded-lg focus:outline-none focus:border-brand-magenta font-mono font-bold text-center mt-1 text-red-600"
                required
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase">BP (Sys/Dia)</label>
              <div className="flex gap-1 items-center mt-1">
                <input
                  type="number"
                  placeholder="Sys"
                  value={bpSystolic}
                  onChange={(e) => setBpSystolic(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-gray-250 py-2 px-1 rounded-lg focus:outline-none focus:border-brand-magenta font-mono font-bold text-center text-blue-600"
                  required
                />
                <span className="text-gray-400 font-bold text-xs shrink-0">/</span>
                <input
                  type="number"
                  placeholder="Dia"
                  value={bpDiastolic}
                  onChange={(e) => setBpDiastolic(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-gray-250 py-2 px-1 rounded-lg focus:outline-none focus:border-brand-magenta font-mono font-bold text-center text-cyan-600"
                  required
                />
              </div>
            </div>
            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase flex items-center gap-0.5">
                <Heart className="w-3.5 h-3.5 text-pink-500" /> Pulse (BPM)
              </label>
              <input
                type="number"
                placeholder="72"
                value={heartRate}
                onChange={(e) => setHeartRate(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-gray-250 px-3 py-2 rounded-lg focus:outline-none focus:border-brand-magenta font-mono font-bold text-center mt-1 text-pink-600"
                required
              />
            </div>
          </div>

          <div className="flex gap-2 justify-end pt-2">
            <button
              type="submit"
              className="bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold py-2 px-4 rounded-lg text-xs cursor-pointer"
            >
              Save Record
            </button>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="border border-gray-200 hover:bg-gray-50 text-gray-500 py-2 px-3 rounded-lg text-xs cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* 2. History Timeline */}
      {showHistory && (
        <div className="bg-white border border-gray-150 p-4 rounded-xl space-y-3 shadow-inner max-h-[220px] overflow-y-auto">
          <p className="text-xs font-bold text-brand-navy flex items-center justify-between">
            <span>📝 Clinical Logs Timeline</span>
            <span className="text-[10px] font-mono text-gray-400">{vitals.length} records</span>
          </p>
          <div className="divide-y divide-gray-100 text-xs">
            {vitals.map((rec) => (
              <div key={rec.id} className="py-2.5 flex items-center justify-between gap-4 first:pt-0 last:pb-0 hover:bg-slate-50/50 px-1 rounded">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400 font-mono font-semibold bg-gray-50 px-1.5 py-0.5 rounded border border-gray-100">{rec.timestamp}</span>
                  </div>
                  <div className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] pt-0.5">
                    <span className="text-red-600 font-semibold flex items-center gap-0.5">
                      🌡️ Temp: <strong className="font-mono">{rec.temperature}°F</strong>
                    </span>
                    <span className="text-blue-600 font-semibold flex items-center gap-0.5">
                      🩺 BP: <strong className="font-mono">{rec.bpSystolic}/{rec.bpDiastolic}</strong>
                    </span>
                    <span className="text-pink-600 font-semibold flex items-center gap-0.5">
                      ❤️ Pulse: <strong className="font-mono">{rec.heartRate} bpm</strong>
                    </span>
                  </div>
                </div>
                {allowLogging && (
                  <button
                    type="button"
                    onClick={() => handleDelete(rec.id)}
                    className="text-gray-400 hover:text-red-500 p-1 rounded-lg hover:bg-red-50 transition-colors cursor-pointer"
                    title="Delete record"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
            {vitals.length === 0 && (
              <p className="text-center py-4 text-xs text-gray-400 italic">No logs found for this Patient ID.</p>
            )}
          </div>
        </div>
      )}

      {/* 3. Trends & Sparkline Chart */}
      {!showAddForm && !showHistory && (
        <div className="space-y-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
            {/* Metric Tabs */}
            <div className="flex bg-white border border-gray-200 p-1 rounded-xl w-fit">
              {[
                { id: 'temperature', label: 'Temperature' },
                { id: 'bloodPressure', label: 'Blood Pressure' },
                { id: 'heartRate', label: 'Pulse Rate' }
              ].map((tab) => {
                const isActive = activeMetric === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveMetric(tab.id as any)}
                    className={`px-3 py-1.5 text-[10px] md:text-xs font-bold rounded-lg cursor-pointer transition-all ${
                      isActive 
                        ? 'bg-brand-navy text-white shadow-sm' 
                        : 'text-gray-500 hover:text-gray-800'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Latest Summary */}
            {latest && (
              <div className="text-[10px] bg-white border border-gray-150 px-3 py-1.5 rounded-xl flex items-center gap-3.5 shadow-sm">
                <span className="text-gray-400 uppercase font-black text-[9px] border-r border-gray-100 pr-2.5 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-brand-magenta" /> Latest:
                </span>
                <span className="text-red-600 font-bold flex items-center gap-0.5">
                  🌡️ {latest.temperature}°F
                </span>
                <span className="text-blue-600 font-bold flex items-center gap-0.5">
                  🩺 {latest.bpSystolic}/{latest.bpDiastolic}
                </span>
                <span className="text-pink-600 font-bold flex items-center gap-0.5">
                  ❤️ {latest.heartRate} bpm
                </span>
              </div>
            )}
          </div>

          {/* Sparkline trend canvas */}
          <div className="bg-white border border-gray-150 p-3 rounded-xl shadow-sm relative">
            <ServiceSparkline data={vitals} metric={activeMetric} />
            <div className="mt-2 flex justify-between items-center text-[9px] font-mono text-gray-400">
              {vitals.length > 0 ? (
                <>
                  <span className="flex items-center gap-1">
                    <Clock className="w-2.5 h-2.5" /> Start: {[...vitals].sort((a,b)=>new Date(a.timestamp).getTime()-new Date(b.timestamp).getTime())[0].timestamp}
                  </span>
                  <span>Trend Analysis</span>
                  <span>
                    Last: {[...vitals].sort((a,b)=>new Date(b.timestamp).getTime()-new Date(a.timestamp).getTime())[0].timestamp}
                  </span>
                </>
              ) : (
                <span className="mx-auto">No clinical records available to chart.</span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
