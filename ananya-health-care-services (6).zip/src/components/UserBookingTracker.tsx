import React, { useState, useEffect } from 'react';
import { Booking, UserProfile } from '../types';
import { ensurePatientIdsOnBookings, BOOKINGS_STORAGE_KEY } from '../utils/vitalsHelper';
import { PatientVitalsWidget } from './PatientVitalsWidget';
import { 
  CalendarCheck, 
  Search, 
  MapPin, 
  Calendar, 
  Phone, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Activity, 
  Copy, 
  Check, 
  ChevronRight, 
  Heart, 
  ShieldCheck, 
  Stethoscope, 
  Package, 
  ExternalLink,
  RefreshCw,
  PlusCircle,
  MessageCircle,
  X,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface UserBookingTrackerProps {
  currentUser: UserProfile;
  onBookNew: (itemName?: string, type?: 'service' | 'equipment') => void;
  onOpenFamilyPortal: (patientId?: string) => void;
}

export const UserBookingTracker: React.FC<UserBookingTrackerProps> = ({
  currentUser,
  onBookNew,
  onOpenFamilyPortal,
}) => {
  const [allBookings, setAllBookings] = useState<Booking[]>([]);
  const [userBookings, setUserBookings] = useState<Booking[]>([]);
  const [searchIdQuery, setSearchIdQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<'all' | 'service' | 'equipment'>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedVitalsBooking, setSelectedVitalsBooking] = useState<Booking | null>(null);
  const [manualSearchResult, setManualSearchResult] = useState<Booking | null>(null);
  const [searchError, setSearchError] = useState<string>('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Load bookings from localStorage
  const loadBookings = () => {
    setIsRefreshing(true);
    try {
      const stored = localStorage.getItem(BOOKINGS_STORAGE_KEY);
      let parsed: Booking[] = [];
      if (stored) {
        try {
          parsed = JSON.parse(stored);
        } catch {
          parsed = [];
        }
      }

      const withIds = ensurePatientIdsOnBookings(parsed);
      setAllBookings(withIds);

      // Filter bookings matching current user
      const userEmail = (currentUser.email || '').trim().toLowerCase();
      const userPhone = (currentUser.phone || '').replace(/\D/g, '');
      const userName = (currentUser.name || '').trim().toLowerCase();

      const matched = withIds.filter((b) => {
        const bEmail = (b.email || '').trim().toLowerCase();
        const bPhone = (b.phoneNumber || '').replace(/\D/g, '');
        const bName = (b.customerName || '').trim().toLowerCase();

        const emailMatch = userEmail && bEmail && (bEmail === userEmail || bEmail.includes(userEmail) || userEmail.includes(bEmail));
        const phoneMatch = userPhone && bPhone && (bPhone.includes(userPhone) || userPhone.includes(bPhone));
        const nameMatch = userName && bName && (bName === userName || bName.includes(userName));

        return emailMatch || phoneMatch || nameMatch;
      });

      setUserBookings(matched);
    } catch (e) {
      console.warn('Error loading bookings for tracker:', e);
    } finally {
      setTimeout(() => setIsRefreshing(false), 300);
    }
  };

  useEffect(() => {
    loadBookings();
    
    // Listen for external storage or booking events
    const handleStorageChange = () => loadBookings();
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [currentUser]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(text);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleManualSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchError('');
    setManualSearchResult(null);

    const q = searchIdQuery.trim().toUpperCase();
    if (!q) {
      setSearchError('Please enter a Booking Reference ID or Patient ID');
      return;
    }

    const cleanNum = q.replace(/\D/g, '');
    const found = allBookings.find(
      (b) =>
        (b.id && String(b.id).toUpperCase().includes(q)) ||
        (b.patientId && String(b.patientId).toUpperCase() === q) ||
        (cleanNum.length >= 6 && b.phoneNumber && String(b.phoneNumber).replace(/\D/g, '').includes(cleanNum))
    );

    if (found) {
      setManualSearchResult(found);
    } else {
      setSearchError(`No booking record found matching "${q}". Check the ID and try again.`);
    }
  };

  // Filtered list of user's bookings
  const filteredUserBookings = userBookings.filter((b) => {
    if (filterType !== 'all' && b.type !== filterType) return false;
    if (filterStatus !== 'all' && b.status !== filterStatus) return false;
    return true;
  });

  const activeCount = userBookings.filter((b) => b.status === 'Confirmed').length;
  const pendingCount = userBookings.filter((b) => b.status === 'Pending').length;

  return (
    <section id="user-booking-tracker-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="bg-white rounded-3xl border border-gray-150 shadow-xl overflow-hidden">
        
        {/* Top Header Banner */}
        <div className="bg-gradient-to-r from-brand-navy via-brand-navy-light to-brand-navy p-6 sm:p-8 text-white relative overflow-hidden">
          <div className="absolute right-0 top-0 w-96 h-96 bg-brand-magenta/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
          
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-start sm:items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-brand-magenta/20 border border-brand-magenta/40 flex items-center justify-center font-display font-black text-2xl text-brand-magenta-light shrink-0 shadow-inner">
                {(currentUser.name || 'U').charAt(0).toUpperCase()}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-brand-magenta-light uppercase tracking-widest bg-brand-magenta/20 border border-brand-magenta/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Live Booking Tracker
                  </span>
                  <span className="text-xs text-gray-300 capitalize bg-white/10 px-2.5 py-0.5 rounded-full border border-white/10">
                    {currentUser.role || 'Patient'} Account
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-display font-extrabold text-white tracking-tight">
                  Welcome back, {currentUser.name || 'Valued Member'}
                </h2>
                <p className="text-xs sm:text-sm text-gray-300 font-light flex items-center gap-3 flex-wrap">
                  <span>Registered: <strong className="font-semibold text-white">{currentUser.email}</strong></span>
                  {currentUser.phone && (
                    <span>• Phone: <strong className="font-semibold text-white">+91 {currentUser.phone}</strong></span>
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 flex-wrap sm:self-auto">
              <button
                type="button"
                onClick={loadBookings}
                disabled={isRefreshing}
                className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold py-2.5 px-4 rounded-xl border border-white/20 transition-all cursor-pointer disabled:opacity-50"
                title="Refresh booking records"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-brand-magenta-light' : ''}`} />
                <span>Refresh Status</span>
              </button>

              <button
                type="button"
                onClick={() => onBookNew()}
                className="inline-flex items-center gap-2 bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold py-2.5 px-5 rounded-xl shadow-lg shadow-brand-magenta/25 transition-all cursor-pointer active:scale-95"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Book New Care</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/10">
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-3.5 border border-white/10">
              <p className="text-[11px] font-semibold text-gray-300 uppercase tracking-wider">Total Bookings</p>
              <p className="text-2xl font-display font-black text-white mt-0.5">{userBookings.length}</p>
            </div>
            <div className="bg-emerald-500/10 backdrop-blur-sm rounded-2xl p-3.5 border border-emerald-500/20">
              <p className="text-[11px] font-semibold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Active / Confirmed
              </p>
              <p className="text-2xl font-display font-black text-emerald-300 mt-0.5">{activeCount}</p>
            </div>
            <div className="bg-amber-500/10 backdrop-blur-sm rounded-2xl p-3.5 border border-amber-500/20">
              <p className="text-[11px] font-semibold text-amber-300 uppercase tracking-wider">Under Verification</p>
              <p className="text-2xl font-display font-black text-amber-300 mt-0.5">{pendingCount}</p>
            </div>
            <div className="bg-purple-500/10 backdrop-blur-sm rounded-2xl p-3.5 border border-purple-500/20">
              <p className="text-[11px] font-semibold text-purple-300 uppercase tracking-wider">24/7 Helpline</p>
              <p className="text-sm font-display font-bold text-purple-200 mt-1 truncate">+91 7734931740</p>
            </div>
          </div>

        </div>

        {/* Search & Quick Lookup Bar */}
        <div className="p-6 sm:p-8 bg-slate-50/70 border-b border-gray-150 space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            
            {/* Direct ID Search Form */}
            <form onSubmit={handleManualSearch} className="flex-1 max-w-xl flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Track by Booking ID (ANANYA-...) or Patient ID (PAT1001)..."
                  value={searchIdQuery}
                  onChange={(e) => setSearchIdQuery(e.target.value)}
                  className="w-full bg-white border border-gray-200 pl-10 pr-4 py-2.5 rounded-xl text-xs font-medium focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5 focus:outline-none transition-all placeholder:text-gray-400"
                />
              </div>
              <button
                type="submit"
                className="bg-brand-navy hover:bg-brand-navy-light text-white px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer shrink-0"
              >
                Track ID
              </button>
            </form>

            {/* Filter Tabs */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="inline-flex bg-white p-1 rounded-xl border border-gray-200 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setFilterType('all')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    filterType === 'all' ? 'bg-brand-magenta text-white shadow-sm' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  All Types
                </button>
                <button
                  type="button"
                  onClick={() => setFilterType('service')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    filterType === 'service' ? 'bg-brand-magenta text-white shadow-sm' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Nursing & Care
                </button>
                <button
                  type="button"
                  onClick={() => setFilterType('equipment')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    filterType === 'equipment' ? 'bg-brand-magenta text-white shadow-sm' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Medical Equipment
                </button>
              </div>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="bg-white border border-gray-200 text-gray-700 text-xs font-semibold py-2 px-3 rounded-xl focus:border-brand-magenta focus:outline-none cursor-pointer"
              >
                <option value="all">All Statuses</option>
                <option value="Confirmed">Confirmed</option>
                <option value="Pending">Pending</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>

          </div>

          {/* Manual search error */}
          {searchError && (
            <div className="bg-red-50 text-red-700 text-xs p-3 rounded-xl border border-red-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                <span>{searchError}</span>
              </div>
              <button
                type="button"
                onClick={() => setSearchError('')}
                className="text-red-500 hover:text-red-700 text-xs font-bold"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* Manual search result card popup */}
          {manualSearchResult && (
            <div className="bg-white rounded-2xl p-5 border-2 border-brand-magenta/30 shadow-md relative space-y-4">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  <span className="bg-brand-magenta/10 text-brand-magenta text-[11px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                    Search Result
                  </span>
                  <span className="text-xs font-mono text-gray-500">#{manualSearchResult.id}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setManualSearchResult(null)}
                  className="p-1 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <p className="text-gray-400 font-semibold uppercase text-[10px]">Patient / Customer</p>
                  <p className="font-bold text-brand-navy mt-0.5">{manualSearchResult.customerName}</p>
                  {manualSearchResult.patientId && (
                    <span className="inline-block mt-1 bg-brand-navy/5 text-brand-navy px-2 py-0.5 rounded text-[10px] font-mono font-bold">
                      Patient ID: {manualSearchResult.patientId}
                    </span>
                  )}
                </div>
                <div>
                  <p className="text-gray-400 font-semibold uppercase text-[10px]">Requested Item</p>
                  <p className="font-bold text-brand-magenta mt-0.5">{manualSearchResult.itemSelected}</p>
                  <p className="text-gray-500 text-[11px] capitalize">{manualSearchResult.type}</p>
                </div>
                <div>
                  <p className="text-gray-400 font-semibold uppercase text-[10px]">Live Status</p>
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold mt-1 ${
                    manualSearchResult.status === 'Confirmed'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : manualSearchResult.status === 'Pending'
                      ? 'bg-amber-50 text-amber-700 border border-amber-200'
                      : manualSearchResult.status === 'Completed'
                      ? 'bg-blue-50 text-blue-700 border border-blue-200'
                      : 'bg-red-50 text-red-700 border border-red-200'
                  }`}>
                    {manualSearchResult.status === 'Confirmed' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />}
                    {manualSearchResult.status}
                  </span>
                </div>
              </div>

              <div className="flex gap-3 pt-2 border-t border-gray-100 flex-wrap">
                {manualSearchResult.patientId && (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedVitalsBooking(manualSearchResult);
                    }}
                    className="inline-flex items-center gap-1.5 bg-brand-navy hover:bg-brand-navy-light text-white text-xs font-bold py-2 px-4 rounded-xl transition-all cursor-pointer"
                  >
                    <Activity className="w-3.5 h-3.5 text-brand-magenta" />
                    <span>View Vitals Chart ({manualSearchResult.patientId})</span>
                  </button>
                )}
                <a
                  href={`tel:+917734931740`}
                  className="inline-flex items-center gap-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold py-2 px-4 rounded-xl transition-all"
                >
                  <Phone className="w-3.5 h-3.5 text-gray-500" />
                  <span>Call Coordinator</span>
                </a>
              </div>
            </div>
          )}

        </div>

        {/* Bookings Card List */}
        <div className="p-6 sm:p-8 space-y-4">
          {filteredUserBookings.length === 0 ? (
            /* Empty State */
            <div className="bg-slate-50/70 border-2 border-dashed border-gray-200 rounded-3xl p-8 sm:p-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-brand-magenta/10 text-brand-magenta flex items-center justify-center mx-auto shadow-inner">
                <CalendarCheck className="w-8 h-8" />
              </div>
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="font-display font-bold text-lg text-brand-navy">
                  {userBookings.length === 0 
                    ? `No active bookings linked to "${currentUser.email}"`
                    : 'No bookings match your current filter selection.'}
                </h3>
                <p className="text-xs sm:text-sm text-gray-500 leading-relaxed font-sans font-light">
                  {userBookings.length === 0 
                    ? 'Whenever you schedule home nursing, patient attendants, or rent medical equipment, your real-time tracking records and clinical updates will appear here automatically.'
                    : 'Try clearing your filters or search by your booking reference ID directly.'}
                </p>
              </div>

              <div className="flex justify-center gap-3 pt-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => onBookNew(undefined, 'service')}
                  className="inline-flex items-center gap-2 bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold py-3 px-6 rounded-xl shadow-md transition-all cursor-pointer active:scale-95"
                >
                  <Stethoscope className="w-4 h-4" />
                  <span>Book Home Care Nurse / Attendant</span>
                </button>
                <button
                  type="button"
                  onClick={() => onBookNew(undefined, 'equipment')}
                  className="inline-flex items-center gap-2 bg-white hover:bg-gray-50 text-brand-navy border border-gray-200 text-xs font-semibold py-3 px-5 rounded-xl transition-all cursor-pointer"
                >
                  <Package className="w-4 h-4 text-brand-magenta" />
                  <span>Rent Medical Equipment</span>
                </button>
              </div>
            </div>
          ) : (
            /* Active Bookings Grid */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredUserBookings.map((booking) => {
                const isConfirmed = booking.status === 'Confirmed';
                const isPending = booking.status === 'Pending';
                const isCompleted = booking.status === 'Completed';

                return (
                  <div
                    key={booking.id}
                    className="bg-white rounded-3xl p-6 border border-gray-150 hover:border-brand-magenta/30 hover:shadow-lg transition-all space-y-5 flex flex-col justify-between"
                  >
                    {/* Top Row: Service Type Badge & Status */}
                    <div className="space-y-3">
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                            booking.type === 'service'
                              ? 'bg-brand-magenta/10 text-brand-magenta border border-brand-magenta/20'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}>
                            {booking.type === 'service' ? (
                              <>
                                <Stethoscope className="w-3.5 h-3.5" /> Care Service
                              </>
                            ) : (
                              <>
                                <Package className="w-3.5 h-3.5" /> Equipment Rental
                              </>
                            )}
                          </span>

                          {booking.patientId && (
                            <span className="bg-brand-navy/5 text-brand-navy border border-brand-navy/10 px-2.5 py-1 rounded-full text-[11px] font-mono font-bold flex items-center gap-1">
                              <Heart className="w-3 h-3 text-brand-magenta fill-brand-magenta" />
                              {booking.patientId}
                            </span>
                          )}
                        </div>

                        {/* Status Chip */}
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                          isConfirmed
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : isPending
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : isCompleted
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : 'bg-red-50 text-red-700 border border-red-200'
                        }`}>
                          {isConfirmed && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />}
                          {isPending && <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />}
                          {booking.status}
                        </span>
                      </div>

                      {/* Item Title & Customer Name */}
                      <div>
                        <h4 className="font-display font-extrabold text-lg text-brand-navy leading-snug">
                          {booking.itemSelected}
                        </h4>
                        <p className="text-xs text-gray-500 mt-0.5">
                          Patient/Care Recipient: <strong className="text-gray-800 font-semibold">{booking.customerName}</strong>
                        </p>
                      </div>

                      {/* Detail Metrics */}
                      <div className="bg-slate-50/80 rounded-2xl p-3.5 border border-slate-150 space-y-2 text-xs">
                        <div className="flex items-center justify-between text-gray-600">
                          <span className="flex items-center gap-1.5 text-gray-500">
                            <Calendar className="w-3.5 h-3.5 text-brand-magenta" /> Scheduled Date:
                          </span>
                          <strong className="text-gray-800 font-semibold">{booking.bookingDate || 'Immediate'}</strong>
                        </div>

                        <div className="flex items-start justify-between text-gray-600 gap-2">
                          <span className="flex items-center gap-1.5 text-gray-500 shrink-0">
                            <MapPin className="w-3.5 h-3.5 text-brand-magenta" /> Location:
                          </span>
                          <span className="text-gray-800 font-medium text-right text-[11px] line-clamp-1">
                            {booking.address}
                          </span>
                        </div>

                        {booking.requirementDetails && (
                          <div className="pt-1.5 border-t border-gray-200/60 text-[11px] text-gray-500 italic">
                            &ldquo;{booking.requirementDetails}&rdquo;
                          </div>
                        )}
                      </div>

                      {/* Booking ID with Copy */}
                      <div className="flex items-center justify-between text-[11px] text-gray-400 bg-gray-50/50 px-3 py-1.5 rounded-xl border border-gray-100">
                        <span className="font-mono">Ref: {booking.id}</span>
                        <button
                          type="button"
                          onClick={() => handleCopy(booking.id)}
                          className="text-gray-500 hover:text-brand-magenta transition-colors flex items-center gap-1 font-semibold cursor-pointer"
                          title="Copy Booking ID"
                        >
                          {copiedId === booking.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-600">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="pt-3 border-t border-gray-100 flex items-center gap-2 flex-wrap">
                      {booking.patientId && (
                        <button
                          type="button"
                          onClick={() => setSelectedVitalsBooking(booking)}
                          className="flex-1 inline-flex items-center justify-center gap-1.5 bg-brand-navy hover:bg-brand-navy-light text-white text-xs font-bold py-2.5 px-3 rounded-xl transition-all cursor-pointer shadow-sm active:scale-95"
                        >
                          <Activity className="w-3.5 h-3.5 text-brand-magenta" />
                          <span>View Clinical Vitals Chart</span>
                        </button>
                      )}

                      <a
                        href={`https://wa.me/917734931740?text=${encodeURIComponent(
                          `Hello Ananya Healthcare, I want an update on my booking ref: ${booking.id} for ${booking.itemSelected} (${booking.customerName}).`
                        )}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center justify-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-semibold py-2.5 px-3.5 rounded-xl transition-all cursor-pointer"
                        title="Chat on WhatsApp"
                      >
                        <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Support</span>
                      </a>

                      <a
                        href="tel:+917734931740"
                        className="inline-flex items-center justify-center p-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors"
                        title="Call Coordinator"
                      >
                        <Phone className="w-3.5 h-3.5" />
                      </a>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

          {/* Quick Family Portal Banner Link */}
          <div className="bg-gradient-to-r from-brand-navy/5 via-brand-magenta/5 to-brand-navy/5 rounded-3xl p-6 border border-brand-magenta/15 flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-brand-magenta text-white flex items-center justify-center shrink-0 shadow-md">
                <Heart className="w-6 h-6 fill-white" />
              </div>
              <div>
                <h4 className="font-display font-bold text-sm text-brand-navy">Looking for Full Clinical History & Daily Charts?</h4>
                <p className="text-xs text-gray-500 mt-0.5">
                  Visit the Family Portal to access complete temperature curves, BP charts, and pulse history logs for all admitted family members.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onOpenFamilyPortal()}
              className="inline-flex items-center gap-2 bg-brand-navy hover:bg-brand-navy-light text-white text-xs font-bold py-3 px-5 rounded-xl shadow-md transition-all shrink-0 cursor-pointer"
            >
              <span>Open Family Portal</span>
              <ArrowRight className="w-4 h-4 text-brand-magenta" />
            </button>
          </div>

        </div>

      </div>

      {/* Patient Vitals Modal */}
      <AnimatePresence>
        {selectedVitalsBooking && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl border border-gray-150 max-h-[90vh] overflow-y-auto relative space-y-6"
            >
              <div className="flex justify-between items-start border-b border-gray-100 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/5 px-2.5 py-0.5 rounded-full border border-brand-magenta/10">
                      Live Clinical Record
                    </span>
                    <span className="text-xs font-mono font-bold text-brand-navy">
                      Patient ID: {selectedVitalsBooking.patientId}
                    </span>
                  </div>
                  <h3 className="text-xl font-display font-extrabold text-brand-navy mt-1">
                    {selectedVitalsBooking.customerName} &bull; {selectedVitalsBooking.itemSelected}
                  </h3>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedVitalsBooking(null)}
                  className="p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Embed the existing PatientVitalsWidget */}
              <PatientVitalsWidget
                patientId={selectedVitalsBooking.patientId || 'PAT1001'}
                patientName={selectedVitalsBooking.customerName}
                allowLogging={false}
              />

              <div className="flex justify-end pt-4 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setSelectedVitalsBooking(null)}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold py-2.5 px-6 rounded-xl transition-all cursor-pointer"
                >
                  Close Chart
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </section>
  );
};
