import React from 'react';
import { Logo } from './Logo';
import { Phone, Mail, MapPin, Clock, ExternalLink, ShieldAlert, MessageCircle } from 'lucide-react';

interface FooterProps {
  setCurrentTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentTab }) => {
  const currentYear = new Date().getFullYear();

  const handleLinkClick = (tabId: string) => {
    setCurrentTab(tabId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-brand-navy text-white pt-16 pb-8 border-t-4 border-brand-magenta">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
        
        {/* Brand Information Column */}
        <div className="flex flex-col gap-4">
          <div className="bg-white/95 p-3 rounded-xl inline-block self-start shadow-md">
            <Logo layout="horizontal" iconSize={42} />
          </div>
          <p className="text-gray-300 text-sm mt-2 leading-relaxed font-sans">
            Ananya Health Care Services provides professional, trained nursing staff, home-care attendants, and clinical-grade medical equipment. Empowering patients with professional dignity and comprehensive clinical support in the safety of their homes.
          </p>
          <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
            <Clock className="w-4 h-4 text-brand-magenta shrink-0" />
            <span>Emergency Coordination: 24 Hours / 365 Days</span>
          </div>
        </div>

        {/* Quick Links Column */}
        <div>
          <h4 className="font-display font-bold text-lg tracking-wide border-l-4 border-brand-magenta pl-3 mb-6">
            Quick Links
          </h4>
          <ul className="space-y-3 text-sm text-gray-300 font-sans">
            {[
              { id: 'home', label: 'Home Page' },
              { id: 'services', label: 'Our Healthcare Services' },
              { id: 'equipment', label: 'Medical Equipment Catalog' },
              { id: 'team', label: 'Our Medical & Support Team' },
              { id: 'careers', label: 'Careers & Recruitment' },
              { id: 'contact', label: 'Contact Us & Map Location' },
              { id: 'admin', label: 'Staff portal' },
            ].map((link) => (
              <li key={link.id}>
                <button
                  onClick={() => handleLinkClick(link.id)}
                  className="hover:text-brand-magenta hover:underline transition-colors cursor-pointer text-left focus:outline-none flex items-center gap-1"
                >
                  <span className="text-brand-magenta font-bold">›</span> {link.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Core Contacts Column */}
        <div>
          <h4 className="font-display font-bold text-lg tracking-wide border-l-4 border-brand-magenta pl-3 mb-6">
            Get In Touch
          </h4>
          <ul className="space-y-4 text-sm text-gray-300 font-sans">
            <li className="flex items-start gap-3">
              <Phone className="w-5 h-5 text-brand-magenta shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-gray-400">Contact Lines</p>
                <div className="flex flex-col gap-0.5 font-semibold text-white">
                  <a href="tel:+917734931740" className="hover:text-brand-magenta transition-colors">
                    +91 7734931740
                  </a>
                  <a href="tel:+918955725234" className="hover:text-brand-magenta transition-colors">
                    +91 8955725234
                  </a>
                </div>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <MessageCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-gray-400">WhatsApp Support</p>
                <a
                  href="https://wa.me/917734931740?text=Hello%20Ananya%20Health%20Care%20Support%2C%20I%20would%20like%20to%20inquire%20about%20your%20services%21"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-emerald-300 text-emerald-400 font-semibold transition-colors duration-200"
                >
                  Chat Live 24/7
                </a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <Mail className="w-5 h-5 text-brand-magenta shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-gray-400">Official Email</p>
                <a
                  href="mailto:ananyahealthcare1@gmail.com"
                  className="hover:text-brand-magenta transition-colors font-medium text-white break-all"
                >
                  ananyahealthcare1@gmail.com
                </a>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-brand-magenta shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-gray-400">Our Office Network</p>
                <div className="mt-1 space-y-2 text-xs leading-relaxed text-gray-300">
                  <p><strong>Jaipur:</strong> Sanganer Goshala, Sheopur Rd, Jaipur - 302029</p>
                  <p><strong>Kota:</strong> near UCO bank, Civil Lines, Kota - 324001</p>
                  <p><strong>Pune:</strong> Nanal Shastri Rd, Kasba Peth, Pune - 411002</p>
                  <p><strong>Jodhpur:</strong> 5th B Rd, Sardarpura, Jodhpur - 342003</p>
                </div>
              </div>
            </li>
          </ul>
        </div>

        {/* Embedded Dynamic Quick Booking Call */}
        <div className="bg-brand-navy-light/40 p-5 rounded-2xl border border-white/10 flex flex-col justify-between">
          <div>
            <h5 className="font-display font-semibold text-white text-base">In Need of Urgent Support?</h5>
            <p className="text-xs text-gray-300 mt-2 leading-relaxed">
              Contact our duty operations manager immediately. We coordinate staff deployments within 2-4 hours of registration.
            </p>
          </div>
          <div className="mt-5 space-y-2">
            <button
              onClick={() => handleLinkClick('booking')}
              className="w-full bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
            >
              Book Service Online <ExternalLink className="w-3 h-3" />
            </button>
            <a
              href="https://wa.me/917734931740?text=Hello%20Ananya%20Health%20Care%20Support%2C%20I%20would%20like%20to%20inquire%20about%20your%20services%21"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-1.5 transition-all text-center block"
            >
              <MessageCircle className="w-3.5 h-3.5" /> Chat on WhatsApp
            </a>
            <a
              href="tel:+917734931740"
              className="w-full bg-white/10 hover:bg-white/20 text-white text-xs font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-1.5 transition-all text-center block"
            >
              <Phone className="w-3 h-3 text-brand-magenta" /> Direct Manager Call
            </a>
          </div>
        </div>

      </div>

      {/* Sub Footer Strip */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-gray-400 font-sans">
        <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4">
          <p>
            © {currentYear} Ananya Health Care Services. All Rights Reserved.
          </p>
          <span className="hidden sm:inline text-gray-600">•</span>
          <p className="font-extralight text-xs tracking-widest text-slate-400">
            powered by <span className="font-light text-slate-200">JD Studio</span>
          </p>
        </div>
        <div className="flex gap-6">
          <button
            onClick={() => handleLinkClick('admin')}
            className="hover:text-brand-magenta transition-colors flex items-center gap-1 cursor-pointer"
          >
            <ShieldAlert className="w-3.5 h-3.5" /> Staff Administration Portal
          </button>
        </div>
      </div>
    </footer>
  );
};
