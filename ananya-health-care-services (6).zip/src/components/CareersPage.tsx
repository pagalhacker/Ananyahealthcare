import React, { useState, useEffect } from 'react';
import { Briefcase, MapPin, Clock, DollarSign, CheckCircle2, FileText, Send, User, Phone, Mail, Award, Check, AlertCircle, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { JobApplication } from '../types';
import { saveToFirestore } from '../lib/firebase';

interface CareersPageProps {
  onApplicationSuccess?: (app: JobApplication) => void;
}

export const CareersPage: React.FC<CareersPageProps> = ({ onApplicationSuccess }) => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [applicationId, setApplicationId] = useState('');
  
  // All stored applications for status lookup
  const [allApplications, setAllApplications] = useState<JobApplication[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<JobApplication[] | null>(null);
  
  // Form fields state
  const [applicantName, setApplicantName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [position, setPosition] = useState('ICU Staff Nurse (GNM / B.Sc. Nursing)');
  const [experienceYears, setExperienceYears] = useState('1-2 Years');
  const [qualifications, setQualifications] = useState('');
  const [coverMessage, setCoverMessage] = useState('');
  
  // Validation errors
  const [errors, setErrors] = useState<Record<string, string>>({});

  const loadAllApplications = () => {
    const stored = localStorage.getItem('ananya_careers');
    if (stored) {
      setAllApplications(JSON.parse(stored));
    }
  };

  useEffect(() => {
    loadAllApplications();
  }, [formSubmitted]);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const jobOpenings = [
    {
      title: 'ICU Staff Nurse (GNM / B.Sc. Nursing)',
      location: 'Jaipur (On-site / Home Care)',
      type: 'Full-Time (12h/24h Shifts)',
      salary: '₹30,000 - ₹45,000 / month',
      experience: '1+ Years in ICU / Critical Care',
      description: 'Perform professional clinical-grade nursing care directly at patient residences, including vital monitoring, IV administration, catheterizations, tracheostomy suctioning, and coordination with treating doctors.',
      requirements: [
        'Valid Nursing Registration Certificate (GNM/B.Sc. Nursing)',
        'Proficiency in handling ICU equipment like oxygen concentrators and patient monitors',
        'Excellent verbal communication and empathetic counseling skills',
        'Punctuality and strict adherence to hospital-level medical logs'
      ]
    },
    {
      title: 'General Patient Care Attendant',
      location: 'Jaipur (Home Deployments)',
      type: 'Full-Time (12h Shifts)',
      salary: '₹18,000 - ₹24,000 / month',
      experience: 'Freshers or Trained Caretakers',
      description: 'Provide dedicated personal care assistance to bedridden, senior, or recovering patients. Assist with bathing, grooming, diapering, safe transfers, mobility exercises, feeding, and timely medicine alarms.',
      requirements: [
        'Certified Nursing Assistant (CNA) or nursing student preferred',
        'Physical strength for transfer assistance (wheelchair/bed)',
        'Patient, respectful, and compassionate demeanor towards elderly',
        'Clean police and reference verification background'
      ]
    },
    {
      title: 'Home Physiotherapist (BPT / MPT)',
      location: 'Jaipur (Part-Time / Per Visit)',
      type: 'Flexible / Per-Session',
      salary: '₹600 - ₹1,000 / session',
      experience: '2+ Years Ortho/Neuro Rehab',
      description: 'Conduct expert physiotherapy and physical rehabilitation sessions in patient homes. Design personalized movement and exercise charts for stroke recovery, post-surgical stiffness, paralysis, and severe joint pain.',
      requirements: [
        'Valid BPT/MPT Degree from a recognized university',
        'Own portable diagnostic equipment (TENS/Ultrasound) is a plus',
        'Strong diagnostic and progress reporting skills',
        'Empathetic and encouraging training attitude'
      ]
    },
    {
      title: 'Medical Equipment Coordinator',
      location: 'Jaipur (Logistics Hub)',
      type: 'Full-Time (Day Shifts)',
      salary: '₹15,000 - ₹20,000 / month',
      experience: 'Driving License + Technical Aptitude',
      description: 'Coordinate the delivery, setup, and calibration of home medical equipment (beds, oxygen concentrators, CPAPs, suction units). Provide operational training to the family, and perform basic device servicing.',
      requirements: [
        'Valid two-wheeler or four-wheeler driving license',
        'Willingness to travel all corners of Jaipur for immediate dispatches',
        'Basic technical aptitude to calibrate digital health monitors and pumps',
        'Polite behavior and professional training instruction'
      ]
    }
  ];

  const handleApplyNow = (jobTitle: string) => {
    setPosition(jobTitle);
    const formElement = document.getElementById('application-form');
    if (formElement) {
      formElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!applicantName.trim()) newErrors.applicantName = 'Full Name is required';
    if (!phoneNumber.trim()) {
      newErrors.phoneNumber = 'Mobile Number is required';
    } else if (!/^\d{10}$/.test(phoneNumber.trim().replace(/[-+ ]/g, ''))) {
      newErrors.phoneNumber = 'Please enter a valid 10-digit mobile number';
    }
    if (!email.trim()) {
      newErrors.email = 'Email Address is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!qualifications.trim()) newErrors.qualifications = 'Please state your nursing degrees or general credentials';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const uniqueId = `APP-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
    
    const newApplication: JobApplication = {
      id: uniqueId,
      applicantName: applicantName.trim(),
      phoneNumber: phoneNumber.trim(),
      email: email.trim(),
      position,
      experienceYears,
      qualifications: qualifications.trim(),
      coverMessage: coverMessage.trim(),
      status: 'Received',
      createdAt: new Date().toISOString()
    };

    // Store in localStorage
    const stored = localStorage.getItem('ananya_careers');
    const currentApps: JobApplication[] = stored ? JSON.parse(stored) : [];
    currentApps.push(newApplication);
    localStorage.setItem('ananya_careers', JSON.stringify(currentApps));

    // Sync with Firebase Firestore
    saveToFirestore('careers', uniqueId, newApplication);

    setApplicationId(uniqueId);
    setFormSubmitted(true);
    
    if (onApplicationSuccess) {
      onApplicationSuccess(newApplication);
    }

    scrollToSection('application-form');
  };

  return (
    <div className="space-y-16 py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 font-sans">
      
      {/* 1. Header Hero section */}
      <div className="relative bg-brand-navy text-white rounded-3xl p-8 md:p-14 overflow-hidden shadow-xl">
        <div className="absolute inset-0 bg-radial-at-t from-brand-navy-light via-brand-navy to-brand-navy" />
        <div className="absolute top-0 right-0 w-80 h-80 bg-brand-magenta/10 rounded-full blur-3xl opacity-50" />
        
        <div className="relative z-10 max-w-3xl space-y-6">
          <span className="inline-flex items-center gap-1.5 bg-brand-magenta/15 text-brand-magenta-light px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest border border-brand-magenta/20">
            <Award className="w-3.5 h-3.5" /> Work With Pride & Dignity
          </span>
          <h1 className="font-display font-black text-3xl md:text-5xl tracking-tight leading-tight">
            Join Jaipur&apos;s Leading <br />
            <span className="text-brand-magenta-light">Home Healthcare Services</span>
          </h1>
          <p className="text-gray-300 text-sm md:text-base leading-relaxed max-w-2xl font-light">
            Are you a certified staff nurse, trained bedside assistant, or physical rehab specialist? Join Ananya Health Care Services to build a secure, highly respected, and professionally rewarding career with flexible shifts, timely pay, and continuous learning.
          </p>
          <div className="flex flex-wrap gap-4 pt-2">
            <button
              onClick={() => scrollToSection('openings')}
              className="bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold py-3 px-6 rounded-xl transition-all text-xs flex items-center gap-1 cursor-pointer"
            >
              View Open Positions <Briefcase className="w-4 h-4" />
            </button>
            <button
              onClick={() => scrollToSection('application-form')}
              className="bg-white/10 hover:bg-white/15 text-white border border-white/20 hover:border-white/40 font-semibold py-3 px-6 rounded-xl transition-all text-xs flex items-center gap-1 cursor-pointer"
            >
              Direct Application Form
            </button>
          </div>
        </div>
      </div>

      {/* 2. Benefits Highlight section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          {
            title: 'Timely & High-Tier Remunerations',
            desc: 'We offer some of the highest daily and monthly wages in the healthcare support segment, credited directly to your bank account with complete transparency.',
            icon: DollarSign,
            color: 'text-green-600 bg-green-50 border-green-100'
          },
          {
            title: 'Safety & Professional Standing',
            desc: 'Our Operations Manager, Mr. Rajesh Gurjar, strictly vets home environments before staff allocation to guarantee absolute safety, dignity, and standard working conditions.',
            icon: CheckCircle2,
            color: 'text-brand-magenta bg-brand-magenta/5 border-brand-magenta/10'
          },
          {
            title: 'Shift Flexibility & Health Insurance',
            desc: 'Choose between 12-hour day shifts, night shifts, or continuous 24-hour residential duties. Long-standing staff gain coverage under emergency health insurance.',
            icon: Clock,
            color: 'text-blue-600 bg-blue-50 border-blue-100'
          }
        ].map((item, idx) => {
          const Icon = item.icon;
          return (
            <div key={idx} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
              <div className="space-y-4">
                <div className={`p-3.5 rounded-2xl border w-fit ${item.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="font-display font-bold text-lg text-brand-navy">{item.title}</h3>
                <p className="text-gray-500 text-xs leading-relaxed">{item.desc}</p>
              </div>
              <div className="pt-4 border-t border-gray-50 mt-4 flex items-center gap-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                <span>Verified Benefit</span>
                <Check className="w-3.5 h-3.5 text-green-500" />
              </div>
            </div>
          );
        })}
      </div>

      {/* 3. Openings Section */}
      <div id="openings" className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/5 border border-brand-magenta/10 px-3.5 py-1.5 rounded-full">
            Immediate Job Openings
          </span>
          <h2 className="font-display font-black text-2xl md:text-3.5xl text-brand-navy">
            Currently Hiring in Jaipur
          </h2>
          <p className="text-gray-500 text-xs md:text-sm leading-relaxed">
            We are actively recruiting passionate, skilled, and honest individuals for the following roles. Applications are reviewed within 48 hours.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {jobOpenings.map((job, idx) => (
            <div key={idx} className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 md:p-8 flex flex-col justify-between hover:border-brand-magenta/10 hover:shadow-md transition-all">
              <div className="space-y-5">
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-gray-100 pb-4">
                  <div>
                    <h3 className="font-display font-bold text-lg md:text-xl text-brand-navy">{job.title}</h3>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500 mt-1.5 font-sans">
                      <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-brand-magenta shrink-0" /> {job.location}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5 text-brand-navy shrink-0" /> {job.type}</span>
                    </div>
                  </div>
                  <span className="text-xs font-bold bg-green-500/10 text-green-700 border border-green-500/20 px-3 py-1 rounded-full shrink-0">
                    Actively Hiring
                  </span>
                </div>

                <div className="space-y-4">
                  {/* Remuneration Info Bar */}
                  <div className="flex justify-between items-center bg-slate-50 p-3.5 rounded-xl text-xs border border-gray-100">
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-4 h-4 text-brand-magenta" />
                      <span className="text-gray-500">Pay Structure:</span>
                    </div>
                    <strong className="text-brand-navy text-sm font-bold">{job.salary}</strong>
                  </div>

                  <p className="text-gray-600 text-xs leading-relaxed font-sans">{job.description}</p>

                  <div className="space-y-2">
                    <p className="text-[11px] font-bold text-brand-navy uppercase tracking-wider">Candidate Requirements:</p>
                    <ul className="text-xs text-gray-600 space-y-1.5 font-sans">
                      {job.requirements.map((req, rid) => (
                        <li key={rid} className="flex items-start gap-1.5">
                          <Check className="w-3.5 h-3.5 text-green-500 mt-0.5 shrink-0" />
                          <span>{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-gray-50 mt-6">
                <button
                  onClick={() => handleApplyNow(job.title)}
                  className="w-full bg-brand-navy hover:bg-brand-navy-light text-white text-xs font-bold py-3 px-6 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 shadow-sm"
                >
                  Apply For This Position <Send className="w-3.5 h-3.5 text-brand-magenta" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Application Form Section */}
      <div id="application-form" className="max-w-3xl mx-auto bg-white rounded-3xl border border-gray-100 shadow-lg p-6 md:p-10 relative">
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-brand-navy via-brand-magenta to-brand-navy rounded-t-3xl" />
        
        <AnimatePresence mode="wait">
          {!formSubmitted ? (
            <motion.div
              key="apply-form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <div className="text-center md:text-left">
                <div className="flex items-center gap-2 justify-center md:justify-start text-xs font-bold text-brand-magenta uppercase tracking-wider">
                  <FileText className="w-4 h-4" /> Application Form
                </div>
                <h3 className="font-display font-bold text-2xl text-brand-navy mt-1">Submit Your Application</h3>
                <p className="text-gray-500 text-xs mt-1.5 leading-relaxed font-sans">
                  Please fill out the details below. Our operations supervisor will match your application and contact you for a basic clinical vetting interview within 2 working days.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Two Column Name & Phone */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-brand-magenta" /> Full Name <span className="text-brand-magenta">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Ramesh Kumar Gurjar"
                      value={applicantName}
                      onChange={(e) => setApplicantName(e.target.value)}
                      className={`w-full bg-gray-50 border ${errors.applicantName ? 'border-red-500' : 'border-gray-200'} px-4 py-3 rounded-xl focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5 focus:outline-none transition-all text-sm`}
                    />
                    {errors.applicantName && <p className="text-red-500 text-[11px] font-semibold flex items-center gap-0.5 mt-1"><AlertCircle className="w-3 h-3" /> {errors.applicantName}</p>}
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1">
                      <Phone className="w-3.5 h-3.5 text-brand-magenta" /> Mobile Number <span className="text-brand-magenta">*</span>
                    </label>
                    <input
                      type="tel"
                      maxLength={10}
                      placeholder="10-digit mobile number"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                      className={`w-full bg-gray-50 border ${errors.phoneNumber ? 'border-red-500' : 'border-gray-200'} px-4 py-3 rounded-xl focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5 focus:outline-none transition-all text-sm`}
                    />
                    {errors.phoneNumber && <p className="text-red-500 text-[11px] font-semibold flex items-center gap-0.5 mt-1"><AlertCircle className="w-3 h-3" /> {errors.phoneNumber}</p>}
                  </div>
                </div>

                {/* Email Address */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-brand-magenta" /> Email Address <span className="text-brand-magenta">*</span>
                  </label>
                  <input
                    type="email"
                    placeholder="name@gmail.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`w-full bg-gray-50 border ${errors.email ? 'border-red-500' : 'border-gray-200'} px-4 py-3 rounded-xl focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5 focus:outline-none transition-all text-sm`}
                  />
                  {errors.email && <p className="text-red-500 text-[11px] font-semibold flex items-center gap-0.5 mt-1"><AlertCircle className="w-3 h-3" /> {errors.email}</p>}
                </div>

                {/* Dropdowns: Position & Experience */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                      Position Applying For
                    </label>
                    <select
                      value={position}
                      onChange={(e) => setPosition(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 px-4 py-3 rounded-xl focus:border-brand-magenta focus:outline-none text-sm font-medium text-brand-navy"
                    >
                      <option value="ICU Staff Nurse (GNM / B.Sc. Nursing)">ICU Staff Nurse (GNM / B.Sc.)</option>
                      <option value="General Patient Care Attendant">General Patient Care Attendant</option>
                      <option value="Home Physiotherapist (BPT / MPT)">Home Physiotherapist (BPT/MPT)</option>
                      <option value="Medical Equipment Coordinator">Medical Equipment Coordinator</option>
                    </select>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                      Total Experience Years
                    </label>
                    <select
                      value={experienceYears}
                      onChange={(e) => setExperienceYears(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 px-4 py-3 rounded-xl focus:border-brand-magenta focus:outline-none text-sm font-medium text-brand-navy"
                    >
                      <option value="Fresher / No Experience">Fresher / No Experience</option>
                      <option value="1-2 Years">1-2 Years</option>
                      <option value="3-5 Years">3-5 Years</option>
                      <option value="5+ Years">5+ Years</option>
                    </select>
                  </div>
                </div>

                {/* Qualifications */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                    Educational Qualifications & Degrees <span className="text-brand-magenta">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. B.Sc. Nursing from RUHS (2023), Registered Nurse No. XXXX"
                    value={qualifications}
                    onChange={(e) => setQualifications(e.target.value)}
                    className={`w-full bg-gray-50 border ${errors.qualifications ? 'border-red-500' : 'border-gray-200'} px-4 py-3 rounded-xl focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5 focus:outline-none transition-all text-sm`}
                  />
                  {errors.qualifications && <p className="text-red-500 text-[11px] font-semibold flex items-center gap-0.5 mt-1"><AlertCircle className="w-3 h-3" /> {errors.qualifications}</p>}
                </div>

                {/* Cover Message */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-brand-navy uppercase tracking-wider">
                    Cover Message or Specific Skills (Optional)
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Tell us about yourself, previous medical wards you worked in, or your preferred areas in Jaipur..."
                    value={coverMessage}
                    onChange={(e) => setCoverMessage(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 px-4 py-3 rounded-xl focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5 focus:outline-none transition-all text-sm font-sans"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold py-4 px-6 rounded-xl transition-all shadow-md shadow-brand-magenta/15 flex items-center justify-center gap-2 cursor-pointer active:scale-95 text-sm"
                >
                  <Send className="w-4 h-4" /> Submit Application to HR
                </button>
              </form>
            </motion.div>
          ) : (
            <motion.div
              key="success-screen"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-8 space-y-6"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full text-green-600">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              
              <div className="space-y-2">
                <h3 className="font-display font-bold text-2.5xl text-brand-navy">Application Received!</h3>
                <p className="text-gray-500 text-sm max-w-md mx-auto leading-relaxed">
                  Thank you for applying, <strong className="text-brand-navy">{applicantName}</strong>. Your profile has been registered in our recruitment pipeline under reference code:
                </p>
                <div className="bg-slate-50 border border-gray-100 rounded-xl px-4 py-2 text-sm font-mono font-bold text-brand-navy w-fit mx-auto mt-2 tracking-wide">
                  {applicationId}
                </div>
              </div>

              <div className="bg-brand-navy text-white text-xs rounded-2xl p-6 max-w-md mx-auto space-y-3.5 text-left font-sans">
                <p className="font-bold border-b border-white/10 pb-2">Next Steps in Our Vetting Process:</p>
                <ul className="space-y-2 text-gray-300 leading-relaxed">
                  <li className="flex gap-2">
                    <span className="text-brand-magenta font-bold">1.</span>
                    <span>Our operations manager, <strong>Mr. Rajesh Gurjar</strong>, will review your nursing/support experience profile.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-brand-magenta font-bold">2.</span>
                    <span>You will receive a call on <strong>+91 {phoneNumber}</strong> within 48 hours for a clinical screening.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-brand-magenta font-bold">3.</span>
                    <span>Approved candidates will be summoned to our Jhalana office for credential verification.</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => {
                  setFormSubmitted(false);
                  setApplicantName('');
                  setPhoneNumber('');
                  setEmail('');
                  setQualifications('');
                  setCoverMessage('');
                }}
                className="bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-bold py-3 px-6 rounded-xl transition-all cursor-pointer"
              >
                Apply for Another Job
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 5. Live Status Tracker */}
      <div className="max-w-3xl mx-auto bg-slate-50 rounded-3xl border border-gray-200/80 p-6 md:p-8 space-y-6">
        <div className="text-center md:text-left space-y-2">
          <div className="flex items-center gap-2 justify-center md:justify-start text-xs font-bold text-brand-navy uppercase tracking-wider">
            <CheckCircle2 className="w-4 h-4 text-brand-magenta" /> Real-Time Application Tracker
          </div>
          <h3 className="font-display font-bold text-xl text-brand-navy">Check Your Application Status</h3>
          <p className="text-xs text-gray-500 leading-relaxed font-sans">
            Have you already submitted an application? Enter your registered **10-Digit Mobile Number** or **Application Code (e.g. APP-XXXXXX-XXX)** to instantly check your verification status in our hiring pipeline.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-3.5 w-4 h-4 text-gray-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Enter Registered Mobile Number or APP-XXXXXX-XXX"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-gray-200 pl-11 pr-4 py-3 rounded-xl focus:border-brand-magenta focus:ring-4 focus:ring-brand-magenta/5 focus:outline-none transition-all text-sm font-semibold text-brand-navy placeholder:text-gray-400 placeholder:font-normal"
            />
          </div>
          <button
            onClick={() => {
              const queryClean = (searchQuery || '').trim().toLowerCase();
              if (!queryClean) {
                setSearchResult([]);
                return;
              }
              const cleanNumeric = queryClean.replace(/\D/g, '');
              const matches = allApplications.filter(
                (app) =>
                  (app.id || '').toLowerCase().includes(queryClean) ||
                  (cleanNumeric && (app.phoneNumber || '').replace(/\D/g, '').includes(cleanNumeric))
              );
              setSearchResult(matches);
            }}
            className="bg-brand-navy hover:bg-brand-navy-light text-white text-xs font-bold py-3 px-6 rounded-xl transition-all cursor-pointer whitespace-nowrap active:scale-95"
          >
            Track Status
          </button>
        </div>

        {/* Search Results Display */}
        {searchResult !== null && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4 border-t border-gray-200 pt-4"
          >
            {searchResult.length === 0 ? (
              <div className="text-center py-4 text-xs text-gray-400 font-sans">
                No matching applications found. Please double-check your input or submit a new application above.
              </div>
            ) : (
              searchResult.map((app) => (
                <div key={app.id} className="bg-white rounded-2xl border border-gray-200/60 p-5 space-y-4 relative overflow-hidden shadow-sm text-left">
                  <div className={`absolute left-0 top-0 bottom-0 w-1.5 ${
                    app.status === 'Shortlisted' ? 'bg-green-500' :
                    app.status === 'Rejected' ? 'bg-red-500' : 'bg-amber-500'
                  }`} />
                  
                  <div className="flex flex-wrap justify-between items-start gap-2 pl-2">
                    <div>
                      <span className="text-[10px] font-mono font-bold bg-slate-100 text-brand-navy px-2 py-0.5 rounded border border-gray-200">
                        {app.id}
                      </span>
                      <h4 className="font-display font-bold text-base text-brand-navy mt-1.5">{app.applicantName}</h4>
                      <p className="text-[11px] text-gray-500 font-sans mt-0.5">Applied: {new Date(app.createdAt).toLocaleDateString()} | Exp: {app.experienceYears}</p>
                    </div>
                    
                    <span className={`text-[10px] font-bold px-3 py-1 rounded-full border shrink-0 ${
                      app.status === 'Shortlisted' ? 'bg-green-50 border-green-200 text-green-700' :
                      app.status === 'Rejected' ? 'bg-red-50 border-red-200 text-red-700' : 'bg-amber-50 border-amber-200 text-amber-700'
                    }`}>
                      • {app.status}
                    </span>
                  </div>

                  <div className="pl-2 space-y-2 font-sans text-xs text-gray-600">
                    <p><strong>Position:</strong> {app.position}</p>
                    <p><strong>Qualifications:</strong> {app.qualifications}</p>
                    
                    {/* Visual Progress Timeline */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-gray-100 space-y-3 mt-3">
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Hiring Pipeline Progress:</p>
                      
                      <div className="flex items-start gap-3">
                        <div className="flex flex-col items-center shrink-0">
                          <div className="w-5 h-5 rounded-full bg-green-500 text-white flex items-center justify-center font-bold text-[9px]">✓</div>
                          <div className="w-0.5 h-6 bg-green-500" />
                        </div>
                        <div className="pb-2">
                          <p className="text-[11px] font-bold text-brand-navy leading-none">Application Received</p>
                          <p className="text-[10px] text-gray-400 mt-1">Successfully registered in Jaipur database.</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3">
                        <div className="flex flex-col items-center shrink-0">
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[9px] ${
                            app.status === 'Shortlisted' || app.status === 'Rejected'
                              ? 'bg-green-500 text-white'
                              : 'bg-amber-500 text-white animate-pulse'
                          }`}>
                            {app.status === 'Shortlisted' || app.status === 'Rejected' ? '✓' : '●'}
                          </div>
                          <div className={`w-0.5 h-6 ${app.status === 'Shortlisted' ? 'bg-green-500' : 'bg-gray-200'}`} />
                        </div>
                        <div className="pb-2">
                          <p className="text-[11px] font-bold text-brand-navy leading-none">Clinical Vetting</p>
                          <p className="text-[10px] text-gray-400 mt-1">
                            {app.status === 'Shortlisted' ? 'Profile pre-approved by Rajesh Gurjar.' :
                             app.status === 'Rejected' ? 'Completed review.' : 'Reviewing certifications & telephone vetting in progress.'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3">
                        <div className="flex flex-col items-center shrink-0">
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[9px] ${
                            app.status === 'Shortlisted' ? 'bg-green-500 text-white' :
                            app.status === 'Rejected' ? 'bg-red-500 text-white' : 'bg-gray-200 text-gray-400'
                          }`}>
                            {app.status === 'Shortlisted' ? '★' : app.status === 'Rejected' ? '✕' : '3'}
                          </div>
                        </div>
                        <div>
                          <p className="text-[11px] font-bold text-brand-navy leading-none">Final Interview Invitation</p>
                          <p className="text-[10px] text-gray-400 mt-1">
                            {app.status === 'Shortlisted' ? 'Expect an SMS/call on registered number for Jhalana Office invite.' :
                             app.status === 'Rejected' ? 'Not selected for further rounds. Thank you.' : 'Pending screening stage.'}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </motion.div>
        )}
      </div>

    </div>
  );
};
