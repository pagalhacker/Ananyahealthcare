import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, Shield, Cross } from 'lucide-react';
import { getLocalBrandSettings, fetchAndSyncBrandSettings, BRAND_UPDATED_EVENT } from '../utils/brandHelper';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);
  const [isExiting, setIsExiting] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [brandSettings, setBrandSettings] = useState(getLocalBrandSettings());

  useEffect(() => {
    fetchAndSyncBrandSettings().then(setBrandSettings);

    const handleUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) setBrandSettings(customEvent.detail);
      else setBrandSettings(getLocalBrandSettings());
    };

    window.addEventListener(BRAND_UPDATED_EVENT, handleUpdate);

    // Progress counter timer
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 2;
      });
    }, 40);

    // Mouse movement 3D tilt tracking
    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const x = (e.clientX / innerWidth - 0.5) * 30; // Max tilt deg
      const y = (e.clientY / innerHeight - 0.5) * -30;
      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Auto trigger completion when progress hits 100% after a short hold
    const exitTimer = setTimeout(() => {
      setIsExiting(true);
      setTimeout(() => {
        onFinish();
      }, 700);
    }, 2800);

    return () => {
      clearInterval(interval);
      clearTimeout(exitTimer);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener(BRAND_UPDATED_EVENT, handleUpdate);
    };
  }, [onFinish]);

  return (
    <AnimatePresence>
      {!isExiting && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.05, filter: 'blur(10px)' }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-0 z-50 flex flex-col justify-between items-center bg-gradient-to-br from-white via-slate-50 to-rose-50/40 text-slate-800 overflow-hidden select-none"
        >
          {/* Animated Ambient 3D Glowing Background Spheres (Light Mode) */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <motion.div
              animate={{
                scale: [1, 1.25, 1],
                opacity: [0.25, 0.45, 0.25],
                x: [0, 40, 0],
                y: [0, -30, 0],
              }}
              transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-brand-magenta/15 blur-3xl pointer-events-none"
            />
            <motion.div
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.2, 0.4, 0.2],
                x: [0, -50, 0],
                y: [0, 40, 0],
              }}
              transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
              className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-blue-500/15 blur-3xl pointer-events-none"
            />
            <motion.div
              animate={{
                rotate: 360,
              }}
              transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full border border-slate-200/60 pointer-events-none"
            />
            <motion.div
              animate={{
                rotate: -360,
              }}
              transition={{ duration: 35, repeat: Infinity, ease: 'linear' }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full border border-dashed border-slate-200/50 pointer-events-none"
            />
          </div>

          {/* Center 3D Dynamic Emblem & Typography Container */}
          <div className="relative z-10 flex flex-col items-center justify-center my-auto px-4 text-center perspective-1000">
            <motion.div
              style={{
                transformStyle: 'preserve-3d',
                rotateX: mousePos.y * 0.5,
                rotateY: mousePos.x * 0.5,
              }}
              transition={{ type: 'spring', stiffness: 100, damping: 20 }}
              className="relative flex flex-col items-center"
            >
              {/* 3D Dynamic Emblem Stack with Admin Logo Image */}
              <div className="relative w-40 h-40 mb-8 flex items-center justify-center">
                {/* Rotating Outer Rings with 3D Depth */}
                <motion.div
                  animate={{ rotate: 360, rotateY: [0, 180, 360] }}
                  transition={{ rotate: { duration: 12, repeat: Infinity, ease: 'linear' }, rotateY: { duration: 6, repeat: Infinity, ease: 'easeInOut' } }}
                  className="absolute inset-0 rounded-3xl border-2 border-brand-magenta/40 shadow-[0_0_30px_rgba(224,30,105,0.2)]"
                  style={{ transform: 'translateZ(20px)' }}
                />
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ duration: 15, repeat: Infinity, ease: 'linear' }}
                  className="absolute inset-2 rounded-2xl border border-slate-300/60"
                  style={{ transform: 'translateZ(30px)' }}
                />

                {/* Central Shield Icon / Custom Brand Logo */}
                <motion.div
                  initial={{ scale: 0, rotate: -45 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.2 }}
                  className="w-28 h-28 rounded-2xl bg-white p-2.5 border border-slate-200/80 shadow-2xl shadow-slate-200/90 flex items-center justify-center relative overflow-hidden group backdrop-blur-md"
                  style={{ transform: 'translateZ(50px)' }}
                >
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-brand-magenta/10 via-transparent to-transparent opacity-60" />
                  
                  {/* Floating Brand Logo Image */}
                  <div className="relative z-10 w-full h-full flex items-center justify-center p-1">
                    {brandSettings.logoUrl ? (
                      <motion.img
                        animate={{ scale: [1, 1.06, 1] }}
                        transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                        src={brandSettings.logoUrl}
                        alt="Brand Logo"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.1)]"
                        onError={(e) => {
                          // Fallback to cross icon
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <motion.div
                        animate={{ scale: [1, 1.15, 1] }}
                        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                      >
                        <Cross className="w-12 h-12 text-brand-navy drop-shadow-sm stroke-[2.5]" />
                      </motion.div>
                    )}
                  </div>
                </motion.div>

                {/* Floating 3D Badges */}
                <motion.div
                  animate={{ y: [-4, 4, -4], rotate: [0, 5, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                  className="absolute -top-3 -right-6 px-3 py-1 rounded-full bg-white/95 border border-slate-200 text-slate-800 text-[10px] font-bold shadow-md backdrop-blur-md flex items-center gap-1"
                  style={{ transform: 'translateZ(70px)' }}
                >
                  <Activity className="w-3 h-3 text-brand-magenta animate-pulse" />
                  <span>24/7 Care</span>
                </motion.div>

                <motion.div
                  animate={{ y: [4, -4, 4], rotate: [0, -5, 0] }}
                  transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
                  className="absolute -bottom-3 -left-6 px-3 py-1 rounded-full bg-white/95 border border-slate-200 text-slate-800 text-[10px] font-bold shadow-md backdrop-blur-md flex items-center gap-1"
                  style={{ transform: 'translateZ(70px)' }}
                >
                  <Shield className="w-3 h-3 text-blue-600" />
                  <span>Verified Staff</span>
                </motion.div>
              </div>

              {/* Title Typography */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="space-y-2"
                style={{ transform: 'translateZ(40px)' }}
              >
                <h1 className="font-display text-3xl sm:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-brand-navy via-slate-900 to-brand-magenta">
                  {brandSettings.brandName}
                </h1>
                <p className="text-brand-magenta font-extrabold text-sm sm:text-base tracking-widest uppercase flex items-center justify-center gap-2">
                  <span className="w-6 h-[1px] bg-brand-magenta/40" />
                  <span>{brandSettings.tagline}</span>
                  <span className="w-6 h-[1px] bg-brand-magenta/40" />
                </p>
              </motion.div>

              {/* Sub-tagline */}
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="mt-4 text-xs sm:text-sm text-slate-600 max-w-sm mx-auto font-normal leading-relaxed"
                style={{ transform: 'translateZ(20px)' }}
              >
                Professional Home Nursing, ICU Setup & Dedicated Critical Care
              </motion.p>
            </motion.div>

            {/* Dynamic ECG Heartbeat Line */}
            <div className="w-64 h-8 my-6 relative overflow-hidden flex items-center justify-center">
              <svg className="w-full h-full stroke-brand-magenta fill-none stroke-2 drop-shadow-sm" viewBox="0 0 200 40">
                <path d="M 0 20 L 40 20 L 50 10 L 60 30 L 70 5 L 80 35 L 90 20 L 200 20" />
              </svg>
              <motion.div
                animate={{ x: [-200, 200] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                className="absolute inset-y-0 w-16 bg-gradient-to-r from-transparent via-brand-magenta/30 to-transparent blur-xs"
              />
            </div>

            {/* Progress Bar */}
            <div className="w-64 space-y-2">
              <div className="w-full bg-slate-200/80 rounded-full h-1.5 overflow-hidden p-0.5 border border-slate-300/40 shadow-inner">
                <motion.div
                  className="h-full bg-gradient-to-r from-brand-magenta via-rose-500 to-brand-navy rounded-full shadow-[0_0_10px_rgba(224,30,105,0.4)]"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 px-1">
                <span>Initializing Care Portal...</span>
                <span>{progress}%</span>
              </div>
            </div>
          </div>

          {/* Bottom Footer - EXACT USER REQUEST: "powered by JD Studio in thin font and small in size" */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="pb-8 text-center z-20"
          >
            <p className="font-extralight text-xs sm:text-sm tracking-widest text-slate-500 uppercase select-none flex items-center justify-center gap-1.5">
              <span>powered by</span>
              <span className="font-light text-brand-navy tracking-wider">JD Studio</span>
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
