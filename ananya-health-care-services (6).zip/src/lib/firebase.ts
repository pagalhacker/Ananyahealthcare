import { saveToSql, deleteFromSql, fetchFromSql } from './sqlClient';

// Flag indicating database connection
export const isSqlDatabaseConnected = true;
export const isFirebaseEnabled = false; // Legacy fallback flag

/**
 * Saves a single document/record to PostgreSQL database backend
 */
export async function saveToFirestore(collectionName: string, docId: string, data: any) {
  try {
    let endpoint = collectionName;
    if (collectionName === 'bookings') endpoint = 'bookings';
    else if (collectionName === 'equipment_catalog' || collectionName === 'equipment') endpoint = 'equipment';
    else if (collectionName === 'vitals') endpoint = 'vitals';
    else if (collectionName === 'attendance_logs' || collectionName === 'attendance') endpoint = 'attendance';
    else if (collectionName === 'brand_settings') endpoint = 'brand-settings';
    else if (collectionName === 'careers' || collectionName === 'job_applications') endpoint = 'job-applications';
    else if (collectionName === 'staff_users' || collectionName === 'staff') endpoint = 'staff';
    else if (collectionName === 'staff_profile_requests' || collectionName === 'staff_requests') endpoint = 'staff-profile-requests';

    await saveToSql(endpoint, { ...data, id: docId });
    console.log(`[PostgreSQL DB] Saved doc ${docId} to ${collectionName}`);
  } catch (error) {
    console.warn(`[PostgreSQL DB] Error saving ${docId} to ${collectionName}:`, error);
  }
}

/**
 * Removes a single document/record from PostgreSQL database backend
 */
export async function removeFromFirestore(collectionName: string, docId: string) {
  try {
    let endpoint = collectionName;
    if (collectionName === 'bookings') endpoint = 'bookings';
    else if (collectionName === 'equipment_catalog' || collectionName === 'equipment') endpoint = 'equipment';
    else if (collectionName === 'vitals') endpoint = 'vitals';
    else if (collectionName === 'attendance_logs' || collectionName === 'attendance') endpoint = 'attendance';
    else if (collectionName === 'brand_settings') endpoint = 'brand-settings';
    else if (collectionName === 'careers' || collectionName === 'job_applications') endpoint = 'job-applications';
    else if (collectionName === 'staff_users' || collectionName === 'staff') endpoint = 'staff';
    else if (collectionName === 'staff_profile_requests' || collectionName === 'staff_requests') endpoint = 'staff-profile-requests';

    await deleteFromSql(endpoint, docId);
    console.log(`[PostgreSQL DB] Deleted doc ${docId} from ${collectionName}`);
  } catch (error) {
    console.warn(`[PostgreSQL DB] Error deleting ${docId} from ${collectionName}:`, error);
  }
}

/**
 * Performs bi-directional synchronization between LocalStorage and PostgreSQL backend.
 */
export async function syncCollection<T extends { id?: string; userId?: string; equipmentKey?: string; bookingKey?: string; vitalKey?: string; attendanceKey?: string; appKey?: string; staffKey?: string; requestKey?: string }>(
  collectionName: string,
  localStorageKey: string,
  defaultSeedData: T[]
): Promise<T[]> {
  const localRaw = localStorage.getItem(localStorageKey);
  let localItems: T[] = [];
  try {
    if (localRaw) {
      const parsed = JSON.parse(localRaw);
      localItems = Array.isArray(parsed) ? parsed : [parsed];
    }
  } catch {
    localItems = [];
  }

  if (localItems.length === 0 && defaultSeedData.length > 0) {
    localItems = [...defaultSeedData];
    localStorage.setItem(localStorageKey, JSON.stringify(localItems));
  }

  try {
    let endpoint = collectionName;
    if (collectionName === 'bookings') endpoint = 'bookings';
    else if (collectionName === 'equipment_catalog' || collectionName === 'equipment') endpoint = 'equipment';
    else if (collectionName === 'vitals') endpoint = 'vitals';
    else if (collectionName === 'attendance_logs' || collectionName === 'attendance') endpoint = 'attendance';
    else if (collectionName === 'brand_settings') endpoint = 'brand-settings';
    else if (collectionName === 'careers' || collectionName === 'job_applications') endpoint = 'job-applications';
    else if (collectionName === 'staff_users' || collectionName === 'staff') endpoint = 'staff';
    else if (collectionName === 'staff_profile_requests' || collectionName === 'staff_requests') endpoint = 'staff-profile-requests';

    const remoteItems = await fetchFromSql<any[]>(endpoint);
    if (remoteItems && Array.isArray(remoteItems) && remoteItems.length > 0) {
      // Map keys to frontend shape
      const mappedRemote: T[] = remoteItems.map((r: any) => {
        return {
          ...r,
          userId: r.user_id || r.userId || r.staff_key || r.staffKey,
          name: r.name,
          role: r.role,
          phoneNumber: r.phone_number || r.phoneNumber,
          email: r.email,
          status: r.status,
          password: r.password,
          createdAt: r.created_at || r.createdAt,
          id: r.bookingKey || r.equipmentKey || r.vitalKey || r.attendanceKey || r.appKey || r.staffKey || r.requestKey || r.id || r.user_id || r.userId,
        };
      });

      localStorage.setItem(localStorageKey, JSON.stringify(mappedRemote));
      console.log(`[PostgreSQL DB] Synchronized '${collectionName}': ${mappedRemote.length} items.`);
      return mappedRemote;
    } else {
      // Seed remote PostgreSQL with local items
      if (localItems.length > 0) {
        for (const item of localItems) {
          await saveToSql(endpoint, item);
        }
      }
    }
  } catch (err) {
    console.warn(`[PostgreSQL DB] Sync failed for '${collectionName}', using local:`, err);
  }

  return localItems;
}

/**
 * Resets PostgreSQL collection with default seed data
 */
export async function resetFirestoreCollection(collectionName: string, seedData: any[]) {
  try {
    let endpoint = collectionName;
    if (collectionName === 'bookings') endpoint = 'bookings';
    else if (collectionName === 'equipment_catalog' || collectionName === 'equipment') endpoint = 'equipment';
    else if (collectionName === 'vitals') endpoint = 'vitals';
    else if (collectionName === 'attendance_logs' || collectionName === 'attendance') endpoint = 'attendance';
    else if (collectionName === 'brand_settings') endpoint = 'brand-settings';
    else if (collectionName === 'careers' || collectionName === 'job_applications') endpoint = 'job-applications';

    for (const item of seedData) {
      await saveToSql(endpoint, item);
    }
    console.log(`[PostgreSQL DB] Collection '${collectionName}' reset successfully with ${seedData.length} records.`);
  } catch (error) {
    console.error(`[PostgreSQL DB] Error resetting collection '${collectionName}':`, error);
  }
}

// Dummy auth stub for graceful degradation
export const auth = null;
export const db = null;
