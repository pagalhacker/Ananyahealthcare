/**
 * API client to communicate with Supabase / Cloud SQL / PostgreSQL Backend
 */
import { getSupabaseClient, isSupabaseConfigured } from './supabase';

export async function fetchFromSql<T>(endpoint: string): Promise<T | null> {
  // If Supabase credentials are configured, query Supabase directly
  const supabase = getSupabaseClient();
  if (isSupabaseConfigured && supabase) {
    try {
      const tableName = getTableName(endpoint);
      const { data, error } = await supabase.from(tableName).select('*').order('created_at', { ascending: false });
      if (!error && data) {
        return data as unknown as T;
      }
      if (error) {
        console.warn(`[Supabase] Error reading from '${tableName}':`, error.message);
      }
    } catch (e) {
      console.warn(`[Supabase] Exception querying '${endpoint}':`, e);
    }
  }

  // Fallback to Express backend
  try {
    const res = await fetch(`/api/${endpoint}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn(`[API] GET /api/${endpoint} failed:`, err);
    return null;
  }
}

export async function saveToSql<T>(endpoint: string, payload: any): Promise<T | null> {
  const supabase = getSupabaseClient();
  if (isSupabaseConfigured && supabase) {
    try {
      const tableName = getTableName(endpoint);
      const rowData = mapPayloadToDbColumns(tableName, payload);
      const { data, error } = await supabase.from(tableName).upsert(rowData).select();
      if (!error && data) {
        return data[0] as unknown as T;
      }
      if (error) {
        console.warn(`[Supabase] Error saving to '${tableName}':`, error.message);
      }
    } catch (e) {
      console.warn(`[Supabase] Exception saving to '${endpoint}':`, e);
    }
  }

  // Fallback to Express backend
  try {
    const res = await fetch(`/api/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn(`[API] POST /api/${endpoint} failed:`, err);
    return null;
  }
}

export async function deleteFromSql(endpoint: string, key: string): Promise<boolean> {
  const supabase = getSupabaseClient();
  if (isSupabaseConfigured && supabase) {
    try {
      const tableName = getTableName(endpoint);
      const keyCol = getKeyColumn(tableName);
      const { error } = await supabase.from(tableName).delete().eq(keyCol, key);
      if (!error) return true;
      if (error) {
        console.warn(`[Supabase] Error deleting from '${tableName}':`, error.message);
      }
    } catch (e) {
      console.warn(`[Supabase] Exception deleting from '${endpoint}':`, e);
    }
  }

  // Fallback to Express backend
  try {
    const res = await fetch(`/api/${endpoint}/${encodeURIComponent(key)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch (err) {
    console.warn(`[API] DELETE /api/${endpoint}/${key} failed:`, err);
    return false;
  }
}

function getTableName(endpoint: string): string {
  if (endpoint.includes('booking')) return 'bookings';
  if (endpoint.includes('equipment')) return 'equipment';
  if (endpoint.includes('vital')) return 'vitals';
  if (endpoint.includes('attendance')) return 'attendance';
  if (endpoint.includes('brand')) return 'brand_settings';
  if (endpoint.includes('job') || endpoint.includes('career')) return 'job_applications';
  if (endpoint.includes('staff_profile_request') || endpoint.includes('staff-request') || endpoint.includes('profile_request')) return 'staff_profile_requests';
  if (endpoint.includes('staff')) return 'staff_users';
  return endpoint;
}

function getKeyColumn(tableName: string): string {
  switch (tableName) {
    case 'bookings': return 'booking_key';
    case 'equipment': return 'equipment_key';
    case 'vitals': return 'vital_key';
    case 'attendance': return 'attendance_key';
    case 'brand_settings': return 'brand_key';
    case 'job_applications': return 'app_key';
    case 'staff_users': return 'staff_key';
    case 'staff_profile_requests': return 'request_key';
    default: return 'id';
  }
}

function mapPayloadToDbColumns(tableName: string, p: any): any {
  if (tableName === 'bookings') {
    return {
      booking_key: p.bookingKey || p.id || `book-${Date.now()}`,
      customer_name: p.customerName || p.name || 'Anonymous',
      phone_number: p.phoneNumber || p.phone || '',
      email: p.email || '',
      type: p.type || 'service',
      item_selected: p.itemSelected || p.service || '',
      booking_date: p.bookingDate || p.date || new Date().toISOString().slice(0, 10),
      address: p.address || '',
      requirement_details: p.requirementDetails || '',
      status: p.status || 'Pending',
      patient_id: p.patientId || null,
      assigned_staff_id: p.assignedStaffId || null,
      assigned_staff_name: p.assignedStaffName || null,
      assigned_staff_role: p.assignedStaffRole || null,
    };
  }
  if (tableName === 'equipment') {
    return {
      equipment_key: p.equipmentKey || p.id || `eq-${Date.now()}`,
      title: p.title || '',
      description: p.description || '',
      category: p.category || 'both',
      rental_price: p.rentalPrice || '',
      purchase_price: p.purchasePrice || '',
      features: p.features || [],
      image: p.image || '',
    };
  }
  if (tableName === 'vitals') {
    return {
      vital_key: p.vitalKey || p.id || `v-${Date.now()}`,
      patient_id: p.patientId || 'PAT1001',
      patient_name: p.patientName || 'Patient',
      temperature: Math.round(p.temperature || 98.6),
      bp_systolic: Math.round(p.bpSystolic || 120),
      bp_diastolic: Math.round(p.bpDiastolic || 80),
      heart_rate: Math.round(p.heartRate || 72),
      logged_date: p.timestamp || p.loggedDate || new Date().toISOString().slice(0, 10),
    };
  }
  if (tableName === 'attendance') {
    return {
      attendance_key: p.attendanceKey || p.id || `att-${Date.now()}`,
      user_id: p.userId || '',
      staff_name: p.staffName || '',
      role: p.role || '',
      check_in_time: p.checkInTime || '',
      check_out_time: p.checkOutTime || null,
      location: p.location || '',
      action_notes: p.actionNotes || '',
      date: p.date || new Date().toISOString().slice(0, 10),
      coordinates: p.coordinates || null,
      check_out_coordinates: p.checkOutCoordinates || null,
    };
  }
  if (tableName === 'brand_settings') {
    return {
      brand_key: 'default_brand',
      brand_name: p.brandName || 'ANANYA',
      logo_url: p.logoUrl || '',
      tagline: p.tagline || 'HEALTH CARE SERVICES',
      updated_at: new Date().toISOString(),
    };
  }
  if (tableName === 'job_applications') {
    return {
      app_key: p.appKey || p.id || `job-${Date.now()}`,
      applicant_name: p.applicantName || '',
      phone_number: p.phoneNumber || '',
      email: p.email || '',
      position: p.position || '',
      experience_years: p.experienceYears || '',
      qualifications: p.qualifications || '',
      cover_message: p.coverMessage || '',
      status: p.status || 'Received',
    };
  }
  if (tableName === 'staff_users') {
    return {
      staff_key: p.staffKey || p.userId || p.id || `ANA${Math.floor(1000 + Math.random() * 9000)}`,
      user_id: p.userId || p.id || '',
      name: p.name || '',
      role: p.role || 'ICU Staff Nurse',
      phone_number: p.phoneNumber || p.phone || '',
      email: p.email || '',
      password: p.password || 'Ananya@123',
      status: p.status || 'Active',
      updated_at: new Date().toISOString(),
    };
  }
  if (tableName === 'staff_profile_requests') {
    return {
      request_key: p.requestKey || p.id || `req-${Date.now()}`,
      staff_id: p.staffId || p.userId || '',
      current_name: p.currentName || '',
      current_role: p.currentRole || '',
      current_phone: p.currentPhone || '',
      current_email: p.currentEmail || '',
      requested_name: p.requestedName || '',
      requested_role: p.requestedRole || '',
      requested_phone: p.requestedPhone || '',
      requested_email: p.requestedEmail || '',
      reason: p.reason || '',
      status: p.status || 'Pending',
      admin_notes: p.adminNotes || '',
      resolved_at: p.resolvedAt || null,
    };
  }
  return p;
}
