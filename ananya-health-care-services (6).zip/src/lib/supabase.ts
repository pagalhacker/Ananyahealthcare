import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Read credentials from client environment variables
const supabaseUrl = (import.meta as any).env?.VITE_SUPABASE_URL || '';
const supabaseAnonKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || '';

let _supabaseClient: SupabaseClient | null = null;

export const isSupabaseConfigured = Boolean(
  supabaseUrl && 
  supabaseAnonKey && 
  supabaseUrl.startsWith('https://') && 
  supabaseAnonKey.length > 10
);

/**
 * Returns the initialized Supabase client if keys are present in environment settings.
 */
export function getSupabaseClient(): SupabaseClient | null {
  if (!isSupabaseConfigured) {
    return null;
  }
  if (!_supabaseClient) {
    try {
      _supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
        },
      });
      console.log('✅ Connected to Supabase Project:', supabaseUrl);
    } catch (err) {
      console.warn('Failed to initialize Supabase client:', err);
    }
  }
  return _supabaseClient;
}

export const supabase = getSupabaseClient();

/**
 * SQL Schema for Supabase SQL Editor:
 * Run this in your Supabase Dashboard -> SQL Editor to initialize all tables.
 */
export const SUPABASE_SQL_INIT_SCRIPT = `
-- 1. Bookings Table
CREATE TABLE IF NOT EXISTS public.bookings (
    id BIGSERIAL PRIMARY KEY,
    booking_key TEXT UNIQUE NOT NULL,
    customer_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    email TEXT,
    type TEXT NOT NULL,
    item_selected TEXT NOT NULL,
    booking_date TEXT NOT NULL,
    address TEXT NOT NULL,
    requirement_details TEXT,
    status TEXT DEFAULT 'Pending',
    patient_id TEXT,
    assigned_staff_id TEXT,
    assigned_staff_name TEXT,
    assigned_staff_role TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Equipment Catalog Table
CREATE TABLE IF NOT EXISTS public.equipment (
    id BIGSERIAL PRIMARY KEY,
    equipment_key TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    rental_price TEXT,
    purchase_price TEXT,
    features JSONB DEFAULT '[]'::jsonb,
    image TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Patient Vitals Table
CREATE TABLE IF NOT EXISTS public.vitals (
    id BIGSERIAL PRIMARY KEY,
    vital_key TEXT UNIQUE NOT NULL,
    patient_id TEXT NOT NULL,
    patient_name TEXT NOT NULL,
    temperature INTEGER NOT NULL,
    bp_systolic INTEGER NOT NULL,
    bp_diastolic INTEGER NOT NULL,
    heart_rate INTEGER NOT NULL,
    logged_date TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Attendance Logs Table
CREATE TABLE IF NOT EXISTS public.attendance (
    id BIGSERIAL PRIMARY KEY,
    attendance_key TEXT UNIQUE NOT NULL,
    user_id TEXT NOT NULL,
    staff_name TEXT NOT NULL,
    role TEXT NOT NULL,
    check_in_time TEXT NOT NULL,
    check_out_time TEXT,
    location TEXT NOT NULL,
    action_notes TEXT,
    date TEXT NOT NULL,
    coordinates JSONB,
    check_out_coordinates JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Brand Settings Table
CREATE TABLE IF NOT EXISTS public.brand_settings (
    id BIGSERIAL PRIMARY KEY,
    brand_key TEXT UNIQUE DEFAULT 'default_brand',
    brand_name TEXT NOT NULL,
    logo_url TEXT,
    tagline TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Job Applications Table
CREATE TABLE IF NOT EXISTS public.job_applications (
    id BIGSERIAL PRIMARY KEY,
    app_key TEXT UNIQUE NOT NULL,
    applicant_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    email TEXT,
    position TEXT NOT NULL,
    experience_years TEXT,
    qualifications TEXT,
    cover_message TEXT,
    status TEXT DEFAULT 'Received',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Staff Users Table (Role, Name, Email, Phone, Access ID, Status)
CREATE TABLE IF NOT EXISTS public.staff_users (
    id BIGSERIAL PRIMARY KEY,
    staff_key TEXT UNIQUE NOT NULL,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    email TEXT NOT NULL,
    password TEXT,
    status TEXT DEFAULT 'Active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Staff Profile Change Requests (Admin Approval Workflow)
CREATE TABLE IF NOT EXISTS public.staff_profile_requests (
    id BIGSERIAL PRIMARY KEY,
    request_key TEXT UNIQUE NOT NULL,
    staff_id TEXT NOT NULL,
    current_name TEXT NOT NULL,
    current_role TEXT NOT NULL,
    current_phone TEXT NOT NULL,
    current_email TEXT NOT NULL,
    requested_name TEXT NOT NULL,
    requested_role TEXT NOT NULL,
    requested_phone TEXT NOT NULL,
    requested_email TEXT NOT NULL,
    reason TEXT,
    status TEXT DEFAULT 'Pending',
    admin_notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);

-- Enable Row Level Security (RLS) & Public access policies for standard operations
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.equipment ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vitals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.brand_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_profile_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access on bookings" ON public.bookings FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update on bookings" ON public.bookings FOR ALL USING (true);

CREATE POLICY "Allow public read access on equipment" ON public.equipment FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update on equipment" ON public.equipment FOR ALL USING (true);

CREATE POLICY "Allow public read access on vitals" ON public.vitals FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update on vitals" ON public.vitals FOR ALL USING (true);

CREATE POLICY "Allow public read access on attendance" ON public.attendance FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update on attendance" ON public.attendance FOR ALL USING (true);

CREATE POLICY "Allow public read access on brand_settings" ON public.brand_settings FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update on brand_settings" ON public.brand_settings FOR ALL USING (true);

CREATE POLICY "Allow public read access on job_applications" ON public.job_applications FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update on job_applications" ON public.job_applications FOR ALL USING (true);

CREATE POLICY "Allow public read access on staff_users" ON public.staff_users FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update on staff_users" ON public.staff_users FOR ALL USING (true);

CREATE POLICY "Allow public read access on staff_profile_requests" ON public.staff_profile_requests FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update on staff_profile_requests" ON public.staff_profile_requests FOR ALL USING (true);
`;
