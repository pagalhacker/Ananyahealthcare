import { Service, Equipment, TeamMember, Testimonial, Office } from './types';

export const SERVICES: Service[] = [
  {
    id: 'home-nursing',
    title: 'Home Nursing Care',
    description: 'Highly professional, clinical-grade nursing care in the comfort of your own home.',
    longDescription: 'Our home nursing service brings certified, hospital-trained registered nurses (GNM/B.Sc. Nursing) directly to your bedside. Ideal for continuous monitoring, medication administration, and complex medical procedures without the hospital stay.',
    iconName: 'Activity',
    features: [
      'Injection administration & IV fluids setup',
      'Wound care & post-surgical dressings',
      'Catheterization & Ryle\'s tube insertion',
      'Vital signs monitoring & medication administration',
      'Tracheostomy and ventilator care management'
    ],
    rates: 'Starting from ₹1,200 / day'
  },
  {
    id: 'patient-attendant',
    title: 'Patient Care Attendants',
    description: 'Compassionate, trained semi-medical staff assisting with daily living activities.',
    longDescription: 'Our bedside attendants provide dedicated non-clinical support. They assist patients who have limited mobility due to illness, surgery, or age, ensuring hygiene, safety, nutrition, and peace of mind.',
    iconName: 'UserCheck',
    features: [
      'Assistance with bathing, dressing, and grooming',
      'Feeding, meal planning, and dietary supervision',
      'Safe transfer assistance (bed to wheelchair)',
      'Prompt reminders for medicines and exercises',
      'Companionship and emotional well-being support'
    ],
    rates: 'Starting from ₹800 / day'
  },
  {
    id: 'post-op-care',
    title: 'Post-Operative Care',
    description: 'Specialized recovery assistance after surgeries to prevent infections and complications.',
    longDescription: 'The transition from hospital to home post-surgery is critical. Our team ensures that wound management, mobilization, pain relief, and doctor-prescribed recovery protocols are meticulously followed for a speedy recovery.',
    iconName: 'HeartPulse',
    features: [
      'Post-surgical pain management support',
      'Physiotherapeutic movement & bedside mobilization',
      'Infection prevention in wound sutures',
      'Regular coordination with your primary surgeon',
      'Dietary management for quick tissue recovery'
    ],
    rates: 'Starting from ₹1,500 / day'
  },
  {
    id: 'elderly-care',
    title: 'Elderly Care Services',
    description: 'Dedicated geriatric care supporting seniors in living an independent and dignified life.',
    longDescription: 'Geriatric care requires patience, empathy, and specialized training. We support senior citizens with chronic illnesses, degenerative diseases like Alzheimer\'s/Dementia, or general frailties of age.',
    iconName: 'Heart',
    features: [
      'Chronic disease management (Diabetes, Hypertension)',
      'Dementia, Parkinson\'s & Alzheimer\'s support',
      'Accident and fall prevention measures',
      'Cognitive engagement activities',
      'Escort to hospital check-ups and pharmacy'
    ],
    rates: 'Starting from ₹900 / day'
  },
  {
    id: 'baby-mother-care',
    title: 'Newborn & Mother Care',
    description: 'Gentle, nurturing care for newborns and support for new mothers during the postpartum phase.',
    longDescription: 'Bringing a new life home is a beautiful experience that requires specialized care. Our trained caregivers assist mothers with postnatal recovery and ensure that the baby receives professional hygiene, massage, and feeding assistance.',
    iconName: 'Baby',
    features: [
      'Newborn massage, bathing, and sanitization',
      'Breastfeeding guidance and support',
      'Mother\'s postnatal diet and physical recovery support',
      'Sleep scheduling and habit tracking for infants',
      'Sterilization of baby bottles and utilities'
    ],
    rates: 'Starting from ₹1,000 / day'
  },
  {
    id: 'physiotherapy',
    title: 'Physiotherapy at Home',
    description: 'Expert physical therapists conducting sessions at home to restore range of motion.',
    longDescription: 'Recover from joint stiffness, muscle pain, paralysis, or neurological conditions under the supervision of highly qualified Bachelors/Masters of Physiotherapy (BPT/MPT). We bring standard clinic utilities home.',
    iconName: 'Activity',
    features: [
      'Orthopedic, neurological, and sports rehabilitation',
      'Post-stroke paralysis recovery stimulation',
      'Custom therapeutic exercise programs',
      'Ultrasound, TENS, and heating therapy',
      'Ergonomic advice and posture correction'
    ],
    rates: 'Starting from ₹600 / session'
  }
];

export const EQUIPMENT_CATALOG: Equipment[] = [
  {
    id: 'wheelchair-premium',
    title: 'Premium Foldable Wheelchair',
    description: 'Lightweight, chrome-plated steel frame wheelchair with heavy-duty puncture-proof wheels.',
    category: 'both',
    rentalPrice: '₹800 / month',
    purchasePrice: '₹6,500',
    features: [
      'Soft-padded armrests and elevated footrests',
      'Folding mechanism for easy car trunk storage',
      'Manual wheel locks for absolute safety',
      'Seat width: 18 inches, carrying capacity up to 120 kg'
    ],
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'oxygen-concentrator',
    title: 'Oxygen Concentrator (5L / 10L)',
    description: 'High-purity oxygen concentrator with integrated nebulizer and real-time purity display.',
    category: 'both',
    rentalPrice: '₹4,500 / month',
    purchasePrice: '₹35,000',
    features: [
      'Delivers medical-grade oxygen (up to 93% ±3% purity)',
      'Low power consumption and noiseless operation (<45 dB)',
      'Equipped with safety alarms for low oxygen purity/pressure',
      'Inbuilt humidifier bottle and dual flow output'
    ],
    image: 'https://images.unsplash.com/photo-1584515901387-a7a1a63376af?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'hospital-bed-cardiac',
    title: '3-Function Manual Cardiac Bed',
    description: 'Professional hospital-grade bed with manual cranks for backrest, knee-rest, and height adjustment.',
    category: 'both',
    rentalPrice: '₹3,000 / month',
    purchasePrice: '₹24,000',
    features: [
      'Collapsible aluminum side rails for patient safety',
      'Removable ABS head and foot boards',
      '3 smooth, heavy-duty silent cranks',
      'Includes IV drip pole and medical-grade anti-decubitus mattress'
    ],
    image: 'https://images.unsplash.com/photo-1586773860418-d3b3ac96317d?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'patient-monitor',
    title: 'Multipara Patient Monitor',
    description: '5-Parameter medical monitor capturing ECG, SpO2, NIBP, Respiration, and Temperature.',
    category: 'both',
    rentalPrice: '₹2,500 / month',
    purchasePrice: '₹18,500',
    features: [
      '12.1-inch high-resolution color TFT screen',
      'Audible and visual alarms for abnormal health metrics',
      'Up to 72 hours of tabular and graphical trends',
      'Adult, pediatric, and neonatal compatibility'
    ],
    image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'air-mattress',
    title: 'Anti-Decubitus Air Mattress & Pump',
    description: 'Alternating pressure bubble pad system to prevent and treat bedsores / pressure sores.',
    category: 'purchase',
    purchasePrice: '₹2,200',
    features: [
      'Adjustable pressure range dial on quiet pump',
      '130 individual bubble cells for optimal pressure distribution',
      'Medical-grade PVC with heavy-duty repair patch',
      'Fits perfectly over any standard hospital or home bed'
    ],
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'bipap-machine',
    title: 'BiPAP / CPAP Therapy Machine',
    description: 'Auto-adjusting sleep apnea and respiratory therapy device with integrated humidifier.',
    category: 'both',
    rentalPrice: '₹5,000 / month',
    purchasePrice: '₹42,000',
    features: [
      'Smart pressure relief technology for comfortable breathing',
      'Detailed sleep data analysis with wireless report export',
      'Ultra-silent operation for undisturbed sleep',
      'Includes premium full-face or nasal mask'
    ],
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'suction-machine',
    title: 'Electric Portable Suction Machine',
    description: 'High-vacuum, high-flow sputum and phlegm extractor ideal for tracheostomy care.',
    category: 'both',
    rentalPrice: '₹1,000 / month',
    purchasePrice: '₹7,500',
    features: [
      'Stepless negative pressure regulator with clear gauge',
      '1000ml autoclavable glass jar with overflow safety valve',
      'Compact, oil-free piston pump requiring zero maintenance',
      'Noise-reducing design (<60 dB)'
    ],
    image: 'https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'digital-ecg',
    title: '3-Channel Portable ECG Machine',
    description: 'Compact electrocardiograph with automated measurement and diagnostic reports.',
    category: 'rent',
    rentalPrice: '₹2,000 / month',
    features: [
      'Real-time high-fidelity 12-lead waveforms display',
      'Inbuilt high-speed thermal paper printing',
      'Anti-baseline drift and AC interference filters',
      'Lightweight with built-in rechargeable battery'
    ],
    image: 'https://images.unsplash.com/photo-1603398938378-e54eab446dde?auto=format&fit=crop&q=80&w=600'
  }
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    id: 'owner',
    name: 'Mr. Jeetram Diya',
    role: 'Founder & CEO',
    image: 'https://images.unsplash.com/photo-1504257401700-1a6158a69675?auto=format&fit=crop&q=80&w=400',
    bio: 'Mr. Jeetram Diya is the visionary Founder & CEO of Ananya Health Care. He guides our long-term strategic direction, medical compliance, and cooperative medical institution frameworks, scaling clinical-grade home recovery operations to serve thousands of families.',
    phone: '8955725234',
    email: 'director.ananyahealthcare@gmail.com'
  },
  {
    id: 'director',
    name: 'Mrs. Ananya Sharma',
    role: 'Co-Founder & Director',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400',
    bio: 'With over 15 years of experience in healthcare management, Mrs. Ananya co-founded this agency to bridge the critical gap between hospital care and home recovery, fostering dignity and professional standards at home.',
    phone: '7734931740',
    email: 'ananyahealthcare1@gmail.com'
  },
  {
    id: 'manager',
    name: 'Mr. Rajesh Gurjar',
    role: 'Operations & Staffing Manager',
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=400',
    bio: 'Rajesh Gurjar oversees our entire operational roster of 120+ registered nurses, attendants, and physical therapists. He handles direct patient allocations, shift schedules, and immediate client relations.',
    phone: '7734931740',
    email: 'operations.ananya@gmail.com'
  },
  {
    id: 'social-media',
    name: 'Ms. Priya Sen',
    role: 'Social Media & Public Relations Lead',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400',
    bio: 'Priya handles community outreach, patient testimonials, educational webinars, and brand communication. She ensures the public and patients find quick, helpful answers and healthcare tips across our digital platforms.',
    phone: '8955725234',
    email: 'ananyahealthcare1@gmail.com'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Rajendra Prasad Yadav',
    role: 'Son of Post-Op Cardiac Patient',
    content: 'Ananya Health Care provided a registered male nurse for my father post-coronary bypass. The level of care, timing punctuality, and medical precision in dressing the wounds was phenomenal. Saved us multiple hospital visits.',
    rating: 5,
    date: 'June 20, 2026'
  },
  {
    id: 'test-2',
    name: 'Meenakshi Iyer',
    role: 'Daughter of Geriatric Patient',
    content: 'We rented a hospital bed and bought an alternating pressure mattress. The equipment delivery was on the same day, extremely clean, and the staff even set it up and gave us full instructions on operating it. Truly exceptional!',
    rating: 5,
    date: 'May 14, 2026'
  },
  {
    id: 'test-3',
    name: 'Gaurav Rathore',
    role: 'Husband of Maternity Client',
    content: 'Highly professional baby care service. The nanny was incredibly sweet, hygienic, and highly trained in baby massage. Our family is extremely grateful to Mrs. Ananya for coordinating this on short notice.',
    rating: 5,
    date: 'July 02, 2026'
  }
];

export const FAQS = [
  {
    q: 'How does your hiring and staffing process work?',
    a: 'Every staff member at Ananya Health Care Services undergoes rigorous criminal background checks, medical knowledge tests, and hands-on clinical assessments before enrollment. We verify their certificates (GNM, B.Sc Nursing, or Attendant credentials) thoroughly.'
  },
  {
    q: 'Can we request a replacement if we are not satisfied with an attendant?',
    a: 'Absolutely. We strive for a 100% comfort match. If for any reason the patient or family is uncomfortable with an allocated care staff, contact our manager, Mr. Rajesh Gurjar, and we will arrange a suitable replacement within 24 hours.'
  },
  {
    q: 'What are the charges for equipment rentals?',
    a: 'Equipment rental rates vary by item. For example, manual hospital beds start at ₹3,000/month and oxygen concentrators at ₹4,500/month. We charge a minimal security deposit which is fully refundable upon return of the functional device.'
  },
  {
    q: 'Are your services active 24/7?',
    a: 'Yes, we provide both 12-hour shifts (day or night) and full 24-hour residential stays, where staff live with the patient to provide around-the-clock clinical and personal supervision.'
  }
];

export const OFFICES: Office[] = [
  {
    id: 'jaipur',
    city: 'Jaipur',
    branchName: 'Jaipur Office (Sanganer)',
    address: 'Sanganer Goshala, Sheopur Rd, Sanganer, Pratap Nagar, Jaipur, Rajasthan 302029',
    mapQuery: 'Sanganer Goshala, Sheopur Rd, Sanganer, Pratap Nagar, Jaipur, Rajasthan 302029',
    embedUrl: 'https://maps.google.com/maps?q=Sanganer%20Goshala%2C%20Sheopur%20Rd%2C%20Sanganer%2C%20Pratap%20Nagar%2C%20Jaipur%2C%20Rajasthan%20302029&t=&z=14&ie=UTF8&iwloc=&output=embed',
    phone: '7734931740',
    email: 'ananyahealthcare1@gmail.com'
  },
  {
    id: 'kota',
    city: 'Kota',
    branchName: 'Kota Office (Civil Lines)',
    address: 'near UCO bank, Civil Lines, Nayapura, Kota, Rajasthan 324001',
    mapQuery: 'near UCO bank, Civil Lines, Nayapura, Kota, Rajasthan 324001',
    embedUrl: 'https://maps.google.com/maps?q=near%20UCO%20bank%2C%20Civil%20Lines%2C%20Nayapura%2C%20Kota%2C%20Rajasthan%20324001&t=&z=14&ie=UTF8&iwloc=&output=embed',
    phone: '8955725234',
    email: 'director.ananyahealthcare@gmail.com'
  },
  {
    id: 'pune',
    city: 'Pune',
    branchName: 'Pune Office (Kasba Peth)',
    address: 'Nanal Shastri Rd, Kasba Peth, Pune, Maharashtra 411002',
    mapQuery: 'Nanal Shastri Rd, Kasba Peth, Pune, Maharashtra 411002',
    embedUrl: 'https://maps.google.com/maps?q=Nanal%20Shastri%20Rd%2C%20Kasba%20Peth%2C%20Pune%2C%20Maharashtra%20411002&t=&z=14&ie=UTF8&iwloc=&output=embed',
    phone: '7734931740',
    email: 'operations.ananya@gmail.com'
  },
  {
    id: 'jodhpur',
    city: 'Jodhpur',
    branchName: 'Jodhpur Office (Sardarpura)',
    address: '5th B Rd, Sardarpura, Jodhpur, Rajasthan 342003',
    mapQuery: '5th B Rd, Sardarpura, Jodhpur, Rajasthan 342003',
    embedUrl: 'https://maps.google.com/maps?q=5th%20B%20Rd%2C%20Sardarpura%2C%20Jodhpur%2C%20Rajasthan%20342003&t=&z=14&ie=UTF8&iwloc=&output=embed',
    phone: '8955725234',
    email: 'ananyahealthcare1@gmail.com'
  }
];

