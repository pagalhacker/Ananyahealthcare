import { BrandSettings } from '../types';
import { saveToSql, fetchFromSql } from '../lib/sqlClient';

export const DEFAULT_BRAND_SETTINGS: BrandSettings = {
  id: 'main_brand',
  logoUrl: 'https://cdn.phototourl.com/free/2026-07-14-44a66428-3fc7-42cc-98ce-a35b8e19dccb.png',
  brandName: 'ANANYA',
  tagline: 'HEALTH CARE SERVICES',
  updatedAt: new Date().toISOString()
};

export const BRAND_SETTINGS_KEY = 'ananya_brand_settings';
export const BRAND_UPDATED_EVENT = 'ananya_brand_settings_updated';

export function getLocalBrandSettings(): BrandSettings {
  try {
    const cached = localStorage.getItem(BRAND_SETTINGS_KEY);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed && typeof parsed === 'object') {
        return {
          ...DEFAULT_BRAND_SETTINGS,
          ...parsed,
          logoUrl: parsed.logoUrl || DEFAULT_BRAND_SETTINGS.logoUrl,
          brandName: parsed.brandName || DEFAULT_BRAND_SETTINGS.brandName,
          tagline: parsed.tagline || DEFAULT_BRAND_SETTINGS.tagline,
        };
      }
    }
  } catch (e) {
    console.warn('Failed to parse cached brand settings:', e);
  }
  return DEFAULT_BRAND_SETTINGS;
}

export async function saveBrandSettings(settings: BrandSettings): Promise<BrandSettings> {
  const finalSettings: BrandSettings = {
    ...settings,
    id: 'main_brand',
    updatedAt: new Date().toISOString()
  };
  
  // Save to LocalStorage
  localStorage.setItem(BRAND_SETTINGS_KEY, JSON.stringify(finalSettings));
  
  // Save to PostgreSQL backend
  try {
    await saveToSql('brand-settings', {
      brandName: finalSettings.brandName,
      logoUrl: finalSettings.logoUrl,
      tagline: finalSettings.tagline,
    });
  } catch (err) {
    console.error('Failed to save brand settings to PostgreSQL:', err);
  }
  
  // Broadcast event across all mounted React components
  window.dispatchEvent(new CustomEvent(BRAND_UPDATED_EVENT, { detail: finalSettings }));
  return finalSettings;
}

export async function fetchAndSyncBrandSettings(): Promise<BrandSettings> {
  const local = getLocalBrandSettings();
  try {
    const remote = await fetchFromSql<any>('brand-settings');
    if (remote && remote.brandName) {
      const merged: BrandSettings = {
        ...DEFAULT_BRAND_SETTINGS,
        logoUrl: remote.logoUrl || local.logoUrl || DEFAULT_BRAND_SETTINGS.logoUrl,
        brandName: remote.brandName || local.brandName || DEFAULT_BRAND_SETTINGS.brandName,
        tagline: remote.tagline || local.tagline || DEFAULT_BRAND_SETTINGS.tagline,
        updatedAt: remote.updatedAt || new Date().toISOString(),
      };
      localStorage.setItem(BRAND_SETTINGS_KEY, JSON.stringify(merged));
      window.dispatchEvent(new CustomEvent(BRAND_UPDATED_EVENT, { detail: merged }));
      return merged;
    }
  } catch (e) {
    console.warn('Failed syncing brand settings from PostgreSQL:', e);
  }
  return local;
}
