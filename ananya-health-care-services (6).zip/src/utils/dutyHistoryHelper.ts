import { Booking, AttendanceLog } from '../types';
import { BOOKINGS_STORAGE_KEY, ensurePatientIdsOnBookings } from './vitalsHelper';

export interface DailyShiftLog {
  id: string;
  date: string;
  checkInTime: string;
  checkOutTime: string | null;
  shiftHours: number;
  location: string;
  actionNotes: string;
  gpsVerified: boolean;
  coordinates?: { lat: number; lng: number };
  vitalsRecorded?: boolean;
}

export interface PatientDutyRecord {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone?: string;
  patientAge?: number;
  patientGender?: 'Male' | 'Female' | 'Other';
  serviceTitle: string;
  serviceType: 'service' | 'equipment';
  locationAddress: string;
  locality: string;
  city: string;
  startDate: string;
  endDate: string;
  totalDays: number;
  totalShifts: number;
  totalHours: number;
  status: 'Completed' | 'Ongoing' | 'Scheduled';
  assignedStaffId: string;
  assignedStaffName: string;
  assignedStaffRole: string;
  clinicalRequirement: string;
  dutyHighlights: string[];
  dailyLogs: DailyShiftLog[];
}

export const DUTY_HISTORY_STORAGE_KEY = 'ananya_staff_duty_history';
export const DUTY_HISTORY_UPDATED_EVENT = 'ananya_duty_history_updated';

// Pre-seeded rich clinical duty histories for staff
const SEED_DUTY_HISTORY: PatientDutyRecord[] = [
  // 1. Ramesh Kumar Chaudhary (ANA1001) - ICU Staff Nurse
  {
    id: 'DUTY-1001-AARAV',
    patientId: 'PAT1001',
    patientName: 'Aarav Singhal',
    patientPhone: '+91 98290 12345',
    patientAge: 62,
    patientGender: 'Male',
    serviceTitle: '24/7 ICU Post-Op Home Nursing Care',
    serviceType: 'service',
    locationAddress: 'Plot No. 12, Sector 4, Malviya Nagar, Jaipur, RJ',
    locality: 'Malviya Nagar',
    city: 'Jaipur',
    startDate: '2026-07-01',
    endDate: '2026-07-14',
    totalDays: 14,
    totalShifts: 14,
    totalHours: 112,
    status: 'Completed',
    assignedStaffId: 'ANA1001',
    assignedStaffName: 'Ramesh Kumar Chaudhary',
    assignedStaffRole: 'ICU Staff Nurse (GNM / B.Sc.)',
    clinicalRequirement: 'Post-CABG (cardiac bypass surgery) critical care, surgical wound asepsis, insulin titration, and catheter flushing.',
    dutyHighlights: [
      'Managed sterile sternal wound dressing with Betadine/dry gauze daily.',
      'Administered sliding scale insulin twice daily with blood glucose checks.',
      'Logged cardiac telemetry, BP (avg 120/80 mmHg), and SpO2 (>98%).',
      'Assisted patient from strict bed-rest to independent ambulation in room.'
    ],
    dailyLogs: [
      {
        id: 'LOG-1001-1',
        date: '2026-07-14',
        checkInTime: '2026-07-14T08:00:00.000Z',
        checkOutTime: '2026-07-14T16:00:00.000Z',
        shiftHours: 8,
        location: 'Plot No. 12, Sector 4, Malviya Nagar, Jaipur',
        actionNotes: 'Final shift handover. Sternal wound healed cleanly with zero signs of infection. Fasting sugar 112 mg/dL. Handed vitals chart to family.',
        gpsVerified: true,
        coordinates: { lat: 26.8549, lng: 75.8219 },
        vitalsRecorded: true
      },
      {
        id: 'LOG-1001-2',
        date: '2026-07-13',
        checkInTime: '2026-07-13T08:00:00.000Z',
        checkOutTime: '2026-07-13T16:00:00.000Z',
        shiftHours: 8,
        location: 'Plot No. 12, Sector 4, Malviya Nagar, Jaipur',
        actionNotes: 'Monitored morning vitals (BP 120/80, Pulse 72 bpm). Patient walked 100 meters inside house without shortness of breath.',
        gpsVerified: true,
        coordinates: { lat: 26.8549, lng: 75.8219 },
        vitalsRecorded: true
      },
      {
        id: 'LOG-1001-3',
        date: '2026-07-12',
        checkInTime: '2026-07-12T08:00:00.000Z',
        checkOutTime: '2026-07-12T16:00:00.000Z',
        shiftHours: 8,
        location: 'Plot No. 12, Sector 4, Malviya Nagar, Jaipur',
        actionNotes: 'Arrived on-time. Administered insulin, monitored vitals, cleaned and redressed post-op wound. Patient resting comfortably.',
        gpsVerified: true,
        coordinates: { lat: 26.8549, lng: 75.8219 },
        vitalsRecorded: true
      },
      {
        id: 'LOG-1001-4',
        date: '2026-07-11',
        checkInTime: '2026-07-11T08:00:00.000Z',
        checkOutTime: '2026-07-11T16:00:00.000Z',
        shiftHours: 8,
        location: 'Plot No. 12, Sector 4, Malviya Nagar, Jaipur',
        actionNotes: 'Catheter maintenance and flushing done. Vitals stable: BP 120/78, Temp 98.9 F.',
        gpsVerified: true,
        coordinates: { lat: 26.8549, lng: 75.8219 },
        vitalsRecorded: true
      },
      {
        id: 'LOG-1001-5',
        date: '2026-07-10',
        checkInTime: '2026-07-10T08:00:00.000Z',
        checkOutTime: '2026-07-10T16:00:00.000Z',
        shiftHours: 8,
        location: 'Plot No. 12, Sector 4, Malviya Nagar, Jaipur',
        actionNotes: 'Routine ICU shift. Administered morning meds and nebulization.',
        gpsVerified: true,
        coordinates: { lat: 26.8549, lng: 75.8219 },
        vitalsRecorded: true
      }
    ]
  },
  {
    id: 'DUTY-1001-SUNITA',
    patientId: 'PAT1005',
    patientName: 'Sunita Agarwal',
    patientPhone: '+91 94140 88776',
    patientAge: 58,
    patientGender: 'Female',
    serviceTitle: 'Tracheostomy & Respiratory ICU Nursing',
    serviceType: 'service',
    locationAddress: 'B-18, Vaishali Nagar, near Amrapali Circle, Jaipur, RJ',
    locality: 'Vaishali Nagar',
    city: 'Jaipur',
    startDate: '2026-06-15',
    endDate: '2026-06-25',
    totalDays: 11,
    totalShifts: 11,
    totalHours: 88,
    status: 'Completed',
    assignedStaffId: 'ANA1001',
    assignedStaffName: 'Ramesh Kumar Chaudhary',
    assignedStaffRole: 'ICU Staff Nurse (GNM / B.Sc.)',
    clinicalRequirement: 'Tracheostomy tube care, sterile deep suctioning, BiPAP synchronization, and chest physiotherapy.',
    dutyHighlights: [
      'Maintained tracheostomy cannula hygiene with zero bronchial aspiration.',
      'Suctioned secretions 4-6 times per shift using electric portable suction device.',
      'Coordinated with treating pulmonologist on BiPAP settings (IPAP 14 / EPAP 6).',
      'Assisted patient family with emergency decannulation protocol guidance.'
    ],
    dailyLogs: [
      {
        id: 'LOG-1001-SUN-1',
        date: '2026-06-25',
        checkInTime: '2026-06-25T08:00:00.000Z',
        checkOutTime: '2026-06-25T16:00:00.000Z',
        shiftHours: 8,
        location: 'B-18, Vaishali Nagar, Jaipur',
        actionNotes: 'Final duty day. Tracheostomy stoma intact, zero secretion block. Handed suction catheter stock to family.',
        gpsVerified: true,
        coordinates: { lat: 26.9030, lng: 75.7423 }
      },
      {
        id: 'LOG-1001-SUN-2',
        date: '2026-06-24',
        checkInTime: '2026-06-24T08:00:00.000Z',
        checkOutTime: '2026-06-24T16:00:00.000Z',
        shiftHours: 8,
        location: 'B-18, Vaishali Nagar, Jaipur',
        actionNotes: 'Cannula dressing changed. Nebulized with Levolin and Budecort as prescribed.',
        gpsVerified: true,
        coordinates: { lat: 26.9030, lng: 75.7423 }
      }
    ]
  },
  {
    id: 'DUTY-1001-RAJESH',
    patientId: 'PAT1006',
    patientName: 'Rajesh Gupta',
    patientPhone: '+91 98280 44556',
    patientAge: 71,
    patientGender: 'Male',
    serviceTitle: 'Post-Stroke ICU Nursing & Enteral Tube Care',
    serviceType: 'service',
    locationAddress: '78, Jagatpura Scheme, near Mahal Road, Jaipur, RJ',
    locality: 'Jagatpura',
    city: 'Jaipur',
    startDate: '2026-05-18',
    endDate: '2026-06-05',
    totalDays: 19,
    totalShifts: 19,
    totalHours: 152,
    status: 'Completed',
    assignedStaffId: 'ANA1001',
    assignedStaffName: 'Ramesh Kumar Chaudhary',
    assignedStaffRole: 'ICU Staff Nurse (GNM / B.Sc.)',
    clinicalRequirement: 'Acute ischemic stroke recovery, Ryle’s tube feeding, Foley catheter care, and DVT prophylaxis.',
    dutyHighlights: [
      'Administered 200ml high-protein blenderized enteral feeds every 3 hours without regurgitation.',
      'Repositioned patient every 2 hours on alternating air mattress to avoid pressure ulcers.',
      'Logged neurological GCS score daily (improved from 10 to 14 over 19 days).',
      'Assisted with limb passive movements to prevent contractures.'
    ],
    dailyLogs: [
      {
        id: 'LOG-1001-RAJ-1',
        date: '2026-06-05',
        checkInTime: '2026-06-05T08:00:00.000Z',
        checkOutTime: '2026-06-05T16:00:00.000Z',
        shiftHours: 8,
        location: '78, Jagatpura Scheme, Jaipur',
        actionNotes: 'Patient successfully transitioned to oral soft diet swallow test. Catheter removed under physician supervision.',
        gpsVerified: true,
        coordinates: { lat: 26.8242, lng: 75.8647 }
      }
    ]
  },

  // 2. Dr. Priya Sharma (ANA1002) - Home Physiotherapist
  {
    id: 'DUTY-1002-VINAY',
    patientId: 'PAT1003',
    patientName: 'Vinay Rathore',
    patientPhone: '+91 70144 98765',
    patientAge: 54,
    patientGender: 'Male',
    serviceTitle: 'Post-Stroke Neuro-Rehab & Gait Rehabilitation',
    serviceType: 'service',
    locationAddress: '245, Mansarovar Scheme, Jaipur, RJ - 302020',
    locality: 'Mansarovar',
    city: 'Jaipur',
    startDate: '2026-07-01',
    endDate: '2026-07-13',
    totalDays: 13,
    totalShifts: 13,
    totalHours: 20,
    status: 'Completed',
    assignedStaffId: 'ANA1002',
    assignedStaffName: 'Dr. Priya Sharma',
    assignedStaffRole: 'Home Physiotherapist (BPT / MPT)',
    clinicalRequirement: 'Left hemiparesis gait recovery, shoulder subluxation prevention, and static/dynamic balance training.',
    dutyHighlights: [
      'Gait retraining achieved with quad-rip cane support over 150m walking distances.',
      'Active-assisted range of motion for left upper limb (shoulder flexion reached 120°).',
      'Dynamic balance board exercises with zero fall incidents.',
      'Prescribed home exercise routine for family to supervise between sessions.'
    ],
    dailyLogs: [
      {
        id: 'LOG-1002-1',
        date: '2026-07-12',
        checkInTime: '2026-07-12T10:30:00.000Z',
        checkOutTime: '2026-07-12T11:45:00.000Z',
        shiftHours: 1.25,
        location: '245, Mansarovar Scheme, Jaipur',
        actionNotes: 'Post-stroke gait training session. Walked 150 meters with quad-rip cane support. Performed active-assist stretching.',
        gpsVerified: true,
        coordinates: { lat: 26.8529, lng: 75.7570 }
      },
      {
        id: 'LOG-1002-2',
        date: '2026-07-11',
        checkInTime: '2026-07-11T10:30:00.000Z',
        checkOutTime: '2026-07-11T11:45:00.000Z',
        shiftHours: 1.25,
        location: '245, Mansarovar Scheme, Jaipur',
        actionNotes: 'Left upper limb neuro-muscular stimulation and weight-bearing exercises.',
        gpsVerified: true,
        coordinates: { lat: 26.8529, lng: 75.7570 }
      }
    ]
  },
  {
    id: 'DUTY-1002-KAILASH',
    patientId: 'PAT1007',
    patientName: 'Kailash Chand Verma',
    patientPhone: '+91 94145 22334',
    patientAge: 68,
    patientGender: 'Male',
    serviceTitle: 'Total Knee Replacement (TKR) Home Physiotherapy',
    serviceType: 'service',
    locationAddress: 'Near UCO Bank, Civil Lines, Kota, RJ - 324001',
    locality: 'Civil Lines',
    city: 'Kota',
    startDate: '2026-06-10',
    endDate: '2026-06-24',
    totalDays: 15,
    totalShifts: 15,
    totalHours: 23,
    status: 'Completed',
    assignedStaffId: 'ANA1002',
    assignedStaffName: 'Dr. Priya Sharma',
    assignedStaffRole: 'Home Physiotherapist (BPT / MPT)',
    clinicalRequirement: 'Bilateral TKR post-operative rehabilitation, CPM machine mobilization, and quadriceps lag correction.',
    dutyHighlights: [
      'Restored active knee flexion from 45° to 115° on right knee and 110° on left knee.',
      'Eliminated quadriceps extensor lag with straight-leg raise drills.',
      'Stair climbing re-education achieved safely with single handrail support.'
    ],
    dailyLogs: [
      {
        id: 'LOG-1002-KOT-1',
        date: '2026-06-24',
        checkInTime: '2026-06-24T11:00:00.000Z',
        checkOutTime: '2026-06-24T12:30:00.000Z',
        shiftHours: 1.5,
        location: 'Civil Lines, Kota Branch Area',
        actionNotes: 'Final rehabilitation session. Patient walked 500m independently with normal reciprocal gait. Full recovery achieved.',
        gpsVerified: true,
        coordinates: { lat: 25.1825, lng: 75.8422 }
      }
    ]
  },

  // 3. Devendra Singh Shekhawat (ANA1003) - General Patient Care Attendant
  {
    id: 'DUTY-1003-RUKMANI',
    patientId: 'PAT1002',
    patientName: 'Rukmani Devi',
    patientPhone: '+91 80055 12345',
    patientAge: 79,
    patientGender: 'Female',
    serviceTitle: '24-Hour Elderly Dementia & Attendant Support',
    serviceType: 'service',
    locationAddress: 'H.No. 45-B, Vaishali Nagar, near Hanuman Temple, Jaipur, RJ',
    locality: 'Vaishali Nagar',
    city: 'Jaipur',
    startDate: '2026-06-15',
    endDate: '2026-07-06',
    totalDays: 22,
    totalShifts: 22,
    totalHours: 264,
    status: 'Completed',
    assignedStaffId: 'ANA1003',
    assignedStaffName: 'Devendra Singh Shekhawat',
    assignedStaffRole: 'General Patient Care Attendant',
    clinicalRequirement: 'Advanced Alzheimer care, wander prevention, bathing & hygiene assistance, and gentle wheelchair transfers.',
    dutyHighlights: [
      'Provided continuous 24/7 patient vigilance preventing falls or disorientation.',
      'Daily morning sponge bath, hair combing, skin moisturization, and diaper changes.',
      'Assisted with wheelchair walks in garden for mental calmness and sunshine exposure.',
      'Prompt medicine reminders and nutritious soft meal feeding.'
    ],
    dailyLogs: [
      {
        id: 'LOG-1003-1',
        date: '2026-07-06',
        checkInTime: '2026-07-06T08:00:00.000Z',
        checkOutTime: '2026-07-06T20:00:00.000Z',
        shiftHours: 12,
        location: 'H.No. 45-B, Vaishali Nagar, Jaipur',
        actionNotes: 'Completed 22-day dedicated attendant deployment. Patient in cheerful spirits with healthy skin and zero bed sores.',
        gpsVerified: true,
        coordinates: { lat: 26.9030, lng: 75.7423 }
      }
    ]
  },
  {
    id: 'DUTY-1003-OMPRAKASH',
    patientId: 'PAT1008',
    patientName: 'Om Prakash Meena',
    patientPhone: '+91 98291 99887',
    patientAge: 83,
    patientGender: 'Male',
    serviceTitle: 'Bedridden Senior Citizen Daily Living Support',
    serviceType: 'service',
    locationAddress: 'Sector 3, Sanganer Goshala Rd, Jaipur, RJ - 302029',
    locality: 'Sanganer',
    city: 'Jaipur',
    startDate: '2026-05-10',
    endDate: '2026-05-26',
    totalDays: 17,
    totalShifts: 17,
    totalHours: 204,
    status: 'Completed',
    assignedStaffId: 'ANA1003',
    assignedStaffName: 'Devendra Singh Shekhawat',
    assignedStaffRole: 'General Patient Care Attendant',
    clinicalRequirement: 'Complete bed-bound care for elderly stroke patient, diaper management, skin hygiene, and assisted feeding.',
    dutyHighlights: [
      'Turned patient side-to-side every 2 hours on anti-decubitus air bed.',
      'Conducted oral hygiene, sponge bathing, and clothing changes twice daily.',
      'Assisted with warm limb massages and passive finger flexion.'
    ],
    dailyLogs: [
      {
        id: 'LOG-1003-OM-1',
        date: '2026-05-26',
        checkInTime: '2026-05-26T08:00:00.000Z',
        checkOutTime: '2026-05-26T20:00:00.000Z',
        shiftHours: 12,
        location: 'Sector 3, Sanganer, Jaipur',
        actionNotes: 'Shift concluded smoothly. All hygiene tasks completed and documented in register.',
        gpsVerified: true,
        coordinates: { lat: 26.8016, lng: 75.7973 }
      }
    ]
  }
];

/**
 * Loads all duty history records from localStorage or initial seeds.
 */
export const getAllDutyHistory = (): PatientDutyRecord[] => {
  const stored = localStorage.getItem(DUTY_HISTORY_STORAGE_KEY);
  if (stored) {
    try {
      const parsed: PatientDutyRecord[] = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    } catch {
      // fallback
    }
  }
  localStorage.setItem(DUTY_HISTORY_STORAGE_KEY, JSON.stringify(SEED_DUTY_HISTORY));
  return SEED_DUTY_HISTORY;
};

/**
 * Synchronizes duty history with the backend database.
 */
export const syncDutyHistoryWithDb = async (): Promise<PatientDutyRecord[]> => {
  try {
    const res = await fetch('/api/staff-duties');
    if (res.ok) {
      const dbDuties: PatientDutyRecord[] = await res.json();
      if (Array.isArray(dbDuties) && dbDuties.length > 0) {
        // Merge with existing local seeds/additions
        const local = getAllDutyHistory();
        const mergedMap = new Map<string, PatientDutyRecord>();
        
        // Start with local
        local.forEach((d) => mergedMap.set(d.id, d));
        // Overwrite with DB
        dbDuties.forEach((d) => mergedMap.set(d.id || (d as any).dutyKey, d));

        const merged = Array.from(mergedMap.values());
        localStorage.setItem(DUTY_HISTORY_STORAGE_KEY, JSON.stringify(merged));
        window.dispatchEvent(new CustomEvent(DUTY_HISTORY_UPDATED_EVENT, { detail: merged }));
        return merged;
      } else {
        // If DB is empty, push initial seeds to DB
        const local = getAllDutyHistory();
        for (const seed of local.slice(0, 5)) {
          try {
            await fetch('/api/staff-duties', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(seed),
            });
          } catch {
            // ignore initial seed error
          }
        }
      }
    }
  } catch (e) {
    console.warn('Duty history DB sync fallback to localStorage:', e);
  }
  return getAllDutyHistory();
};

/**
 * Saves or updates a patient duty history record with instant DB sync.
 */
export const saveDutyRecord = (duty: PatientDutyRecord): PatientDutyRecord[] => {
  const all = getAllDutyHistory();
  const existingIdx = all.findIndex((d) => d.id === duty.id);
  let updated: PatientDutyRecord[];
  if (existingIdx >= 0) {
    updated = [...all];
    updated[existingIdx] = duty;
  } else {
    updated = [duty, ...all];
  }
  localStorage.setItem(DUTY_HISTORY_STORAGE_KEY, JSON.stringify(updated));
  window.dispatchEvent(new CustomEvent(DUTY_HISTORY_UPDATED_EVENT, { detail: updated }));

  // Push to backend API in background
  try {
    fetch('/api/staff-duties', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(duty),
    }).catch((err) => console.warn('Background duty save error:', err));
  } catch (err) {
    console.warn('Failed to dispatch background duty save:', err);
  }

  return updated;
};

/**
 * Deletes a patient duty history record with instant DB sync.
 */
export const deleteDutyRecord = (dutyId: string): PatientDutyRecord[] => {
  const all = getAllDutyHistory();
  const updated = all.filter((d) => d.id !== dutyId && (d as any).dutyKey !== dutyId);
  localStorage.setItem(DUTY_HISTORY_STORAGE_KEY, JSON.stringify(updated));
  window.dispatchEvent(new CustomEvent(DUTY_HISTORY_UPDATED_EVENT, { detail: updated }));

  // Delete from backend API in background
  try {
    fetch(`/api/staff-duties/${encodeURIComponent(dutyId)}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Background duty delete error:', err));
  } catch (err) {
    console.warn('Failed to dispatch background duty delete:', err);
  }

  return updated;
};

/**
 * Helper to calculate days between two dates
 */
export const calculateDutyDays = (startDateStr: string, endDateStr: string): number => {
  if (!startDateStr) return 1;
  const start = new Date(startDateStr);
  const end = endDateStr ? new Date(endDateStr) : new Date(startDateStr);
  
  if (isNaN(start.getTime()) || isNaN(end.getTime())) return 1;
  
  const diffTime = Math.abs(end.getTime() - start.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; // inclusive of start day
  return Math.max(1, diffDays);
};

/**
 * Retrieves past patient duties performed by a specific staff member.
 * Automatically aggregates from:
 * 1. Preloaded duty history records
 * 2. Bookings assigned to this staff member
 * 3. Attendance shift logs
 */
export const getStaffPatientDuties = (
  staffId: string,
  staffName?: string,
  staffRole?: string
): PatientDutyRecord[] => {
  const cleanStaffId = (staffId || '').trim().toUpperCase();
  const cleanStaffName = (staffName || '').trim().toLowerCase();

  const allDuties = getAllDutyHistory();

  // 1. Filter historical records for this staff
  const staffDuties = allDuties.filter((d) => {
    const idMatch = cleanStaffId && d.assignedStaffId && d.assignedStaffId.toUpperCase() === cleanStaffId;
    const nameMatch = cleanStaffName && d.assignedStaffName && (
      d.assignedStaffName.toLowerCase().includes(cleanStaffName) ||
      cleanStaffName.includes(d.assignedStaffName.toLowerCase())
    );
    return idMatch || nameMatch;
  });

  // 2. Also check if there are active bookings assigned to this staff not yet in duty records
  try {
    const storedBookings = localStorage.getItem(BOOKINGS_STORAGE_KEY);
    if (storedBookings) {
      const bookings: Booking[] = JSON.parse(storedBookings);
      bookings.forEach((b) => {
        const isAssigned = (
          (b.assignedStaffId && b.assignedStaffId.toUpperCase() === cleanStaffId) ||
          (b.assignedStaffName && cleanStaffName && b.assignedStaffName.toLowerCase().includes(cleanStaffName))
        );

        if (isAssigned && b.status === 'Confirmed') {
          const alreadyExists = staffDuties.some((d) => d.patientId === b.patientId || d.patientName.toLowerCase() === (b.customerName || '').toLowerCase());
          if (!alreadyExists) {
            staffDuties.unshift({
              id: `DUTY-AUTO-${b.id}`,
              patientId: b.patientId || 'PAT-AUTO',
              patientName: b.customerName,
              patientPhone: b.phoneNumber,
              serviceTitle: b.itemSelected,
              serviceType: b.type,
              locationAddress: b.address,
              locality: b.address.split(',')[0] || 'Jaipur',
              city: 'Jaipur',
              startDate: b.bookingDate,
              endDate: b.bookingDate,
              totalDays: 1,
              totalShifts: 1,
              totalHours: 8,
              status: 'Ongoing',
              assignedStaffId: cleanStaffId,
              assignedStaffName: staffName || 'Healthcare Staff',
              assignedStaffRole: staffRole || 'Staff Nurse',
              clinicalRequirement: b.requirementDetails || 'General clinical care duty.',
              dutyHighlights: [
                'Active assignment dispatched through Ananya Health Care portal.',
                'Daily vitals monitoring and patient home care.'
              ],
              dailyLogs: [
                {
                  id: `LOG-AUTO-${b.id}`,
                  date: b.bookingDate,
                  checkInTime: new Date().toISOString(),
                  checkOutTime: null,
                  shiftHours: 8,
                  location: b.address,
                  actionNotes: 'Duty commenced under current assignment.',
                  gpsVerified: true,
                  coordinates: { lat: 26.8549, lng: 75.8219 }
                }
              ]
            });
          }
        }
      });
    }
  } catch (e) {
    console.warn('Error merging bookings into staff duty history', e);
  }

  // If no duties found and staffId starts with ANA, provide personalized sample
  if (staffDuties.length === 0 && cleanStaffId) {
    return [
      {
        id: `DUTY-${cleanStaffId}-SAMPLE-1`,
        patientId: 'PAT1001',
        patientName: 'Aarav Singhal',
        patientPhone: '+91 98290 12345',
        patientAge: 62,
        patientGender: 'Male',
        serviceTitle: 'Home Patient Care & Vitals Monitoring',
        serviceType: 'service',
        locationAddress: 'Plot No. 12, Sector 4, Malviya Nagar, Jaipur, RJ',
        locality: 'Malviya Nagar',
        city: 'Jaipur',
        startDate: '2026-07-01',
        endDate: '2026-07-10',
        totalDays: 10,
        totalShifts: 10,
        totalHours: 80,
        status: 'Completed',
        assignedStaffId: cleanStaffId,
        assignedStaffName: staffName || 'Caregiver Staff',
        assignedStaffRole: staffRole || 'Healthcare Attendant',
        clinicalRequirement: 'Post-discharge home recovery support, vitals monitoring, and patient hygiene care.',
        dutyHighlights: [
          'Logged daily temperature, pulse, and blood pressure in clinic register.',
          'Assisted patient with daily living activities with zero complaints.',
          'Maintained sterile hygiene and medicine schedule.'
        ],
        dailyLogs: [
          {
            id: `LOG-${cleanStaffId}-1`,
            date: '2026-07-10',
            checkInTime: '2026-07-10T08:00:00.000Z',
            checkOutTime: '2026-07-10T16:00:00.000Z',
            shiftHours: 8,
            location: 'Plot No. 12, Sector 4, Malviya Nagar, Jaipur',
            actionNotes: 'Shift completed on time. Patient vitals within normal range.',
            gpsVerified: true,
            coordinates: { lat: 26.8549, lng: 75.8219 }
          }
        ]
      }
    ];
  }

  return staffDuties;
};
