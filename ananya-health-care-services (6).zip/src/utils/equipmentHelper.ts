import { Equipment } from '../types';
import { EQUIPMENT_CATALOG } from '../data';
import { saveToSql, deleteFromSql, fetchFromSql } from '../lib/sqlClient';

export const EQUIPMENT_STORAGE_KEY = 'ananya_equipment_catalog';
export const EQUIPMENT_UPDATED_EVENT = 'ananya_equipment_updated';

export function getLocalEquipmentCatalog(): Equipment[] {
  try {
    const cached = localStorage.getItem(EQUIPMENT_STORAGE_KEY);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to parse cached equipment catalog:', e);
  }
  return EQUIPMENT_CATALOG;
}

export async function saveEquipmentCatalog(list: Equipment[]): Promise<Equipment[]> {
  localStorage.setItem(EQUIPMENT_STORAGE_KEY, JSON.stringify(list));
  window.dispatchEvent(new CustomEvent(EQUIPMENT_UPDATED_EVENT, { detail: list }));
  return list;
}

export async function syncEquipmentWithPostgres(): Promise<Equipment[]> {
  const local = getLocalEquipmentCatalog();
  try {
    const remote = await fetchFromSql<any[]>('equipment');
    if (remote && Array.isArray(remote) && remote.length > 0) {
      const formatted: Equipment[] = remote.map((r: any) => ({
        id: r.equipmentKey || `eq-${r.id}`,
        title: r.title,
        description: r.description,
        category: r.category,
        rentalPrice: r.rentalPrice,
        purchasePrice: r.purchasePrice,
        features: r.features || [],
        image: r.image || '',
      }));
      localStorage.setItem(EQUIPMENT_STORAGE_KEY, JSON.stringify(formatted));
      window.dispatchEvent(new CustomEvent(EQUIPMENT_UPDATED_EVENT, { detail: formatted }));
      return formatted;
    } else {
      // Seed remote database with initial catalog
      for (const item of local) {
        await saveToSql('equipment', item);
      }
    }
  } catch (e) {
    console.warn('Failed syncing equipment catalog from PostgreSQL:', e);
  }
  return local;
}

// Backward compatibility alias
export const syncEquipmentWithFirestore = syncEquipmentWithPostgres;

export async function updateEquipmentItem(id: string, updates: Partial<Equipment>): Promise<Equipment[]> {
  const current = getLocalEquipmentCatalog();
  const updated = current.map(item => item.id === id ? { ...item, ...updates } : item);
  
  const target = updated.find(i => i.id === id);
  if (target) {
    try {
      await saveToSql('equipment', target);
    } catch (err) {
      console.warn('Failed saving equipment item to PostgreSQL:', err);
    }
  }

  return saveEquipmentCatalog(updated);
}

export async function addEquipmentItem(newItem: Omit<Equipment, 'id'>): Promise<Equipment[]> {
  const current = getLocalEquipmentCatalog();
  const id = `eq-${Date.now()}`;
  const item: Equipment = {
    id,
    ...newItem
  };
  const updated = [item, ...current];
  try {
    await saveToSql('equipment', item);
  } catch (err) {
    console.warn('Failed creating equipment item in PostgreSQL:', err);
  }
  return saveEquipmentCatalog(updated);
}

export async function deleteEquipmentItem(id: string): Promise<Equipment[]> {
  const current = getLocalEquipmentCatalog();
  const updated = current.filter(item => item.id !== id);
  try {
    await deleteFromSql('equipment', id);
  } catch (err) {
    console.warn('Failed deleting equipment item from PostgreSQL:', err);
  }
  return saveEquipmentCatalog(updated);
}

export async function resetEquipmentCatalogToDefault(): Promise<Equipment[]> {
  return saveEquipmentCatalog(EQUIPMENT_CATALOG);
}
