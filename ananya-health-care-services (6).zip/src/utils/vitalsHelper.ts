import { Booking, VitalRecord } from '../types';
import { saveToSql, deleteFromSql, fetchFromSql } from '../lib/sqlClient';

// Centralized LocalStorage keys
export const VITALS_STORAGE_KEY = 'ananya_all_vitals';
export const BOOKINGS_STORAGE_KEY = 'ananya_bookings';

// Preloaded historical vitals for standard patients
const SEED_VITALS: VitalRecord[] = [
  // Patient 1: Aarav Singhal (PAT1001) - Cardiac/Post-op Recovery
  { id: 'v-1001-1', patientId: 'PAT1001', patientName: 'Aarav Singhal', temperature: 100.2, bpSystolic: 115, bpDiastolic: 75, heartRate: 88, timestamp: '2026-07-09' },
  { id: 'v-1001-2', patientId: 'PAT1001', patientName: 'Aarav Singhal', temperature: 99.5, bpSystolic: 118, bpDiastolic: 76, heartRate: 82, timestamp: '2026-07-10' },
  { id: 'v-1001-3', patientId: 'PAT1001', patientName: 'Aarav Singhal', temperature: 98.9, bpSystolic: 120, bpDiastolic: 78, heartRate: 78, timestamp: '2026-07-11' },
  { id: 'v-1001-4', patientId: 'PAT1001', patientName: 'Aarav Singhal', temperature: 98.6, bpSystolic: 122, bpDiastolic: 80, heartRate: 74, timestamp: '2026-07-12' },
  { id: 'v-1001-5', patientId: 'PAT1001', patientName: 'Aarav Singhal', temperature: 98.4, bpSystolic: 120, bpDiastolic: 80, heartRate: 72, timestamp: '2026-07-13' },

  // Patient 2: Rukmani Devi (PAT1002) - Elderly/Alzheimer Care
  { id: 'v-1002-1', patientId: 'PAT1002', patientName: 'Rukmani Devi', temperature: 98.4, bpSystolic: 142, bpDiastolic: 88, heartRate: 85, timestamp: '2026-07-09' },
  { id: 'v-1002-2', patientId: 'PAT1002', patientName: 'Rukmani Devi', temperature: 98.6, bpSystolic: 138, bpDiastolic: 84, heartRate: 82, timestamp: '2026-07-10' },
  { id: 'v-1002-3', patientId: 'PAT1002', patientName: 'Rukmani Devi', temperature: 98.5, bpSystolic: 135, bpDiastolic: 82, heartRate: 79, timestamp: '2026-07-11' },
  { id: 'v-1002-4', patientId: 'PAT1002', patientName: 'Rukmani Devi', temperature: 98.6, bpSystolic: 130, bpDiastolic: 80, heartRate: 76, timestamp: '2026-07-12' },
  { id: 'v-1002-5', patientId: 'PAT1002', patientName: 'Rukmani Devi', temperature: 98.5, bpSystolic: 128, bpDiastolic: 78, heartRate: 74, timestamp: '2026-07-13' },

  // Patient 3: Vinay Rathore (PAT1003) - COPD/Oxygen Loan
  { id: 'v-1003-1', patientId: 'PAT1003', patientName: 'Vinay Rathore', temperature: 98.6, bpSystolic: 132, bpDiastolic: 82, heartRate: 80, timestamp: '2026-07-09' },
  { id: 'v-1003-2', patientId: 'PAT1003', patientName: 'Vinay Rathore', temperature: 98.8, bpSystolic: 130, bpDiastolic: 80, heartRate: 84, timestamp: '2026-07-10' },
  { id: 'v-1003-3', patientId: 'PAT1003', patientName: 'Vinay Rathore', temperature: 98.4, bpSystolic: 125, bpDiastolic: 78, heartRate: 82, timestamp: '2026-07-11' },
  { id: 'v-1003-4', patientId: 'PAT1003', patientName: 'Vinay Rathore', temperature: 98.5, bpSystolic: 122, bpDiastolic: 75, heartRate: 78, timestamp: '2026-07-12' },
  { id: 'v-1003-5', patientId: 'PAT1003', patientName: 'Vinay Rathore', temperature: 98.6, bpSystolic: 120, bpDiastolic: 78, heartRate: 75, timestamp: '2026-07-13' },

  // Patient 4: Kiran Sharma (PAT1004) - Mobility
  { id: 'v-1004-1', patientId: 'PAT1004', patientName: 'Kiran Sharma', temperature: 98.1, bpSystolic: 128, bpDiastolic: 78, heartRate: 72, timestamp: '2026-07-09' },
  { id: 'v-1004-2', patientId: 'PAT1004', patientName: 'Kiran Sharma', temperature: 98.3, bpSystolic: 130, bpDiastolic: 80, heartRate: 74, timestamp: '2026-07-10' },
  { id: 'v-1004-3', patientId: 'PAT1004', patientName: 'Kiran Sharma', temperature: 98.4, bpSystolic: 124, bpDiastolic: 78, heartRate: 72, timestamp: '2026-07-11' },
  { id: 'v-1004-4', patientId: 'PAT1004', patientName: 'Kiran Sharma', temperature: 98.5, bpSystolic: 120, bpDiastolic: 76, heartRate: 70, timestamp: '2026-07-12' },
  { id: 'v-1004-5', patientId: 'PAT1004', patientName: 'Kiran Sharma', temperature: 98.6, bpSystolic: 118, bpDiastolic: 75, heartRate: 68, timestamp: '2026-07-13' },
];

/**
 * Ensures bookings have Patient IDs, saving changes to localStorage.
 */
export const ensurePatientIdsOnBookings = (bookings: Booking[]): Booking[] => {
  let changed = false;
  const updated = bookings.map((b) => {
    let currentPatId = b.patientId ? b.patientId.replace('PAT-', 'PAT') : '';
    if (!currentPatId) {
      changed = true;
      if (b.customerName === 'Aarav Singhal') currentPatId = 'PAT1001';
      else if (b.customerName === 'Rukmani Devi') currentPatId = 'PAT1002';
      else if (b.customerName === 'Vinay Rathore') currentPatId = 'PAT1003';
      else if (b.customerName === 'Kiran Sharma') currentPatId = 'PAT1004';
      else {
        const rand = Math.floor(1000 + Math.random() * 9000);
        currentPatId = `PAT${rand}`;
      }
      return { ...b, patientId: currentPatId };
    }
    if (b.patientId !== currentPatId) {
      changed = true;
      return { ...b, patientId: currentPatId };
    }
    return b;
  });

  if (changed) {
    localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(updated));
  }
  return updated;
};

/**
 * Fetches all vitals from unified central localStorage or initializes with seeds.
 */
export const getAllVitals = (): VitalRecord[] => {
  const stored = localStorage.getItem(VITALS_STORAGE_KEY);
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {
      localStorage.setItem(VITALS_STORAGE_KEY, JSON.stringify(SEED_VITALS));
      return SEED_VITALS;
    }
  } else {
    localStorage.setItem(VITALS_STORAGE_KEY, JSON.stringify(SEED_VITALS));
    return SEED_VITALS;
  }
};

/**
 * Fetches all vitals filtered for a specific patient ID.
 */
export const getVitalsForPatient = (patientId: string): VitalRecord[] => {
  const all = getAllVitals();
  const cleanTarget = (patientId || '').trim().toUpperCase();
  if (!cleanTarget) return [];
  return all.filter((v) => (v.patientId || '').toUpperCase() === cleanTarget);
};

/**
 * Saves or updates a vital record.
 */
export const addVitalRecord = (record: Omit<VitalRecord, 'id'>): VitalRecord => {
  const all = getAllVitals();
  const newRecord: VitalRecord = {
    ...record,
    id: `v-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
  };
  const updated = [newRecord, ...all];
  localStorage.setItem(VITALS_STORAGE_KEY, JSON.stringify(updated));

  // Sync with PostgreSQL
  saveToSql('vitals', newRecord);

  return newRecord;
};

/**
 * Deletes a vital record.
 */
export const deleteVitalRecord = (id: string): VitalRecord[] => {
  const all = getAllVitals();
  const updated = all.filter((v) => v.id !== id);
  localStorage.setItem(VITALS_STORAGE_KEY, JSON.stringify(updated));

  // Delete from PostgreSQL
  deleteFromSql('vitals', id);

  return updated;
};

/**
 * Synchronizes patient vitals with PostgreSQL database.
 */
export const syncVitalsWithPostgres = async (): Promise<VitalRecord[]> => {
  const localList = getAllVitals();
  try {
    const remote = await fetchFromSql<any[]>('vitals');
    if (remote && Array.isArray(remote) && remote.length > 0) {
      const formatted: VitalRecord[] = remote.map((r: any) => ({
        id: r.vitalKey || `v-${r.id}`,
        patientId: r.patientId,
        patientName: r.patientName,
        temperature: r.temperature,
        bpSystolic: r.bpSystolic,
        bpDiastolic: r.bpDiastolic,
        heartRate: r.heartRate,
        timestamp: r.loggedDate || new Date().toISOString().slice(0, 10),
      }));
      localStorage.setItem(VITALS_STORAGE_KEY, JSON.stringify(formatted));
      return formatted;
    } else {
      // Seed remote
      for (const item of localList) {
        await saveToSql('vitals', item);
      }
    }
  } catch (err) {
    console.warn('Failed syncing vitals with PostgreSQL:', err);
  }
  return localList;
};

// Backward compatibility alias
export const syncVitalsWithFirestore = syncVitalsWithPostgres;
