// src/db/schema.ts
import { pgTable, serial, text, timestamp, integer, jsonb } from 'drizzle-orm/pg-core';

// Users table (Stores staff, admin, and patient accounts)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Auth UID or user identifier
  email: text('email'),
  name: text('name'),
  role: text('role').default('patient'), // 'admin' | 'staff' | 'patient'
  phoneNumber: text('phone_number'),
  status: text('status').default('Active'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Bookings table (Patient care bookings & equipment rentals/purchases)
export const bookings = pgTable('bookings', {
  id: serial('id').primaryKey(),
  bookingKey: text('booking_key').notNull().unique(),
  customerName: text('customer_name').notNull().default('Anonymous Patient'),
  phoneNumber: text('phone_number').notNull().default(''),
  email: text('email').default(''),
  type: text('type').notNull().default('service'), // 'service' | 'equipment'
  itemSelected: text('item_selected').notNull().default('General Service'),
  bookingDate: text('booking_date').notNull().default(''),
  address: text('address').notNull().default(''),
  requirementDetails: text('requirement_details').default(''),
  status: text('status').default('Pending'), // 'Pending' | 'Confirmed' | 'Cancelled'
  patientId: text('patient_id').default(''),
  assignedStaffId: text('assigned_staff_id').default(''),
  assignedStaffName: text('assigned_staff_name').default(''),
  assignedStaffRole: text('assigned_staff_role').default(''),
  createdAt: timestamp('created_at').defaultNow(),
});

// Medical Equipment catalog
export const equipment = pgTable('equipment', {
  id: serial('id').primaryKey(),
  equipmentKey: text('equipment_key').notNull().unique(),
  title: text('title').notNull().default('Medical Equipment'),
  description: text('description').notNull().default(''),
  category: text('category').notNull().default('both'), // 'rent' | 'purchase' | 'both'
  rentalPrice: text('rental_price').default(''),
  purchasePrice: text('purchase_price').default(''),
  features: jsonb('features').$type<string[]>().default([]),
  image: text('image').default(''),
  createdAt: timestamp('created_at').defaultNow(),
});

// Patient Vitals table
export const vitals = pgTable('vitals', {
  id: serial('id').primaryKey(),
  vitalKey: text('vital_key').notNull().unique(),
  patientId: text('patient_id').notNull().default('PAT1001'),
  patientName: text('patient_name').notNull().default('Patient'),
  temperature: integer('temperature').notNull().default(98), // In °F
  bpSystolic: integer('bp_systolic').notNull().default(120),
  bpDiastolic: integer('bp_diastolic').notNull().default(80),
  heartRate: integer('heart_rate').notNull().default(72),
  loggedDate: text('logged_date').notNull().default(''), // YYYY-MM-DD
  createdAt: timestamp('created_at').defaultNow(),
});

// Staff Attendance table
export const attendance = pgTable('attendance', {
  id: serial('id').primaryKey(),
  attendanceKey: text('attendance_key').notNull().unique(),
  userId: text('user_id').notNull().default(''),
  staffName: text('staff_name').notNull().default('Staff Member'),
  role: text('role').notNull().default('Clinical Staff'),
  checkInTime: text('check_in_time').notNull().default(''),
  checkOutTime: text('check_out_time'),
  location: text('location').notNull().default(''),
  actionNotes: text('action_notes').default(''),
  date: text('date').notNull().default(''),
  coordinates: jsonb('coordinates').$type<{ lat: number; lng: number }>(),
  checkOutCoordinates: jsonb('check_out_coordinates').$type<{ lat: number; lng: number }>(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Brand Settings table (Logo, Name, Tagline)
export const brandSettings = pgTable('brand_settings', {
  id: serial('id').primaryKey(),
  brandKey: text('brand_key').notNull().unique().default('default_brand'),
  brandName: text('brand_name').notNull().default('ANANYA'),
  logoUrl: text('logo_url').default(''),
  tagline: text('tagline').default('HEALTH CARE SERVICES'),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Job Applications table
export const jobApplications = pgTable('job_applications', {
  id: serial('id').primaryKey(),
  appKey: text('app_key').notNull().unique(),
  applicantName: text('applicant_name').notNull().default('Applicant'),
  phoneNumber: text('phone_number').notNull().default(''),
  email: text('email').default(''),
  position: text('position').notNull().default('Healthcare Professional'),
  experienceYears: text('experience_years').default(''),
  qualifications: text('qualifications').default(''),
  coverMessage: text('cover_message').default(''),
  status: text('status').default('Received'), // 'Received' | 'Shortlisted' | 'Rejected'
  createdAt: timestamp('created_at').defaultNow(),
});

// Staff Users table
export const staffUsers = pgTable('staff_users', {
  id: serial('id').primaryKey(),
  staffKey: text('staff_key').notNull().unique(),
  userId: text('user_id').notNull(),
  name: text('name').notNull().default('Healthcare Staff'),
  role: text('role').notNull().default('ICU Staff Nurse'),
  phoneNumber: text('phone_number').notNull().default(''),
  email: text('email').notNull().default(''),
  password: text('password').default('Ananya@123'),
  status: text('status').default('Active'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Staff Duties & Patient Allocation table (Duty Days, Location, Patient, Shifts)
export const staffDuties = pgTable('staff_duties', {
  id: serial('id').primaryKey(),
  dutyKey: text('duty_key').notNull().unique(),
  patientId: text('patient_id').notNull().default('PAT1001'),
  patientName: text('patient_name').notNull().default('Patient'),
  patientPhone: text('patient_phone').default(''),
  patientAge: integer('patient_age').default(50),
  patientGender: text('patient_gender').default('Male'),
  serviceTitle: text('service_title').notNull().default('Home Care Service'),
  serviceType: text('service_type').notNull().default('service'), // 'service' | 'equipment'
  locationAddress: text('location_address').notNull().default(''),
  locality: text('locality').default('Jaipur'),
  city: text('city').default('Jaipur'),
  startDate: text('start_date').notNull().default(''), // YYYY-MM-DD
  endDate: text('end_date').notNull().default(''), // YYYY-MM-DD
  totalDays: integer('total_days').notNull().default(1), // Duty Days count
  totalShifts: integer('total_shifts').notNull().default(1),
  totalHours: integer('total_hours').notNull().default(8),
  status: text('status').notNull().default('Ongoing'), // 'Ongoing' | 'Completed' | 'Scheduled'
  assignedStaffId: text('assigned_staff_id').notNull().default(''),
  assignedStaffName: text('assigned_staff_name').notNull().default(''),
  assignedStaffRole: text('assigned_staff_role').default(''),
  clinicalRequirement: text('clinical_requirement').default(''),
  dutyHighlights: jsonb('duty_highlights').$type<string[]>().default([]),
  dailyLogs: jsonb('daily_logs').$type<any[]>().default([]),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Staff Profile Change Requests table (Requires Admin Approval)
export const staffProfileRequests = pgTable('staff_profile_requests', {
  id: serial('id').primaryKey(),
  requestKey: text('request_key').notNull().unique(),
  staffId: text('staff_id').notNull(),
  currentName: text('current_name').notNull().default(''),
  currentRole: text('current_role').notNull().default(''),
  currentPhone: text('current_phone').notNull().default(''),
  currentEmail: text('current_email').notNull().default(''),
  requestedName: text('requested_name').notNull().default(''),
  requestedRole: text('requested_role').notNull().default(''),
  requestedPhone: text('requested_phone').notNull().default(''),
  requestedEmail: text('requested_email').notNull().default(''),
  reason: text('reason').default(''),
  status: text('status').default('Pending'), // 'Pending' | 'Approved' | 'Rejected'
  adminNotes: text('admin_notes').default(''),
  createdAt: timestamp('created_at').defaultNow(),
  resolvedAt: timestamp('resolved_at'),
});
