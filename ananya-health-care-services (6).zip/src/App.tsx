import { useState, useEffect } from 'react';
import { SERVICES, EQUIPMENT_CATALOG, TEAM_MEMBERS, TESTIMONIALS, FAQS, OFFICES } from './data';
import { Service, Equipment, Booking, Office, TeamMember, UserProfile } from './types';
import { 
  getLocalEquipmentCatalog, 
  syncEquipmentWithFirestore, 
  EQUIPMENT_UPDATED_EVENT 
} from './utils/equipmentHelper';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SplashScreen } from './components/SplashScreen';
import { BookingForm } from './components/BookingForm';
import { AdminBookings } from './components/AdminBookings';
import { CareersPage } from './components/CareersPage';
import { Logo } from './components/Logo';
import { FamilyPortal } from './components/FamilyPortal';
import { UserBookingTracker } from './components/UserBookingTracker';
import { ProfilePortal } from './components/ProfilePortal';
import { getStoredCurrentUser } from './lib/auth';
import { 
  Heart, 
  ShieldCheck, 
  Phone, 
  CheckCircle2, 
  Activity, 
  ChevronDown, 
  ChevronRight, 
  Star, 
  MessageSquarePlus, 
  Calendar, 
  MapPin, 
  ArrowUpRight, 
  DollarSign, 
  Users, 
  Check, 
  Info,
  Clock,
  ArrowRight,
  ArrowLeft,
  Mail,
  MessageCircle,
  CalendarCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { syncCollection } from './lib/firebase';

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [tabHistory, setTabHistory] = useState<string[]>(['home']);
  const [preselectedBooking, setPreselectedBooking] = useState<{ item: string; type: 'service' | 'equipment' } | undefined>(undefined);
  const [refreshAdminTrigger, setRefreshAdminTrigger] = useState(0);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [selectedOfficeId, setSelectedOfficeId] = useState<string>('jaipur');
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(getStoredCurrentUser());

  // Listen to auth state changes across components
  useEffect(() => {
    const handleAuthChange = () => {
      setCurrentUser(getStoredCurrentUser());
    };
    window.addEventListener('ananya_auth_changed', handleAuthChange);
    window.addEventListener('storage', handleAuthChange);
    return () => {
      window.removeEventListener('ananya_auth_changed', handleAuthChange);
      window.removeEventListener('storage', handleAuthChange);
    };
  }, []);

  // Navigation history & Back button handler
  const navigateToTab = (tabId: string) => {
    if (tabId === currentTab) return;
    setTabHistory((prev) => [...prev, tabId]);
    setCurrentTab(tabId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoBack = () => {
    if (tabHistory.length > 1) {
      const updatedHistory = tabHistory.slice(0, tabHistory.length - 1);
      const prevTab = updatedHistory[updatedHistory.length - 1];
      setTabHistory(updatedHistory);
      setCurrentTab(prevTab);
    } else {
      setCurrentTab('home');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getTabName = (tabId: string) => {
    switch (tabId) {
      case 'home': return 'Home';
      case 'services': return 'Services';
      case 'equipment': return 'Medical Equipment';
      case 'team': return 'Our Team';
      case 'careers': return 'Careers';
      case 'contact': return 'Contact Us';
      case 'family-portal': return 'Family Portal';
      case 'profile': return 'My Profile';
      case 'admin': return 'Staff Portal';
      case 'booking': return 'Booking';
      default: return 'Previous Page';
    }
  };
  
  // Toast notifications for new bookings
  const [showToast, setShowToast] = useState(false);
  const [latestBooking, setLatestBooking] = useState<Booking | null>(null);
  const [expandedVitalsServiceId, setExpandedVitalsServiceId] = useState<string | null>(null);

  // Dynamic Team Members state synced from local and Firestore
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(TEAM_MEMBERS);

  // Dynamic Equipment Catalog state synced from local and Firestore
  const [equipmentCatalog, setEquipmentCatalog] = useState<Equipment[]>(getLocalEquipmentCatalog());

  // Sync equipment catalog on mount or when admin updates them
  useEffect(() => {
    const loadAndSyncEquipment = async () => {
      try {
        const synced = await syncEquipmentWithFirestore();
        setEquipmentCatalog(synced);
      } catch (e) {
        console.error("Failed to sync equipment catalog", e);
        setEquipmentCatalog(getLocalEquipmentCatalog());
      }
    };
    loadAndSyncEquipment();

    const onEquipmentUpdate = (e: CustomEvent) => {
      if (e.detail) {
        setEquipmentCatalog(e.detail);
      } else {
        setEquipmentCatalog(getLocalEquipmentCatalog());
      }
    };

    window.addEventListener(EQUIPMENT_UPDATED_EVENT, onEquipmentUpdate as EventListener);
    return () => {
      window.removeEventListener(EQUIPMENT_UPDATED_EVENT, onEquipmentUpdate as EventListener);
    };
  }, [refreshAdminTrigger]);

  // Sync team members on mount or when admin updates them
  useEffect(() => {
    const loadAndSyncTeam = async () => {
      try {
        const synced = await syncCollection<TeamMember>('team_members', 'ananya_team_members', TEAM_MEMBERS);
        setTeamMembers(synced);
      } catch (e) {
        console.error("Failed to sync team members", e);
        // Fallback to local storage or defaults on failure/offline
        const stored = localStorage.getItem('ananya_team_members');
        if (stored) {
          try {
            setTeamMembers(JSON.parse(stored));
          } catch {
            setTeamMembers(TEAM_MEMBERS);
          }
        } else {
          setTeamMembers(TEAM_MEMBERS);
        }
      }
    };
    loadAndSyncTeam();
  }, [refreshAdminTrigger]);

  // Quick action to jump to Booking Tab with a preselected service or equipment item
  const handleBookNow = (itemName?: string, type?: 'service' | 'equipment') => {
    if (currentUser?.role === 'staff') {
      navigateToTab('profile');
      return;
    }
    if (itemName && type) {
      setPreselectedBooking({ item: itemName, type });
    } else {
      setPreselectedBooking(undefined);
    }
    navigateToTab('booking');
  };

  useEffect(() => {
    if (currentUser?.role === 'staff' && currentTab === 'booking') {
      setCurrentTab('profile');
    }
  }, [currentUser, currentTab]);

  const handleBookingRegistered = (booking: Booking) => {
    setLatestBooking(booking);
    setShowToast(true);
    setRefreshAdminTrigger((prev) => prev + 1);
  };

  useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => {
        setShowToast(false);
      }, 6000);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  const previousTabId = tabHistory.length > 1 ? tabHistory[tabHistory.length - 2] : undefined;
  const previousTabName = previousTabId ? getTabName(previousTabId) : undefined;

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="min-h-screen bg-slate-50/50 flex flex-col justify-between text-gray-800 selection:bg-brand-magenta selection:text-white"
    >
      {/* Header Navigation */}
      <Header 
        currentTab={currentTab} 
        setCurrentTab={navigateToTab} 
        onBookNow={handleBookNow} 
      />

      {/* Page Back Navigation Bar (Visible on inner pages, hidden on Home page) */}
      {currentTab !== 'home' && (
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pt-4 pb-1">
          <button
            onClick={handleGoBack}
            id="global-page-back-button"
            className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold rounded-full bg-white hover:bg-brand-navy hover:text-white text-brand-navy border border-slate-200/80 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer group active:scale-95"
            title="Go back to previous page"
          >
            <ArrowLeft className="w-4 h-4 text-brand-magenta group-hover:text-white transition-colors shrink-0" />
            <span>Back</span>
          </button>
        </div>
      )}

      {/* Main Body Stage with Staggered Fade-in Animations */}
      <main className="flex-grow pb-24 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="w-full"
          >
            
            {/* 1. HOME TAB */}
            {currentTab === 'home' && (
              <div className="space-y-20">
                {/* Modern Editorial Hero Section */}
                <section className="relative bg-brand-navy text-white py-16 md:py-28 overflow-hidden">
                  {/* Visual Background Gradients & Geometry */}
                  <div className="absolute inset-0 bg-radial-at-t from-brand-navy-light via-brand-navy to-brand-navy/95" />
                  <div className="absolute top-0 right-0 w-96 h-96 bg-brand-magenta/10 rounded-full blur-3xl opacity-60" />
                  <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-brand-navy-light/30 rounded-full blur-2xl opacity-40" />

                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                    
                    {/* Left Text Column */}
                    <div className="lg:col-span-7 space-y-6 md:space-y-8">
                      <div className="inline-flex items-center gap-2 bg-brand-magenta/15 text-brand-magenta-light px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest border border-brand-magenta/20">
                        <Heart className="w-4 h-4 fill-brand-magenta animate-pulse" /> ISO 9001:2015 Certified Care
                      </div>

                      <h1 className="font-display text-3xl md:text-4xl lg:text-5xl text-white tracking-tight leading-none md:leading-tight">
                        <span className="font-light">Professional Staff.</span> <br />
                        <span className="text-brand-magenta-light font-extrabold">Comprehensive Care.</span>
                      </h1>

                      <p className="text-gray-300 text-base md:text-lg max-w-2xl leading-relaxed font-sans font-light">
                        Bringing dedicated ICU/Ward nursing, empathetic patient care attendants, and standard diagnostic medical equipment directly into the safety of your private home in Jaipur.
                      </p>

                      {/* CTA Action Bar */}
                      <div className="flex flex-col sm:flex-row gap-4">
                        <button
                          onClick={() => handleBookNow()}
                          className="bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold py-4 px-8 rounded-full shadow-lg shadow-brand-magenta/20 transition-all text-sm flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                        >
                          Schedule Care Staff <ArrowRight className="w-4 h-4" />
                        </button>
                        {currentUser ? (
                          <button
                            onClick={() => {
                              const el = document.getElementById('user-booking-tracker-section');
                              if (el) {
                                el.scrollIntoView({ behavior: 'smooth' });
                              }
                            }}
                            className="bg-white/15 hover:bg-white/25 text-white border border-white/30 font-bold py-4 px-8 rounded-full transition-all text-sm flex items-center justify-center gap-2 cursor-pointer shadow-md"
                          >
                            <CalendarCheck className="w-4 h-4 text-brand-magenta-light" />
                            <span>Track Your Bookings</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => navigateToTab('equipment')}
                            className="bg-white/10 hover:bg-white/15 text-white border border-white/20 hover:border-white/40 font-semibold py-4 px-8 rounded-full transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
                          >
                            Explore Equipment catalog
                          </button>
                        )}
                      </div>

                      {/* Bullet Highlights */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-white/10 text-xs font-semibold text-gray-300 font-sans">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-5 h-5 text-brand-magenta shrink-0" />
                          <span>Strict Staff Verifications</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-5 h-5 text-brand-magenta shrink-0" />
                          <span>24/7 Deployment Shifts</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-5 h-5 text-brand-magenta shrink-0" />
                          <span>Same-Day Equip Delivery</span>
                        </div>
                      </div>
                    </div>

                    {/* Right Dynamic Asset Card */}
                    <div className="lg:col-span-5 relative">
                      <div className="absolute inset-0 bg-brand-magenta/10 rounded-3xl blur-2xl" />
                      
                      {/* Premium card mock of the services summary */}
                      <div className="relative bg-white text-brand-navy p-6 md:p-8 rounded-3xl shadow-2xl border border-gray-100 flex flex-col gap-6">
                        <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                          <div className="flex items-center gap-2">
                            <Activity className="w-5 h-5 text-brand-magenta" />
                            <span className="font-display font-bold text-sm tracking-widest text-brand-navy">LIVE STATUS</span>
                          </div>
                          <span className="flex items-center gap-1 text-[10px] bg-green-500/10 text-green-700 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                            <span className="w-1.5 h-1.5 bg-green-600 rounded-full animate-ping" /> Operations Active
                          </span>
                        </div>

                        {/* Miniature Services Preview List */}
                        <div className="space-y-4">
                          {[
                            { title: 'Home Nursing Care', spec: 'Registered GNM/B.Sc', active: '18 Nurses deployed today' },
                            { title: 'Patient Attendants', spec: 'Geriatric / Bedridden care', active: '42 Shifts active' },
                            { title: 'Medical Equipment', spec: 'Oxygen / CPAP / Beds', active: 'Immediate dispatch' },
                          ].map((item, idx) => (
                            <div key={idx} className="flex justify-between items-center bg-gray-50 p-3.5 rounded-xl border border-gray-200/40">
                              <div>
                                <h4 className="font-display font-bold text-xs text-brand-navy">{item.title}</h4>
                                <p className="text-[10px] text-gray-500 font-medium mt-0.5">{item.spec}</p>
                              </div>
                              <span className="text-[10px] text-brand-magenta font-mono font-bold bg-brand-magenta/5 px-2.5 py-1 rounded-lg border border-brand-magenta/10">
                                {item.active}
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* Live Emergency call-out banner inside hero */}
                        <div className="bg-brand-navy text-white p-4 rounded-2xl flex items-center justify-between border border-brand-navy-light/60">
                          <div>
                            <p className="text-[10px] text-gray-400 font-semibold uppercase">Immediate Counseling</p>
                            <p className="font-display font-bold text-sm text-white mt-0.5">+91 7734931740</p>
                          </div>
                          <a
                            href="tel:+917734931740"
                            className="bg-brand-magenta text-white p-2 rounded-full hover:bg-brand-magenta-light transition-colors"
                          >
                            <Phone className="w-4 h-4" />
                          </a>
                        </div>
                      </div>

                    </div>
                  </div>
                </section>

                {/* Logged-In User Booking Tracker Component */}
                {currentUser && (
                  <UserBookingTracker
                    currentUser={currentUser}
                    onBookNew={handleBookNow}
                    onOpenFamilyPortal={(patientId) => {
                      navigateToTab('family-portal');
                    }}
                  />
                )}

                {/* Live Business Counters Row */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm grid grid-cols-2 md:grid-cols-4 gap-8 divide-y-2 md:divide-y-0 md:divide-x-2 divide-gray-100">
                    {[
                      { num: '120+', text: 'Trained Staff Nurses', sub: 'Verified & Registered' },
                      { num: '1,500+', text: 'Homes Facilitated', sub: 'Across Jaipur & RJ' },
                      { num: '15+', text: 'Equipment Categories', sub: 'Available For Rental' },
                      { num: '24/7', text: 'Patient Coordination', sub: 'Continuous Monitoring' },
                    ].map((c, idx) => (
                      <div key={idx} className="pt-6 md:pt-0 md:px-6 text-center first:pt-0 first:pl-0 flex flex-col justify-center">
                        <p className="font-display font-black text-4xl text-brand-magenta">{c.num}</p>
                        <p className="text-sm font-bold text-brand-navy mt-1">{c.text}</p>
                        <p className="text-xs text-gray-500 mt-0.5 font-sans">{c.sub}</p>
                      </div>
                    ))}
                  </div>
                </section>

                {/* Core Pillars / Why Choose Ananya Health Care */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                  <div className="text-center max-w-2xl mx-auto">
                    <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/5 border border-brand-magenta/10 px-3.5 py-1.5 rounded-full">
                      Pillars of Clinical Excellence
                    </span>
                    <h2 className="font-display font-bold text-3xl md:text-4xl text-brand-navy mt-4">
                      Why Families Trust Ananya Health Care Services
                    </h2>
                    <p className="text-gray-500 text-sm mt-2 leading-relaxed">
                      We treat your family members with the exact scientific precision, medical discipline, and loving respect they deserve.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                      {
                        title: 'Fully Verified & Registered Staff',
                        desc: 'Every nurse holds professional clinical credentials (B.Sc or GNM). All attendants undergo background vetting and intensive physical handling training.',
                        iconName: ShieldCheck,
                        color: 'text-green-600 bg-green-50 border-green-100',
                      },
                      {
                        title: 'Perfect Care Match & Guarantee',
                        desc: 'We map staff to specific patient parameters (gender, language, illness complexity). In case of mismatch, our manager guarantees replacements within 24 hours.',
                        iconName: Users,
                        color: 'text-brand-magenta bg-brand-magenta/5 border-brand-magenta/10',
                      },
                      {
                        title: '24/7 Continuous Support Desk',
                        desc: 'Clinical situations can change in seconds. Our operations supervisors remain awake 24/7 to solve emergencies, coordinate oxygen, or adjust shifts.',
                        iconName: Clock,
                        color: 'text-blue-600 bg-blue-50 border-blue-100',
                      },
                    ].map((p, idx) => {
                      const Icon = p.iconName;
                      return (
                        <div key={idx} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
                          <div className="space-y-4">
                            <div className={`p-3.5 rounded-2xl border w-fit ${p.color}`}>
                              <Icon className="w-6 h-6" />
                            </div>
                            <h3 className="font-display font-bold text-lg text-brand-navy">{p.title}</h3>
                            <p className="text-gray-500 text-sm leading-relaxed font-sans">{p.desc}</p>
                          </div>
                          <div className="pt-6 border-t border-gray-50 mt-6 flex items-center gap-1.5 text-xs font-bold text-brand-navy">
                            <span>Hospital-grade protocols standard</span>
                            <Check className="w-4 h-4 text-green-500" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>

                {/* Patient Testimonial Grid */}
                <section className="bg-white py-16 border-y border-gray-100">
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                    <div className="text-center max-w-2xl mx-auto">
                      <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/5 border border-brand-magenta/10 px-3.5 py-1.5 rounded-full">
                        Patient Stories
                      </span>
                      <h2 className="font-display font-bold text-3xl text-brand-navy mt-4">
                        What Loving Families Say About Us
                      </h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      {TESTIMONIALS.map((t) => (
                        <div key={t.id} className="bg-slate-50 p-8 rounded-3xl border border-gray-200/40 relative flex flex-col justify-between">
                          <div className="space-y-4">
                            <div className="flex gap-1 text-amber-500">
                              {[...Array(t.rating)].map((_, i) => (
                                <Star key={i} className="w-4 h-4 fill-amber-500" />
                              ))}
                            </div>
                            <p className="text-gray-600 text-sm leading-relaxed italic font-sans">
                              &ldquo;{t.content}&rdquo;
                            </p>
                          </div>

                          <div className="pt-6 border-t border-gray-200/60 mt-6 flex justify-between items-center">
                            <div>
                              <h4 className="font-display font-bold text-sm text-brand-navy">{t.name}</h4>
                              <p className="text-xs text-gray-500 font-medium">{t.role}</p>
                            </div>
                            <span className="text-[10px] text-gray-400 font-mono font-medium">{t.date}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </section>

                {/* FAQ Interactive Accordion */}
                <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                  <div className="text-center">
                    <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest">
                      Got Questions?
                    </span>
                    <h2 className="font-display font-bold text-3xl text-brand-navy mt-2">
                      Frequently Asked Questions
                    </h2>
                  </div>

                  <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden divide-y divide-gray-100 font-sans">
                    {FAQS.map((faq, idx) => {
                      const isOpen = activeFaq === idx;
                      return (
                        <div key={idx} className="transition-colors">
                          <button
                            onClick={() => setActiveFaq(isOpen ? null : idx)}
                            className="w-full px-6 py-5 text-left flex justify-between items-center gap-4 hover:bg-gray-50/50 cursor-pointer"
                          >
                            <span className="font-bold text-sm text-brand-navy md:text-base">{faq.q}</span>
                            <span className={`p-1.5 rounded-lg border border-gray-200 transition-transform duration-300 ${isOpen ? 'rotate-180 bg-brand-magenta/5 text-brand-magenta border-brand-magenta/25' : 'bg-white text-gray-400'}`}>
                              <ChevronDown className="w-4 h-4" />
                            </span>
                          </button>
                          <AnimatePresence initial={false}>
                            {isOpen && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.2 }}
                                className="overflow-hidden"
                              >
                                <div className="px-6 pb-6 pt-1 text-sm text-gray-600 leading-relaxed bg-gray-50/30">
                                  {faq.a}
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })}
                  </div>
                </section>

                {/* Bottom Urgency Section Banner */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="bg-brand-navy text-white rounded-3xl p-8 md:p-12 relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-8 border border-white/5 shadow-2xl">
                    <div className="absolute top-0 right-0 w-96 h-96 bg-brand-magenta/5 rounded-full blur-3xl" />
                    
                    <div className="space-y-4 max-w-xl text-center md:text-left">
                      <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest">
                        Available For Immediate Setup
                      </span>
                      <h3 className="font-display font-bold text-2xl md:text-3xl">
                        Ready to secure professional care at home?
                      </h3>
                      <p className="text-gray-300 text-sm leading-relaxed font-sans">
                        Don&apos;t wait. Register your booking request now, or call our team to discuss chronic condition packages.
                      </p>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 shrink-0 w-full md:w-auto">
                      <button
                        onClick={() => handleBookNow()}
                        className="bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold py-3.5 px-8 rounded-full transition-all text-sm flex items-center justify-center gap-2 cursor-pointer active:scale-95 shadow-lg shadow-brand-magenta/15"
                      >
                        Book Online Now
                      </button>
                      <a
                        href="tel:+917734931740"
                        className="bg-white/10 hover:bg-white/15 text-white border border-white/20 hover:border-white/40 font-semibold py-3.5 px-8 rounded-full text-center transition-all text-sm flex items-center justify-center gap-2"
                      >
                        <Phone className="w-4 h-4 text-brand-magenta" /> Call +91 7734931740
                      </a>
                    </div>
                  </div>
                </section>
              </div>
            )}

            {/* 2. SERVICES TAB */}
            {currentTab === 'services' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 py-12">
                {/* Services Header */}
                <div className="text-center max-w-2xl mx-auto">
                  <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/5 border border-brand-magenta/10 px-3.5 py-1.5 rounded-full">
                    Our Specialized Offerings
                  </span>
                  <h2 className="font-display font-black text-3xl md:text-4xl text-brand-navy mt-4">
                    Home Healthcare Services
                  </h2>
                  <p className="text-gray-500 text-sm mt-2 leading-relaxed">
                    Qualified clinical nursing, patient care attendants, and customized recuperation programs mapped directly to Doctor prescriptions.
                  </p>
                </div>

                {/* Services Detailed List */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {SERVICES.map((srv) => (
                    <div
                      key={srv.id}
                      className="bg-white rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow p-6 md:p-8 flex flex-col justify-between relative overflow-hidden"
                    >
                      <div className="space-y-5">
                        {/* Title and Icon block */}
                        <div className="flex items-start gap-4">
                          <div className="p-3.5 bg-brand-navy/5 text-brand-navy border border-brand-navy/5 rounded-2xl shrink-0">
                            <Activity className="w-6 h-6 text-brand-magenta" />
                          </div>
                          <div>
                            <h3 className="font-display font-bold text-xl text-brand-navy">{srv.title}</h3>
                            <span className="text-xs text-brand-magenta font-semibold font-mono bg-brand-magenta/5 px-2.5 py-1 rounded-lg border border-brand-magenta/10 inline-block mt-1.5">
                              {srv.rates}
                            </span>
                          </div>
                        </div>

                        <p className="text-gray-600 text-sm leading-relaxed font-sans">{srv.longDescription}</p>

                        {/* Features Checkbox Bullet List */}
                        <div className="space-y-2.5 pt-4 border-t border-gray-100">
                          <p className="text-xs font-bold text-brand-navy uppercase tracking-wider">Key Inclusions & Skills:</p>
                          <ul className="grid grid-cols-1 gap-2 text-xs font-medium text-gray-600">
                            {srv.features.map((feat, index) => (
                              <li key={index} className="flex items-start gap-2">
                                <Check className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                                <span className="leading-relaxed">{feat}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* Footer CTA of the service card */}
                      <div className="pt-6 mt-6 border-t border-gray-150/60 flex flex-col sm:flex-row justify-between items-center gap-4">
                        <span className="text-xs text-gray-400 font-sans flex items-center gap-1 shrink-0">
                          <ShieldCheck className="w-4 h-4 text-brand-navy" /> Certified and verified
                        </span>
                        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                          <button
                            onClick={() => handleBookNow(srv.title, 'service')}
                            className="flex-1 sm:flex-initial bg-brand-magenta hover:bg-brand-magenta-light text-white font-bold py-2.5 px-6 rounded-xl text-xs transition-all shadow-md hover:shadow-lg active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            Book Staff Now <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 3. MEDICAL EQUIPMENT TAB */}
            {currentTab === 'equipment' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 py-12">
                {/* Equipment Header */}
                <div className="text-center max-w-2xl mx-auto">
                  <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/5 border border-brand-magenta/10 px-3.5 py-1.5 rounded-full">
                    Medical Devices Catalog
                  </span>
                  <h2 className="font-display font-black text-3xl md:text-4xl text-brand-navy mt-4">
                    Medical Equipment Catalog
                  </h2>
                  <p className="text-gray-500 text-sm mt-2 leading-relaxed">
                    Choose clinical-grade medical equipment for rent or permanent purchase. Sanitized, fully calibrated, and delivered directly to your doorstep.
                  </p>
                </div>

                {/* Grid layout with beautiful cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {equipmentCatalog.map((eq) => (
                    <div
                      key={eq.id}
                      className="bg-white rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col justify-between"
                    >
                      {/* Image section with fallbacks */}
                      <div className="relative h-48 bg-slate-100 overflow-hidden flex items-center justify-center">
                        {eq.image && eq.image.trim() !== '' ? (
                          <img
                            src={eq.image}
                            alt={eq.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=600';
                            }}
                          />
                        ) : (
                          <div className="flex flex-col items-center justify-center text-gray-400 p-4">
                            <Activity className="w-8 h-8 mb-1 text-gray-300" />
                            <span className="text-xs font-bold text-gray-500">{eq.title}</span>
                          </div>
                        )}
                        <div className="absolute top-4 left-4 flex gap-1.5 flex-wrap">
                          {eq.rentalPrice && (
                            <span className="text-[10px] font-bold bg-brand-navy text-white px-2.5 py-1 rounded-full uppercase tracking-wider shadow-sm">
                              For Rent
                            </span>
                          )}
                          {eq.purchasePrice && (
                            <span className="text-[10px] font-bold bg-brand-magenta text-white px-2.5 py-1 rounded-full uppercase tracking-wider shadow-sm">
                              Purchase
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Info Details Section */}
                      <div className="p-6 space-y-4 flex-grow flex flex-col justify-between">
                        <div className="space-y-2">
                          <h3 className="font-display font-bold text-lg text-brand-navy line-clamp-1" title={eq.title}>
                            {eq.title}
                          </h3>
                          <p className="text-gray-500 text-xs leading-relaxed font-sans line-clamp-2">
                            {eq.description}
                          </p>
                        </div>

                        {/* Cost list details */}
                        <div className="bg-slate-50 p-3 rounded-xl space-y-1.5 text-xs border border-gray-100">
                          {eq.rentalPrice && (
                            <div className="flex justify-between font-sans">
                              <span className="text-gray-500">Rental Fee:</span>
                              <strong className="text-brand-navy">{eq.rentalPrice}</strong>
                            </div>
                          )}
                          {eq.purchasePrice && (
                            <div className="flex justify-between font-sans">
                              <span className="text-gray-500">Buy Price:</span>
                              <strong className="text-brand-magenta">{eq.purchasePrice}</strong>
                            </div>
                          )}
                        </div>

                        {/* Key Features bullets */}
                        <div className="space-y-1">
                          <p className="text-[10px] font-bold text-brand-navy uppercase tracking-wider">Features:</p>
                          <ul className="text-[11px] text-gray-600 space-y-1 font-sans">
                            {eq.features.slice(0, 3).map((feat, index) => (
                              <li key={index} className="flex items-start gap-1">
                                <Check className="w-3 h-3 text-green-500 mt-0.5 shrink-0" />
                                <span className="line-clamp-1">{feat}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* Booking CTA Button of card */}
                      <div className="p-6 border-t border-gray-50 pt-4 bg-slate-50/50 flex justify-between items-center gap-2">
                        <span className="text-[10px] text-gray-400 font-sans font-medium flex items-center gap-1">
                          <Info className="w-3.5 h-3.5 text-brand-navy" /> Calibrated
                        </span>
                        <button
                          onClick={() => handleBookNow(eq.title, 'equipment')}
                          className="bg-brand-magenta hover:bg-brand-magenta-light text-white text-xs font-bold py-2 px-4 rounded-lg shadow-sm transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                        >
                          Book/Inquire <ArrowUpRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 4. BOOKING PAGE */}
            {currentTab === 'booking' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <BookingForm
                  preselectedItem={preselectedBooking?.item}
                  preselectedType={preselectedBooking?.type}
                  onBookingSuccess={handleBookingRegistered}
                  onViewBookings={() => navigateToTab('admin')}
                />
              </div>
            )}

            {/* 5. TEAM TAB */}
            {currentTab === 'team' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 py-12">
                {/* Team Header */}
                <div className="text-center max-w-2xl mx-auto">
                  <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/5 border border-brand-magenta/10 px-3.5 py-1.5 rounded-full">
                    Our Leadership & Management
                  </span>
                  <h2 className="font-display font-black text-3xl md:text-4xl text-brand-navy mt-4">
                    Meet Our Team
                  </h2>
                  <p className="text-gray-500 text-sm mt-2 leading-relaxed font-sans">
                    Behind every staff allocation, emergency support call, and equipment delivery is a certified team of healthcare executives, medical doctors, and logistics leaders.
                  </p>
                </div>

                {/* Team Roster Grid layout */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {teamMembers.map((m) => {
                    const imageUrl = m.image || (m as any).photo || (m as any).photoUrl || (m as any).photo_url || (m as any).avatar || (m as any).imageUrl || (m as any).image_url || (m as any).img || (m as any).picture || (m as any).url || 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=400';
                    const name = m.name || (m as any).fullName || (m as any).full_name || (m as any).title || 'Team Member';
                    const role = m.role || (m as any).position || (m as any).designation || 'Healthcare Specialist';
                    const bio = m.bio || (m as any).description || (m as any).details || (m as any).about || '';
                    const phone = m.phone || (m as any).phoneNumber || (m as any).phone_number || (m as any).contact || (m as any).mobile || '';
                    const email = m.email || (m as any).emailAddress || (m as any).email_address || (m as any).mail || '';

                    return (
                      <div
                        key={m.id || Math.random()}
                        className="bg-white rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow overflow-hidden flex flex-col justify-between"
                      >
                        <div>
                          {/* Member Image with Referrer no referrer policy */}
                          <div className="relative h-64 bg-slate-100">
                            <img
                              src={imageUrl}
                              alt={name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                            />
                            {role && (
                              <div className="absolute top-4 left-4">
                                <span className="text-[10px] font-bold bg-brand-navy text-white px-3 py-1 rounded-full uppercase tracking-wider shadow-sm border border-white/10">
                                  {role}
                                </span>
                              </div>
                            )}
                          </div>

                          {/* Details and bio */}
                          <div className="p-6 space-y-3 font-sans">
                            <h3 className="font-display font-bold text-lg text-brand-navy leading-snug">{name}</h3>
                            {bio && <p className="text-gray-500 text-xs leading-relaxed">{bio}</p>}
                          </div>
                        </div>

                        {/* Contact Actions within card */}
                        {(phone || email) && (
                          <div className="p-6 border-t border-gray-50 pt-4 bg-slate-50/50 space-y-2 font-sans text-xs">
                            {phone && (
                              <div className="flex justify-between items-center text-gray-600">
                                <span>Duty Contact:</span>
                                <a href={`tel:+91${phone}`} className="font-bold text-brand-navy hover:text-brand-magenta transition-colors">
                                  +91 {phone}
                                </a>
                              </div>
                            )}
                            {email && (
                              <div className="flex justify-between items-center text-gray-600">
                                <span>Official Mail:</span>
                                <a href={`mailto:${email}`} className="font-bold text-brand-navy hover:text-brand-magenta transition-colors max-w-[60%] truncate" title={email}>
                                  {email}
                                </a>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Nursing Staff Vetting highlight */}
                <div className="bg-slate-50 border border-gray-200/50 p-8 rounded-3xl grid grid-cols-1 md:grid-cols-12 gap-8 items-center max-w-5xl mx-auto">
                  <div className="md:col-span-8 space-y-4">
                    <h3 className="font-display font-bold text-2xl text-brand-navy flex items-center gap-2">
                      <ShieldCheck className="w-7 h-7 text-green-500 shrink-0" /> Hospital-Vetted Nursing Roster
                    </h3>
                    <p className="text-gray-600 text-sm leading-relaxed font-sans">
                      Our staffing pool includes 120+ clinical staff including Registered ICU Nurses, General Duty Ward Assistants, Geriatric Attendants, and Newborn Baby Care specialists. Each holds a valid clinical degree, CPR certifications, and clear police verifications.
                    </p>
                  </div>
                  <div className="md:col-span-4 flex justify-end">
                    <button
                      onClick={() => handleBookNow()}
                      className="w-full bg-brand-navy hover:bg-brand-navy-light text-white font-bold py-3.5 px-6 rounded-xl transition-all shadow-md text-xs cursor-pointer active:scale-95"
                    >
                      Request Staff Allocation
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 6. CONTACT & DYNAMIC GOOGLE MAPS TAB */}
            {currentTab === 'contact' && (() => {
              const selectedOffice = OFFICES.find(o => o.id === selectedOfficeId) || OFFICES[0];
              return (
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 py-12">
                  {/* Contact Header */}
                  <div className="text-center max-w-2xl mx-auto">
                    <span className="text-xs font-bold text-brand-magenta uppercase tracking-widest bg-brand-magenta/5 border border-brand-magenta/10 px-3.5 py-1.5 rounded-full">
                      Our Multi-City Network
                    </span>
                    <h2 className="font-display font-black text-3xl md:text-4xl text-brand-navy mt-4">
                      Our Office Locations
                    </h2>
                    <p className="text-gray-500 text-sm mt-2 leading-relaxed">
                      Select any of our physical office branches below to view direct contact numbers, official emails, and live maps.
                    </p>
                  </div>

                  {/* Office branch buttons row */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
                    {OFFICES.map((office) => {
                      const isActive = office.id === selectedOfficeId;
                      return (
                        <button
                          key={office.id}
                          onClick={() => setSelectedOfficeId(office.id)}
                          className={`p-5 rounded-2xl border text-center transition-all flex flex-col justify-between items-center gap-2 cursor-pointer ${
                            isActive
                              ? 'bg-brand-navy text-white border-brand-navy shadow-md scale-[1.02]'
                              : 'bg-white text-brand-navy border-gray-100 hover:border-gray-200 hover:bg-slate-50 shadow-sm'
                          }`}
                        >
                          <span className={`text-[10px] uppercase font-bold tracking-widest ${isActive ? 'text-brand-magenta-light' : 'text-brand-magenta'}`}>
                            {office.city} BRANCH
                          </span>
                          <span className="font-display font-bold text-sm tracking-tight leading-tight">
                            {office.branchName.replace(/ Office \(.+\)/, '')}
                          </span>
                          <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-semibold ${isActive ? 'bg-white/10 text-white' : 'bg-slate-100 text-gray-500'}`}>
                            Active
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Contact & Map grid section */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                    {/* Left Side Quick Details Cards */}
                    <div className="lg:col-span-5 space-y-6">
                      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-8 space-y-6 relative overflow-hidden">
                        {/* Decorative background glow */}
                        <div className="absolute top-0 right-0 w-24 h-24 bg-brand-magenta/5 rounded-full blur-xl pointer-events-none" />
                        
                        <h3 className="font-display font-bold text-xl text-brand-navy border-b border-gray-100 pb-3 flex items-center justify-between">
                          <span>{selectedOffice.branchName}</span>
                          <span className="text-xs bg-brand-magenta/10 text-brand-magenta px-3 py-1 rounded-full font-bold uppercase tracking-wider">
                            {selectedOffice.city}
                          </span>
                        </h3>

                        <ul className="space-y-5 text-sm text-gray-600 font-sans">
                          <li className="flex gap-3 items-start">
                            <MapPin className="w-5 h-5 text-brand-magenta shrink-0 mt-0.5" />
                            <div>
                              <p className="text-xs font-bold text-gray-400 uppercase">OFFICE ADDRESS</p>
                              <p className="text-brand-navy font-semibold mt-1 leading-relaxed">
                                {selectedOffice.address}
                              </p>
                            </div>
                          </li>
                          <li className="flex gap-3 items-start">
                            <Phone className="w-5 h-5 text-brand-magenta shrink-0 mt-0.5" />
                            <div>
                              <p className="text-xs font-bold text-gray-400 uppercase">SUPPORT TELEPHONE</p>
                              <p className="text-brand-navy font-bold mt-1 text-lg">
                                <a href={`tel:+91${selectedOffice.phone}`} className="hover:text-brand-magenta transition-colors">
                                  +91 {selectedOffice.phone}
                                </a>
                              </p>
                              <p className="text-[10px] text-gray-400 mt-0.5">Call for urgent staff dispatch and service booking</p>
                            </div>
                          </li>
                          <li className="flex gap-3 items-start">
                            <Mail className="w-5 h-5 text-brand-magenta shrink-0 mt-0.5" />
                            <div>
                              <p className="text-xs font-bold text-gray-400 uppercase">EMAIL ADDRESS</p>
                              <a href={`mailto:${selectedOffice.email}`} className="text-brand-navy font-semibold hover:text-brand-magenta transition-colors break-all block mt-1">
                                {selectedOffice.email}
                              </a>
                            </div>
                          </li>
                        </ul>
                      </div>

                      {/* Operational Timings Card */}
                      <div className="bg-brand-navy text-white rounded-3xl p-8 space-y-4 relative overflow-hidden">
                        <div className="absolute -top-12 -left-12 w-32 h-32 bg-brand-magenta/5 rounded-full blur-2xl" />
                        <h4 className="font-display font-bold text-lg text-white">Emergency Staffing Hours</h4>
                        <p className="text-xs text-gray-300 leading-relaxed font-sans">
                          Our physical administrative office is open Mon - Sat from 9:00 AM to 6:30 PM. However, our emergency nursing dispatch supervisor and telephone inquiry helpdesk remains active <strong>24 Hours, 365 Days</strong>.
                        </p>
                        <div className="flex gap-4 pt-2 border-t border-white/10 text-xs font-semibold text-gray-300 font-sans">
                          <div className="flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4 text-brand-magenta shrink-0" />
                            <span>Night Shifts Active</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4 text-brand-magenta shrink-0" />
                            <span>Holiday Deployments</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Right Side Maps Container */}
                    <div className="lg:col-span-7 bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden p-6 flex flex-col justify-between min-h-[450px]">
                      <div className="space-y-4 mb-4">
                        <h3 className="font-display font-bold text-lg text-brand-navy">Interactive Location Map</h3>
                        <p className="text-xs text-gray-500 font-sans leading-relaxed">
                          Navigate to our {selectedOffice.city} office using the live map interface below. We serve all areas within and surrounding the city with certified home health care.
                        </p>
                      </div>

                      {/* Dynamic Google Maps iframe pointing to current selected office */}
                      <div className="w-full h-80 rounded-2xl overflow-hidden border border-gray-200 shadow-inner relative bg-slate-50">
                        <iframe
                          src={selectedOffice.embedUrl}
                          width="100%"
                          height="100%"
                          style={{ border: 0 }}
                          allowFullScreen={true}
                          loading="lazy"
                          referrerPolicy="no-referrer-when-downgrade"
                          title={`Ananya Health Care ${selectedOffice.city} Office Map`}
                        />
                      </div>

                      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-4 border-t border-gray-100 mt-4 text-xs font-semibold text-gray-500">
                        <p className="font-sans text-left max-w-md">Branch: {selectedOffice.address}</p>
                        <a
                          href={`https://maps.google.com/?q=${encodeURIComponent(selectedOffice.mapQuery)}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-brand-magenta hover:underline flex items-center gap-1 shrink-0 font-bold"
                        >
                          Open In Google Maps App <ArrowUpRight className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* 6. CAREERS RECRUITMENT PAGE */}
            {currentTab === 'careers' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <CareersPage 
                  onApplicationSuccess={() => {
                    setRefreshAdminTrigger((prev) => prev + 1);
                  }} 
                />
              </div>
            )}

            {/* NEW: FAMILY TRACKER PORTAL TAB */}
            {currentTab === 'family-portal' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <FamilyPortal />
              </div>
            )}

            {/* USER & STAFF PROFILE PORTAL TAB */}
            {currentTab === 'profile' && currentUser && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
                <ProfilePortal 
                  currentUser={currentUser}
                  setCurrentTab={navigateToTab}
                  onBookNow={handleBookNow}
                />
              </div>
            )}

            {currentTab === 'profile' && !currentUser && (
              <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
                <div className="bg-white rounded-3xl p-8 border border-gray-200 shadow-md space-y-4">
                  <div className="w-16 h-16 bg-brand-magenta/10 text-brand-magenta rounded-2xl flex items-center justify-center mx-auto">
                    <Users className="w-8 h-8" />
                  </div>
                  <h2 className="font-display font-extrabold text-2xl text-brand-navy">Sign In to View Your Profile</h2>
                  <p className="text-sm text-gray-600 max-w-md mx-auto">
                    Access your active healthcare bookings, patient vitals, staff duty attendance logs, or update your security password.
                  </p>
                  <div className="pt-4 flex justify-center gap-3">
                    <button
                      onClick={() => navigateToTab('home')}
                      className="px-6 py-2.5 bg-brand-magenta text-white text-xs font-bold rounded-xl hover:bg-brand-magenta-light cursor-pointer shadow-md"
                    >
                      Return to Home
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 7. OPERATIONS / ADMIN STAFF PORTAL */}
            {currentTab === 'admin' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <AdminBookings 
                  onRefreshTrigger={refreshAdminTrigger} 
                  onTriggerSplashPreview={() => setShowSplash(true)} 
                />
              </div>
            )}

          </motion.div>
        </AnimatePresence>
      </main>

      {/* Persistent Dynamic Notification Toast on Booking Submission */}
      <AnimatePresence>
        {showToast && latestBooking && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed bottom-6 right-6 z-50 bg-brand-navy text-white p-5 rounded-2xl shadow-2xl border border-white/10 max-w-sm font-sans w-[90vw]"
          >
            <div className="flex gap-4 items-start">
              <div className="p-2 bg-brand-magenta/15 rounded-xl text-brand-magenta">
                <Heart className="w-5 h-5 fill-brand-magenta animate-pulse" />
              </div>
              <div className="space-y-1.5 flex-grow">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] bg-brand-magenta text-white font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                    NEW INQUIRY
                  </span>
                  <button onClick={() => setShowToast(false)} className="text-gray-400 hover:text-white text-xs">
                    ✕
                  </button>
                </div>
                <h4 className="font-display font-bold text-sm text-white">
                  Booking #{String(latestBooking.id || '').includes('-') ? String(latestBooking.id).split('-').slice(-1)[0] : String(latestBooking.id || '')}
                </h4>
                <p className="text-xs text-gray-300 leading-relaxed">
                  Patient <strong className="text-white">{latestBooking.customerName}</strong> registered for <strong className="text-brand-magenta-light">{latestBooking.itemSelected}</strong> on {latestBooking.bookingDate}.
                </p>
                <div className="flex justify-between items-center pt-2 border-t border-white/10 text-[10px] text-gray-400">
                  <span>Manager will call shortly</span>
                  <button
                    onClick={() => {
                      setShowToast(false);
                      setCurrentTab('admin');
                    }}
                    className="text-brand-magenta hover:underline font-bold"
                  >
                    View Portal
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Action Button for WhatsApp Support */}
      <div className="fixed bottom-24 right-6 lg:bottom-8 lg:right-8 z-50 group font-sans">
        {/* Hover Label for Desktop */}
        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-brand-navy text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow-xl border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none whitespace-nowrap hidden sm:flex items-center gap-1.5">
          <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
          <span>WhatsApp Live Support</span>
        </div>
        
        {/* Pulsing indicator background */}
        <span className="absolute inset-0 bg-emerald-500 rounded-full animate-ping opacity-20 scale-110 pointer-events-none" />
        
        {/* Floating link itself */}
        <a
          href="https://wa.me/917734931740?text=Hello%20Ananya%20Health%20Care%20Support%2C%20I%20would%20like%20to%20inquire%20about%20your%20services%21"
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 transform hover:scale-110 active:scale-95 border-2 border-white/20 hover:border-white/40"
          title="Chat with us on WhatsApp"
        >
          <MessageCircle className="w-7 h-7" />
        </a>
      </div>

      {/* Sticky Mobile Contacts Floating Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-gray-200/80 px-4 py-2.5 flex justify-around items-center gap-3 shadow-lg lg:hidden font-sans">
        <a
          href="tel:+917734931740"
          className="flex-1 bg-brand-navy text-white text-center py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-brand-navy-light transition-all"
        >
          <Phone className="w-3.5 h-3.5 text-brand-magenta" /> Call Manager
        </a>
        <button
          onClick={() => handleBookNow()}
          className="flex-1 bg-brand-magenta text-white text-center py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-brand-magenta-light transition-all cursor-pointer"
        >
          <Calendar className="w-3.5 h-3.5" /> Book Staff/Equip
        </button>
      </div>

      {/* Footer dynamic block */}
      <Footer setCurrentTab={setCurrentTab} />

    </motion.div>
  );
}
