import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { db } from './src/db/index.ts';
import { 
  users, 
  bookings, 
  equipment, 
  vitals, 
  attendance, 
  brandSettings, 
  jobApplications,
  staffUsers,
  staffProfileRequests,
  staffDuties
} from './src/db/schema.ts';
import { eq, desc } from 'drizzle-orm';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', database: 'cloudsql-postgresql', timestamp: new Date().toISOString() });
  });

  // --- API: Brand Settings ---
  app.get('/api/brand-settings', async (req, res) => {
    try {
      const records = await db.select().from(brandSettings).where(eq(brandSettings.brandKey, 'default_brand'));
      if (records.length > 0) {
        return res.json(records[0]);
      }
      return res.json(null);
    } catch (err: any) {
      console.error('Error fetching brand settings:', err);
      res.status(500).json({ error: 'Failed to fetch brand settings' });
    }
  });

  app.post('/api/brand-settings', async (req, res) => {
    try {
      const { brandName, logoUrl, tagline } = req.body;
      const result = await db
        .insert(brandSettings)
        .values({
          brandKey: 'default_brand',
          brandName: brandName || 'ANANYA',
          logoUrl: logoUrl || '',
          tagline: tagline || 'HEALTH CARE SERVICES',
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: brandSettings.brandKey,
          set: {
            brandName: brandName || 'ANANYA',
            logoUrl: logoUrl || '',
            tagline: tagline || 'HEALTH CARE SERVICES',
            updatedAt: new Date(),
          },
        })
        .returning();
      res.json(result[0]);
    } catch (err: any) {
      console.error('Error saving brand settings:', err);
      res.status(500).json({ error: 'Failed to save brand settings' });
    }
  });

  // --- API: Bookings ---
  app.get('/api/bookings', async (req, res) => {
    try {
      const data = await db.select().from(bookings).orderBy(desc(bookings.createdAt));
      const mapped = data.map(b => ({
        ...b,
        id: b.bookingKey || String(b.id),
      }));
      res.json(mapped);
    } catch (err: any) {
      console.error('Error fetching bookings:', err);
      res.status(500).json({ error: 'Failed to fetch bookings' });
    }
  });

  app.post('/api/bookings', async (req, res) => {
    try {
      const item = req.body || {};
      const key = item.bookingKey || item.booking_key || item.id || `book-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
      const customerName = item.customerName || item.customer_name || item.name || 'Anonymous Patient';
      const phoneNumber = item.phoneNumber || item.phone_number || item.phone || '';
      const email = item.email || '';
      const type = item.type || 'service';
      const itemSelected = item.itemSelected || item.item_selected || item.service || item.title || 'General Service';
      const bookingDate = item.bookingDate || item.booking_date || item.date || new Date().toISOString().slice(0, 10);
      const address = item.address || '';
      const requirementDetails = item.requirementDetails || item.requirement_details || '';
      const status = item.status || 'Pending';
      const patientId = item.patientId || item.patient_id || '';
      const assignedStaffId = item.assignedStaffId || item.assigned_staff_id || '';
      const assignedStaffName = item.assignedStaffName || item.assigned_staff_name || '';
      const assignedStaffRole = item.assignedStaffRole || item.assigned_staff_role || '';

      const result = await db
        .insert(bookings)
        .values({
          bookingKey: key,
          customerName,
          phoneNumber,
          email,
          type,
          itemSelected,
          bookingDate,
          address,
          requirementDetails,
          status,
          patientId,
          assignedStaffId,
          assignedStaffName,
          assignedStaffRole,
        })
        .onConflictDoUpdate({
          target: bookings.bookingKey,
          set: {
            customerName,
            phoneNumber,
            email,
            type,
            itemSelected,
            bookingDate,
            address,
            requirementDetails,
            status,
            patientId,
            assignedStaffId,
            assignedStaffName,
            assignedStaffRole,
          },
        })
        .returning();
      const saved = result[0];
      res.json({ ...saved, id: saved.bookingKey || String(saved.id) });
    } catch (err: any) {
      console.error('Error saving booking:', err);
      res.status(500).json({ error: 'Failed to save booking' });
    }
  });

  app.delete('/api/bookings/:key', async (req, res) => {
    try {
      const { key } = req.params;
      await db.delete(bookings).where(eq(bookings.bookingKey, key));
      res.json({ success: true, deletedKey: key });
    } catch (err: any) {
      console.error('Error deleting booking:', err);
      res.status(500).json({ error: 'Failed to delete booking' });
    }
  });

  // --- API: Equipment Catalog ---
  app.get('/api/equipment', async (req, res) => {
    try {
      const data = await db.select().from(equipment).orderBy(desc(equipment.createdAt));
      res.json(data.map(e => ({ ...e, id: e.equipmentKey || String(e.id) })));
    } catch (err: any) {
      console.error('Error fetching equipment:', err);
      res.status(500).json({ error: 'Failed to fetch equipment' });
    }
  });

  app.post('/api/equipment', async (req, res) => {
    try {
      const item = req.body || {};
      const key = item.equipmentKey || item.equipment_key || item.id || `eq-${Date.now()}`;
      const title = item.title || 'Medical Equipment';
      const description = item.description || '';
      const category = item.category || 'both';
      const rentalPrice = item.rentalPrice || item.rental_price || '';
      const purchasePrice = item.purchasePrice || item.purchase_price || '';
      const features = Array.isArray(item.features) ? item.features : [];
      const image = item.image || '';

      const result = await db
        .insert(equipment)
        .values({
          equipmentKey: key,
          title,
          description,
          category,
          rentalPrice,
          purchasePrice,
          features,
          image,
        })
        .onConflictDoUpdate({
          target: equipment.equipmentKey,
          set: {
            title,
            description,
            category,
            rentalPrice,
            purchasePrice,
            features,
            image,
          },
        })
        .returning();
      const saved = result[0];
      res.json({ ...saved, id: saved.equipmentKey || String(saved.id) });
    } catch (err: any) {
      console.error('Error saving equipment:', err);
      res.status(500).json({ error: 'Failed to save equipment' });
    }
  });

  app.delete('/api/equipment/:key', async (req, res) => {
    try {
      const { key } = req.params;
      await db.delete(equipment).where(eq(equipment.equipmentKey, key));
      res.json({ success: true, deletedKey: key });
    } catch (err: any) {
      console.error('Error deleting equipment:', err);
      res.status(500).json({ error: 'Failed to delete equipment' });
    }
  });

  // --- API: Patient Vitals ---
  app.get('/api/vitals', async (req, res) => {
    try {
      const data = await db.select().from(vitals).orderBy(desc(vitals.createdAt));
      res.json(data.map(v => ({ ...v, id: v.vitalKey || String(v.id) })));
    } catch (err: any) {
      console.error('Error fetching vitals:', err);
      res.status(500).json({ error: 'Failed to fetch vitals' });
    }
  });

  app.post('/api/vitals', async (req, res) => {
    try {
      const item = req.body || {};
      const key = item.vitalKey || item.vital_key || item.id || `v-${Date.now()}`;
      const patientId = item.patientId || item.patient_id || 'PAT-1001';
      const patientName = item.patientName || item.patient_name || 'Patient';
      const temperature = Math.round(Number(item.temperature) || 98.6);
      const bpSystolic = Math.round(Number(item.bpSystolic || item.bp_systolic) || 120);
      const bpDiastolic = Math.round(Number(item.bpDiastolic || item.bp_diastolic) || 80);
      const heartRate = Math.round(Number(item.heartRate || item.heart_rate) || 72);
      const loggedDate = item.timestamp || item.loggedDate || item.logged_date || new Date().toISOString().slice(0, 10);

      const result = await db
        .insert(vitals)
        .values({
          vitalKey: key,
          patientId,
          patientName,
          temperature,
          bpSystolic,
          bpDiastolic,
          heartRate,
          loggedDate,
        })
        .onConflictDoUpdate({
          target: vitals.vitalKey,
          set: {
            patientId,
            patientName,
            temperature,
            bpSystolic,
            bpDiastolic,
            heartRate,
            loggedDate,
          },
        })
        .returning();
      const saved = result[0];
      res.json({ ...saved, id: saved.vitalKey || String(saved.id) });
    } catch (err: any) {
      console.error('Error saving vitals:', err);
      res.status(500).json({ error: 'Failed to save vitals' });
    }
  });

  app.delete('/api/vitals/:key', async (req, res) => {
    try {
      const { key } = req.params;
      await db.delete(vitals).where(eq(vitals.vitalKey, key));
      res.json({ success: true, deletedKey: key });
    } catch (err: any) {
      console.error('Error deleting vitals:', err);
      res.status(500).json({ error: 'Failed to delete vitals' });
    }
  });

  // --- API: Attendance Logs ---
  app.get('/api/attendance', async (req, res) => {
    try {
      const data = await db.select().from(attendance).orderBy(desc(attendance.createdAt));
      res.json(data.map(a => ({ ...a, id: a.attendanceKey || String(a.id) })));
    } catch (err: any) {
      console.error('Error fetching attendance:', err);
      res.status(500).json({ error: 'Failed to fetch attendance' });
    }
  });

  app.post('/api/attendance', async (req, res) => {
    try {
      const item = req.body || {};
      const key = item.attendanceKey || item.attendance_key || item.id || `att-${Date.now()}`;
      const userId = item.userId || item.user_id || 'STF-001';
      const staffName = item.staffName || item.staff_name || 'Staff Member';
      const role = item.role || 'Clinical Staff';
      const checkInTime = item.checkInTime || item.check_in_time || new Date().toLocaleTimeString();
      const checkOutTime = item.checkOutTime || item.check_out_time || null;
      const location = item.location || 'Headquarters';
      const actionNotes = item.actionNotes || item.action_notes || '';
      const date = item.date || new Date().toISOString().slice(0, 10);
      const coordinates = item.coordinates || null;
      const checkOutCoordinates = item.checkOutCoordinates || item.check_out_coordinates || null;

      const result = await db
        .insert(attendance)
        .values({
          attendanceKey: key,
          userId,
          staffName,
          role,
          checkInTime,
          checkOutTime,
          location,
          actionNotes,
          date,
          coordinates,
          checkOutCoordinates,
        })
        .onConflictDoUpdate({
          target: attendance.attendanceKey,
          set: {
            checkOutTime,
            actionNotes,
            checkOutCoordinates,
          },
        })
        .returning();
      const saved = result[0];
      res.json({ ...saved, id: saved.attendanceKey || String(saved.id) });
    } catch (err: any) {
      console.error('Error saving attendance log:', err);
      res.status(500).json({ error: 'Failed to save attendance log' });
    }
  });

  // --- API: Job Applications ---
  app.get('/api/job-applications', async (req, res) => {
    try {
      const data = await db.select().from(jobApplications).orderBy(desc(jobApplications.createdAt));
      res.json(data.map(j => ({ ...j, id: j.appKey || String(j.id) })));
    } catch (err: any) {
      console.error('Error fetching job applications:', err);
      res.status(500).json({ error: 'Failed to fetch job applications' });
    }
  });

  app.post('/api/job-applications', async (req, res) => {
    try {
      const item = req.body || {};
      const key = item.appKey || item.app_key || item.id || `job-${Date.now()}`;
      const applicantName = item.applicantName || item.applicant_name || item.name || 'Applicant';
      const phoneNumber = item.phoneNumber || item.phone_number || item.phone || '';
      const email = item.email || '';
      const position = item.position || 'Healthcare Professional';
      const experienceYears = item.experienceYears || item.experience_years || '';
      const qualifications = item.qualifications || '';
      const coverMessage = item.coverMessage || item.cover_message || '';
      const status = item.status || 'Received';

      const result = await db
        .insert(jobApplications)
        .values({
          appKey: key,
          applicantName,
          phoneNumber,
          email,
          position,
          experienceYears,
          qualifications,
          coverMessage,
          status,
        })
        .onConflictDoUpdate({
          target: jobApplications.appKey,
          set: {
            status,
          },
        })
        .returning();
      const saved = result[0];
      res.json({ ...saved, id: saved.appKey || String(saved.id) });
    } catch (err: any) {
      console.error('Error saving job application:', err);
      res.status(500).json({ error: 'Failed to save job application' });
    }
  });

  // --- API: Staff Users ---
  app.get('/api/staff', async (req, res) => {
    try {
      const data = await db.select().from(staffUsers).orderBy(desc(staffUsers.createdAt));
      res.json(data.map(s => ({
        ...s,
        id: s.staffKey || String(s.id),
        userId: s.userId,
        phoneNumber: s.phoneNumber,
      })));
    } catch (err: any) {
      console.error('Error fetching staff users:', err);
      res.status(500).json({ error: 'Failed to fetch staff users' });
    }
  });

  app.post('/api/staff', async (req, res) => {
    try {
      const item = req.body || {};
      const key = item.staffKey || item.staff_key || item.userId || item.user_id || item.id || `ANA${Math.floor(1000 + Math.random() * 9000)}`;
      const userId = item.userId || item.user_id || key;
      const name = item.name || 'Healthcare Staff';
      const role = item.role || 'ICU Staff Nurse';
      const phoneNumber = item.phoneNumber || item.phone_number || item.phone || '';
      const email = item.email || '';
      const password = item.password || 'Ananya@123';
      const status = item.status || 'Active';

      const result = await db
        .insert(staffUsers)
        .values({
          staffKey: key,
          userId,
          name,
          role,
          phoneNumber,
          email,
          password,
          status,
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: staffUsers.staffKey,
          set: {
            name,
            role,
            phoneNumber,
            email,
            password,
            status,
            updatedAt: new Date(),
          },
        })
        .returning();
      const saved = result[0];
      res.json({ ...saved, id: saved.staffKey || String(saved.id) });
    } catch (err: any) {
      console.error('Error saving staff user:', err);
      res.status(500).json({ error: 'Failed to save staff user' });
    }
  });

  app.delete('/api/staff/:key', async (req, res) => {
    try {
      const { key } = req.params;
      await db.delete(staffUsers).where(eq(staffUsers.staffKey, key));
      res.json({ success: true, deletedKey: key });
    } catch (err: any) {
      console.error('Error deleting staff user:', err);
      res.status(500).json({ error: 'Failed to delete staff user' });
    }
  });

  // --- API: Staff Duties & Patient Allocations (Duty Days & Location Tracking) ---
  app.get('/api/staff-duties', async (req, res) => {
    try {
      const data = await db.select().from(staffDuties).orderBy(desc(staffDuties.createdAt));
      res.json(data.map(d => ({
        ...d,
        id: d.dutyKey || String(d.id),
      })));
    } catch (err: any) {
      console.error('Error fetching staff duties:', err);
      res.status(500).json({ error: 'Failed to fetch staff duties' });
    }
  });

  app.post('/api/staff-duties', async (req, res) => {
    try {
      const item = req.body || {};
      const key = item.dutyKey || item.duty_key || item.id || `duty-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
      const patientId = item.patientId || item.patient_id || 'PAT1001';
      const patientName = item.patientName || item.patient_name || 'Patient';
      const patientPhone = item.patientPhone || item.patient_phone || '';
      const patientAge = typeof item.patientAge === 'number' ? item.patientAge : (parseInt(item.patient_age || '50', 10) || 50);
      const patientGender = item.patientGender || item.patient_gender || 'Male';
      const serviceTitle = item.serviceTitle || item.service_title || 'Home Nursing Service';
      const serviceType = item.serviceType || item.service_type || 'service';
      const locationAddress = item.locationAddress || item.location_address || 'Jaipur, Rajasthan';
      const locality = item.locality || 'Jaipur';
      const city = item.city || 'Jaipur';
      const startDate = item.startDate || item.start_date || new Date().toISOString().slice(0, 10);
      const endDate = item.endDate || item.end_date || new Date().toISOString().slice(0, 10);
      const totalDays = typeof item.totalDays === 'number' ? item.totalDays : (parseInt(item.total_days || '1', 10) || 1);
      const totalShifts = typeof item.totalShifts === 'number' ? item.totalShifts : (parseInt(item.total_shifts || '1', 10) || 1);
      const totalHours = typeof item.totalHours === 'number' ? item.totalHours : (parseInt(item.total_hours || '8', 10) || 8);
      const status = item.status || 'Ongoing';
      const assignedStaffId = item.assignedStaffId || item.assigned_staff_id || '';
      const assignedStaffName = item.assignedStaffName || item.assigned_staff_name || '';
      const assignedStaffRole = item.assignedStaffRole || item.assigned_staff_role || '';
      const clinicalRequirement = item.clinicalRequirement || item.clinical_requirement || '';
      const dutyHighlights = Array.isArray(item.dutyHighlights) ? item.dutyHighlights : [];
      const dailyLogs = Array.isArray(item.dailyLogs) ? item.dailyLogs : [];

      const result = await db
        .insert(staffDuties)
        .values({
          dutyKey: key,
          patientId,
          patientName,
          patientPhone,
          patientAge,
          patientGender,
          serviceTitle,
          serviceType,
          locationAddress,
          locality,
          city,
          startDate,
          endDate,
          totalDays,
          totalShifts,
          totalHours,
          status,
          assignedStaffId,
          assignedStaffName,
          assignedStaffRole,
          clinicalRequirement,
          dutyHighlights,
          dailyLogs,
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: staffDuties.dutyKey,
          set: {
            patientId,
            patientName,
            patientPhone,
            patientAge,
            patientGender,
            serviceTitle,
            serviceType,
            locationAddress,
            locality,
            city,
            startDate,
            endDate,
            totalDays,
            totalShifts,
            totalHours,
            status,
            assignedStaffId,
            assignedStaffName,
            assignedStaffRole,
            clinicalRequirement,
            dutyHighlights,
            dailyLogs,
            updatedAt: new Date(),
          },
        })
        .returning();
      const saved = result[0];
      res.json({ ...saved, id: saved.dutyKey || String(saved.id) });
    } catch (err: any) {
      console.error('Error saving staff duty:', err);
      res.status(500).json({ error: 'Failed to save staff duty' });
    }
  });

  app.delete('/api/staff-duties/:key', async (req, res) => {
    try {
      const { key } = req.params;
      await db.delete(staffDuties).where(eq(staffDuties.dutyKey, key));
      res.json({ success: true, deletedKey: key });
    } catch (err: any) {
      console.error('Error deleting staff duty:', err);
      res.status(500).json({ error: 'Failed to delete staff duty' });
    }
  });

  // --- API: Staff Profile Change Requests (Admin Approval) ---
  app.get('/api/staff-profile-requests', async (req, res) => {
    try {
      const data = await db.select().from(staffProfileRequests).orderBy(desc(staffProfileRequests.createdAt));
      res.json(data.map(r => ({
        ...r,
        id: r.requestKey || String(r.id),
      })));
    } catch (err: any) {
      console.error('Error fetching staff profile requests:', err);
      res.status(500).json({ error: 'Failed to fetch profile change requests' });
    }
  });

  app.post('/api/staff-profile-requests', async (req, res) => {
    try {
      const item = req.body || {};
      const key = item.requestKey || item.request_key || item.id || `req-${Date.now()}`;
      const staffId = item.staffId || item.staff_id || item.userId || '';
      const currentName = item.currentName || item.current_name || '';
      const currentRole = item.currentRole || item.current_role || '';
      const currentPhone = item.currentPhone || item.current_phone || '';
      const currentEmail = item.currentEmail || item.current_email || '';
      const requestedName = item.requestedName || item.requested_name || '';
      const requestedRole = item.requestedRole || item.requested_role || '';
      const requestedPhone = item.requestedPhone || item.requested_phone || '';
      const requestedEmail = item.requestedEmail || item.requested_email || '';
      const reason = item.reason || '';
      const status = item.status || 'Pending';
      const adminNotes = item.adminNotes || item.admin_notes || '';
      const resolvedAt = item.resolvedAt || (status !== 'Pending' ? new Date() : null);

      const result = await db
        .insert(staffProfileRequests)
        .values({
          requestKey: key,
          staffId,
          currentName,
          currentRole,
          currentPhone,
          currentEmail,
          requestedName,
          requestedRole,
          requestedPhone,
          requestedEmail,
          reason,
          status,
          adminNotes,
          resolvedAt,
        })
        .onConflictDoUpdate({
          target: staffProfileRequests.requestKey,
          set: {
            status,
            adminNotes,
            resolvedAt: new Date(),
          },
        })
        .returning();
      const saved = result[0];
      res.json({ ...saved, id: saved.requestKey || String(saved.id) });
    } catch (err: any) {
      console.error('Error saving staff profile request:', err);
      res.status(500).json({ error: 'Failed to save profile request' });
    }
  });

  app.post('/api/staff-profile-requests/:key/approve', async (req, res) => {
    try {
      const { key } = req.params;
      const { adminNotes } = req.body || {};
      
      const reqList = await db.select().from(staffProfileRequests).where(eq(staffProfileRequests.requestKey, key));
      if (reqList.length === 0) {
        return res.status(404).json({ error: 'Request not found' });
      }
      
      const targetReq = reqList[0];
      
      // Update profile request to Approved
      const updatedReq = await db
        .update(staffProfileRequests)
        .set({
          status: 'Approved',
          adminNotes: adminNotes || 'Approved by Administrator',
          resolvedAt: new Date(),
        })
        .where(eq(staffProfileRequests.requestKey, key))
        .returning();

      // Update staff users table with the approved changes
      if (targetReq.staffId) {
        await db
          .update(staffUsers)
          .set({
            name: targetReq.requestedName || targetReq.currentName,
            role: targetReq.requestedRole || targetReq.currentRole,
            phoneNumber: targetReq.requestedPhone || targetReq.currentPhone,
            email: targetReq.requestedEmail || targetReq.currentEmail,
            updatedAt: new Date(),
          })
          .where(eq(staffUsers.userId, targetReq.staffId));
      }

      res.json({ success: true, request: updatedReq[0] });
    } catch (err: any) {
      console.error('Error approving staff profile request:', err);
      res.status(500).json({ error: 'Failed to approve request' });
    }
  });

  app.post('/api/staff-profile-requests/:key/reject', async (req, res) => {
    try {
      const { key } = req.params;
      const { adminNotes } = req.body || {};
      
      const updatedReq = await db
        .update(staffProfileRequests)
        .set({
          status: 'Rejected',
          adminNotes: adminNotes || 'Rejected by Administrator',
          resolvedAt: new Date(),
        })
        .where(eq(staffProfileRequests.requestKey, key))
        .returning();

      res.json({ success: true, request: updatedReq[0] });
    } catch (err: any) {
      console.error('Error rejecting staff profile request:', err);
      res.status(500).json({ error: 'Failed to reject request' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Healthcare Server with PostgreSQL running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
